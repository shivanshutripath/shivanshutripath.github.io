"""
rendezvous_robot.py
===================

Controller of agency station i (six independent instances).  Station i is the
ground control of UAV i and an agent of Algorithm 1 of

    "Cooperative Learning of Shared Latent Dynamics for Distributed Online
     Optimization"

The station stays at its command post.  The charging vehicle, a separate
robot, drives to the position the stations agree on.

Per algorithm step t (started by a tick on its telemetry channel):

  data collection, t < N
      y_i(t)     noisy position of UAV i from its own sensor (the tick carries it);
                 the noisy gradient 2 h_i (x_i(t) - y_i(t)) drives gradient tracking
  t = N-1       windowed Gauss--Markov reconstruction theta~_i(t) of the UAV deviation,
                 IV moments M0_i, M1_i (eq. (8)), tau = 3 rounds of average consensus on
                 the 2x2 moments with the graph neighbors, A_hat_i = M1 M0^-1 (+ safeguard)
  forecasting, t >= N
      theta_hat_i(t) = A_hat_i^(t-N+k) theta~_i(N-k), gradient 2 h_i (x_i - bbar_i - theta_hat_i)

  every t       gradient tracking (eq. (11)) with two exchanges with the neighbors:
                 s_i <- sum_j W_ij (s_j + g_j(t) - g_j(t-1)),  x_i <- sum_j W_ij (x_j - alpha s_j)

The station holds its command post (differential drive, GPS + IMU).  Only the
moments and the tracking variables are ever transmitted; measurements never
leave the station.

Status messages on channel 2 (display and data logging only, never read by
another station) report the iterate, the forecast used at step t, both
estimates of A (cooperative and local-only), and how many messages and reals
this station has sent to its neighbors so far.
"""
import math
import os
import sys

import numpy as np
from controller import Robot

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "lib"))
import rendezvous_common as C  # noqa: E402

# differential drive geometry (must match DemoGroundRobot.proto)
WHEEL_RADIUS = 0.10
AXLE = 0.40
V_MAX = 0.9          # m/s
W_MAX = 2.5          # rad/s
K_V, K_W = 1.6, 3.0
GOAL_TOL = 0.04      # m


class RendezvousRobot:
    def __init__(self):
        self.rb = Robot()
        self.ts = int(self.rb.getBasicTimeStep())
        self.i = int(self.rb.getName().split("_")[1])
        self.h = C.PRIORITIES[self.i]
        self.nbrs = C.neighbors(self.i)
        self.W = C.metropolis_row(self.i)
        self.k, self.alpha = C.K_WINDOW, C.ALPHA

        self.left = self.rb.getDevice("left wheel")
        self.right = self.rb.getDevice("right wheel")
        for m in (self.left, self.right):
            m.setPosition(float("inf"))
            m.setVelocity(0.0)
        self.gps = self.rb.getDevice("gps")
        self.imu = self.rb.getDevice("imu")
        self.gps.enable(self.ts)
        self.imu.enable(self.ts)
        self.tx = self.rb.getDevice("emitter")
        self.rx_net = self.rb.getDevice("network")
        self.rx_tel = self.rb.getDevice("telemetry")
        self.rx_net.enable(self.ts)
        self.rx_tel.enable(self.ts)

        # --- Algorithm 1 state ---
        self.x = np.zeros(2)          # iterate x_i(t), starts at 0 (paper units)
        self.s = None                 # tracker s_i(t)
        self.g_prev = None            # gamma_i(t-1)
        self.Y = []                   # own measurements y_i(t), t < N (never transmitted)
        self.A_hat, self.rho = None, None
        self.A_local = None           # local-only estimate (tau = 0), for the on-screen comparison
        self.anchor, self.P, self.fore_t = None, None, None
        self.M0 = self.M1 = None
        self.round = 0

        self.ticks = []               # pending ticks from the supervisor
        self.inbox = {}               # (kind, t, round) -> {sender: value}
        self.phase = "idle"
        self.t = None
        self.my_msg = None
        self.goal = None              # metres; the command post, once GPS is valid
        self.home = None
        self.rho_local = None
        self.fc = None                # forecast theta_hat_i(t) used at the current step (t >= N)

        # what this station actually sent to its neighbors (the algorithm's traffic only)
        self.sent = {"x": [0, 0], "s": [0, 0], "m": [0, 0]}   # kind -> [messages, reals]
        self.bytes_sent = 0
        self.dispatch_sent = 0        # iterates sent to the charging robot (actuation, counted apart)

    # ------------------------------------------------------------ messaging
    def send_net(self, kind, t, r, value):
        v = np.asarray(value).ravel().tolist()
        packet = C.pack(kind=kind, i=self.i, t=t, r=r, v=v)
        self.tx.setChannel(C.CH_NETWORK)
        self.tx.send(packet)
        self.my_msg = np.asarray(value, dtype=float)
        self.sent[kind][0] += 1
        self.sent[kind][1] += len(v)
        self.bytes_sent += len(packet)

    def send_status(self, t_next):
        """Display and logging only: the supervisor draws and records it; no station reads it."""
        msg = dict(kind="status", i=self.i, t=t_next, x=self.x.tolist(),
                   id_coop=None if self.A_hat is None else float(np.linalg.norm(self.A_hat - C.A_TRUE)),
                   id_local=None if self.A_local is None else float(np.linalg.norm(self.A_local - C.A_TRUE)),
                   rho=self.rho, rho_l=self.rho_local,
                   msgs=sum(v[0] for v in self.sent.values()),
                   reals=sum(v[1] for v in self.sent.values()),
                   sent={k: v[:] for k, v in self.sent.items()},
                   nbytes=self.bytes_sent, disp=self.dispatch_sent)
        if self.fc is not None:
            msg["fc"] = [float(self.fc[0]), float(self.fc[1])]
            msg["fc_t"] = self.t
        if self.A_hat is not None:
            msg["A"] = self.A_hat.ravel().tolist()
            msg["Al"] = self.A_local.ravel().tolist()
        self.tx.setChannel(C.CH_STATUS)
        self.tx.send(C.pack(**msg))
        self.tx.setChannel(C.CH_NETWORK)

    def send_progress(self, stage, r=0):
        """Display only: identification progress (consensus round r of tau)."""
        self.tx.setChannel(C.CH_STATUS)
        self.tx.send(C.pack(kind="progress", i=self.i, stage=stage, r=r))
        self.tx.setChannel(C.CH_NETWORK)

    def send_dispatch(self, t_next):
        """Actuation, not part of Algorithm 1: tell the charging robot this station's
        iterate x_i(t+1); the robot drives to the mean of the iterates it receives."""
        self.tx.setChannel(C.CH_DISPATCH)
        self.tx.send(C.pack(kind="iterate", i=self.i, t=t_next, x=self.x.tolist()))
        self.tx.setChannel(C.CH_NETWORK)
        self.dispatch_sent += 1

    def poll(self):
        while self.rx_tel.getQueueLength() > 0:
            try:
                msg = C.unpack(self.rx_tel.getString())
                if msg.get("kind") == "tick":
                    self.ticks.append(msg)
            finally:
                self.rx_tel.nextPacket()
        while self.rx_net.getQueueLength() > 0:
            try:
                msg = C.unpack(self.rx_net.getString())
                if msg.get("i") in self.nbrs:      # only messages of graph neighbors are used
                    self.inbox.setdefault((msg["kind"], msg["t"], msg["r"]), {})[msg["i"]] = np.array(msg["v"])
            finally:
                self.rx_net.nextPacket()

    def gathered(self, kind, t, r):
        box = self.inbox.get((kind, t, r), {})
        return all(j in box for j in self.nbrs)

    def mix(self, kind, t, r, shape):
        """sum_j W_ij v_j over the closed neighborhood (own value included)."""
        box = self.inbox.pop((kind, t, r))
        out = self.W[self.i] * self.my_msg.reshape(shape)
        for j in self.nbrs:
            out = out + self.W[j] * box[j].reshape(shape)
        return out

    # ----------------------------------------------------------- Algorithm 1
    def gradient_signal(self, t):
        """gamma_i(t): measured gradient for t < N, forecast gradient for t >= N."""
        if t < C.N_DATA:
            return 2.0 * self.h * (self.x - self.Y[t])            # = grad f_i with the sensed UAV position
        self.fc = self.theta_hat(t)
        return C.gradient(self.h, C.tasking(self.i, t), self.x, self.fc)

    def theta_hat(self, t):
        while self.fore_t < t:
            self.P = self.P @ self.A_hat
            self.fore_t += 1
        return self.P @ self.anchor

    def start_step(self, tick):
        self.t = t = tick["t"]
        if tick.get("y") is not None:
            self.Y.append(np.array(tick["y"], dtype=float))
        g = self.gradient_signal(t)
        if t == 0:
            self.s, self.g_prev = g, g
            self.send_net("x", t, 0, self.x - self.alpha * self.s)
            self.phase = "wait_x"
        else:
            self.send_net("s", t, 0, self.s + g - self.g_prev)
            self.g_prev = g
            self.phase = "wait_s"

    def identification(self):
        """Reconstruction and local IV moments; then start the consensus rounds."""
        # The patrol is known tasking. Identification uses only the wind deviation.
        dev = np.stack([self.Y[t] - C.tasking(self.i, t) for t in range(len(self.Y))])
        th = C.window_estimates(self.h, np.zeros(2), dev, self.k)       # theta~_i(t), t = 0..N-k
        self.M0, self.M1 = C.iv_moments(th, self.k)
        self.A_local, self.rho_local = C.identify(self.M0, self.M1)    # tau = 0 baseline (display only)
        self.anchor = th[C.N_DATA - self.k].copy()
        self.round = 0
        self.send_progress("consensus", 0)
        self.send_net("m", self.t, 0, np.concatenate([self.M0.ravel(), self.M1.ravel()]))
        self.phase = "consensus"

    def finish_identification(self):
        self.A_hat, self.rho = C.identify(self.M0, self.M1)
        self.P, self.fore_t = np.eye(2), C.N_DATA - self.k
        print("[station %d] A_hat after %d consensus rounds: ||A_hat - A||_F = %.4f (local only: %.4f), spectral radius %.4f"
              % (self.i + 1, C.TAU, np.linalg.norm(self.A_hat - C.A_TRUE), np.linalg.norm(self.A_local - C.A_TRUE), self.rho))

    def finish_step(self):
        self.send_status(self.t + 1)
        self.send_dispatch(self.t + 1)
        self.phase = "idle"

    def advance(self):
        if self.phase == "idle":
            if self.ticks:
                self.start_step(self.ticks.pop(0))
        elif self.phase == "wait_s":
            if self.gathered("s", self.t, 0):
                self.s = self.mix("s", self.t, 0, (2,))
                self.send_net("x", self.t, 0, self.x - self.alpha * self.s)
                self.phase = "wait_x"
        elif self.phase == "wait_x":
            if self.gathered("x", self.t, 0):
                self.x = self.mix("x", self.t, 0, (2,))                # x_i(t+1)
                if self.t == C.N_DATA - 1:
                    self.identification()
                else:
                    self.finish_step()
        elif self.phase == "consensus":
            if self.gathered("m", self.t, self.round):
                mixed = self.mix("m", self.t, self.round, (8,))
                self.M0, self.M1 = mixed[:4].reshape(2, 2), mixed[4:].reshape(2, 2)
                self.round += 1
                self.send_progress("consensus", self.round)
                if self.round < C.TAU:
                    self.send_net("m", self.t, self.round, mixed)
                else:
                    self.finish_identification()
                    self.finish_step()

    # ---------------------------------------------------------------- driving
    def drive(self):
        """The station is a command post. It does not drive."""
        self.left.setVelocity(0.0)
        self.right.setVelocity(0.0)

    def run(self):
        print("[station %d] %s watches the %s, h = %.2f, nearest neighbors = %s" % (
            self.i + 1, C.AGENCIES[self.i], C.SITES[self.i], self.h, [j + 1 for j in self.nbrs]))
        while self.rb.step(self.ts) != -1:
            self.poll()
            self.advance()
            self.drive()


if __name__ == "__main__":
    RendezvousRobot().run()
