"""
charging_robot.py
=================

Controller of the mobile charging robot (protos/DemoChargingRobot.proto).  The
robot is not an agent of Algorithm 1: it listens on the dispatch channel to the
iterates x_i(t) that the six stations send it by radio, and drives to their
mean with its two wheel motors.  Nothing is placed by the supervisor; the
wheels, casters and ground contact are simulated by the physics engine.

Tracking law (unicycle, GPS + IMU):
  * the target is the mean of the latest iterates, led by its estimated
    velocity over T_LEAD seconds, so the robot keeps pace with a moving target;
  * forward driving with speed proportional to the distance (plus the target's
    speed) and turn rate proportional to the heading error;
  * when the target is close and behind, the robot backs up instead of turning
    on the spot (with hysteresis), and inside STOP_RADIUS it stops: a
    differential-drive robot that chases a target inside its own footprint
    would otherwise spin in place;
  * acceleration and turn-rate limits keep the motion smooth.
"""
import math
import os
import sys

import numpy as np
from controller import Robot

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "lib"))
import rendezvous_common as C  # noqa: E402

K_V = 1.2            # 1/s, speed per metre of distance
K_W = 2.6            # 1/s, turn rate per radian of heading error
A_MAX = 0.8          # m/s^2
ALPHA_MAX = 3.0      # rad/s^2
T_LEAD = 0.6         # s, lead on the target's estimated velocity
STOP_RADIUS = 0.06   # m


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


class ChargingRobot:
    def __init__(self):
        self.rb = Robot()
        self.ts = int(self.rb.getBasicTimeStep())
        self.dt = self.ts / 1000.0
        self.left = self.rb.getDevice("left wheel")
        self.right = self.rb.getDevice("right wheel")
        for m in (self.left, self.right):
            m.setPosition(float("inf"))
            m.setVelocity(0.0)
        self.w_max_wheel = min(self.left.getMaxVelocity(), self.right.getMaxVelocity())
        self.gps = self.rb.getDevice("gps")
        self.imu = self.rb.getDevice("imu")
        self.gps.enable(self.ts)
        self.imu.enable(self.ts)
        self.rx = self.rb.getDevice("dispatch")
        self.rx.enable(self.ts)
        self.latest = {}             # station -> (t, x in paper units)
        self.target = None           # metres
        self.target_time = None
        self.target_key = -1         # step t of the last complete set of iterates
        self.v_est = np.zeros(2)     # m/s, estimated velocity of the target
        self.v = 0.0
        self.w = 0.0
        self.reverse = False

    def poll(self):
        """New target once per algorithm step: when all stations have reported step t
        (before that, whatever has arrived).  The velocity estimate uses whole steps."""
        changed = False
        while self.rx.getQueueLength() > 0:
            try:
                msg = C.unpack(self.rx.getString())
                if msg.get("kind") == "iterate":
                    self.latest[msg["i"]] = (msg["t"], np.array(msg["x"], dtype=float))
                    changed = True
            finally:
                self.rx.nextPacket()
        if not changed or not self.latest:
            return
        key = min(t for t, _ in self.latest.values()) if len(self.latest) == C.M else -1
        if self.target is not None and key >= 0 and key == self.target_key:
            return                                    # wait until every station has the next step
        new = np.mean([x for _, x in self.latest.values()], axis=0) * C.SCALE
        now = self.rb.getTime()
        if self.target is not None and key >= 0 and self.target_key >= 0:
            inst = (new - self.target) / max(now - self.target_time, 1e-3)
            self.v_est = 0.6 * self.v_est + 0.4 * inst
        self.target, self.target_time, self.target_key = new, now, key

    def control(self):
        if self.target is None:
            return 0.0, 0.0
        p = self.gps.getValues()
        yaw = self.imu.getRollPitchYaw()[2]
        if any(map(math.isnan, p)) or math.isnan(yaw):
            return 0.0, 0.0
        goal = self.target + T_LEAD * self.v_est
        e = goal - np.array(p[:2])
        dist = float(np.linalg.norm(e))
        speed_t = float(np.linalg.norm(self.v_est))
        if dist < STOP_RADIUS and speed_t < 0.02:
            return 0.0, 0.0
        err = wrap(math.atan2(e[1], e[0]) - yaw)
        # back up when the target is close and behind; hysteresis avoids chattering
        if not self.reverse and abs(err) > 2.2 and dist < 1.0:
            self.reverse = True
        elif self.reverse and (abs(err) < 1.6 or dist > 1.4):
            self.reverse = False
        if self.reverse:
            err_b = wrap(err - math.pi)
            v = -min(C.ROBOT_V_MAX, K_V * dist + speed_t) * max(0.0, math.cos(err_b))
            w = K_W * err_b
        else:
            v = min(C.ROBOT_V_MAX, K_V * dist + speed_t) * max(0.0, math.cos(err))
            w = K_W * err
        return v, max(-C.ROBOT_W_MAX, min(C.ROBOT_W_MAX, w))

    def drive(self, v_cmd, w_cmd):
        dv = max(-A_MAX * self.dt, min(A_MAX * self.dt, v_cmd - self.v))
        dw = max(-ALPHA_MAX * self.dt, min(ALPHA_MAX * self.dt, w_cmd - self.w))
        self.v += dv
        self.w += dw
        wl = (self.v - self.w * C.ROBOT_AXLE / 2.0) / C.ROBOT_WHEEL_RADIUS
        wr = (self.v + self.w * C.ROBOT_AXLE / 2.0) / C.ROBOT_WHEEL_RADIUS
        lim = self.w_max_wheel
        self.left.setVelocity(max(-lim, min(lim, wl)))
        self.right.setVelocity(max(-lim, min(lim, wr)))

    def run(self):
        print("[charging robot] waiting for the stations' iterates on channel %d" % C.CH_DISPATCH)
        while self.rb.step(self.ts) != -1:
            self.poll()
            self.drive(*self.control())


if __name__ == "__main__":
    ChargingRobot().run()
