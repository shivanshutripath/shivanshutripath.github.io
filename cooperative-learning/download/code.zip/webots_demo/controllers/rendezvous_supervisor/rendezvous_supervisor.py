"""
rendezvous_supervisor.py
========================

Supervisor of the Webots simulation of case study (A): a mobile charging robot
for disaster-response UAVs.  It plays the part of the *environment* and of the
*instrumentation*, never of an agent:

  * owns the latent deviations theta_i(t) of the six UAVs,
    theta_i(t+1) = A theta_i(t) + w_i(t), and flies UAV i at
    b_i(t) = p_i(t) + theta_i(t), where p_i(t) is the known route of UAV i
    (its lane of a search line that circles the site, see rendezvous_common);
  * is the stations' clock: every SUBSTEPS basic steps it starts algorithm step t;
  * during data collection (t < N) delivers to station i, and only to station i,
    a noisy position of UAV i, on channel 10 + i;
  * draws what no station can see: the true best position x*(t) (gold beam),
    each station's iterate x_i(t) (colored pin), the radio links and the
    telemetry links, and the head-up display (lib/rendezvous_hud.py);
  * records everything needed to audit and replay the run (see write_logs):
    run_config.json, steps.csv, stations.csv, summary.json;
  * while the stations track, flies the three UAVs that need service most
    (highest h_i) to the charging robot, one at a time: each lands on its pad,
    rides along while it charges, takes off and returns to its lane.  These
    flights are scenery: the latent model and x*(t) do not change.

The stations run Algorithm 1 themselves (rendezvous_robot.py), and the
charging robot drives itself (charging_robot.py, wheel physics), to the mean
of the iterates the stations radio to it.  Nothing of the algorithm and
nothing of the robot's motion lives here.

Environment variables:
    RV_DEMO_SEED       seed of the latent process and of the noise (default 2026)
    RV_DEMO_N, RV_DEMO_TRACK   data-collection length and tracking horizon
    RV_DEMO_OUT        folder for the logs (default output/last_run)
    RV_DEMO_BATCH=1    data collection: no HUD, no snapshots, no recharge
                       flights, quit as soon as the logs are written
    RV_DEMO_HUD=0      hide the head-up display
    RV_DEMO_MOVIE=1, RV_DEMO_SNAPSHOTS=1, RV_DEMO_AUTOQUIT=1
    RV_DEMO_TRAILS=0   no dotted trails of the UAVs and the charging robot
    RV_DEMO_SNAPDIR    folder for the snapshots (default output/)
"""
import csv
import json
import math
import os
import sys
import time

import numpy as np
from controller import Supervisor

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "lib"))
import rendezvous_common as C  # noqa: E402
import rendezvous_hud as H  # noqa: E402

SEED = int(os.environ.get("RV_DEMO_SEED", "2026"))
BATCH = os.environ.get("RV_DEMO_BATCH") == "1"

# One recharge visit, in seconds. Three UAVs do this, highest service rate first.
# The robot keeps driving: the UAV lands on the moving pad and rides along.
FLIGHT = [
    ("approach", 3.4),
    ("land", 2.4),
    ("charge", 3.2),
    ("takeoff", 2.0),
    ("return", 3.4),
]
CLOSING_SECONDS = 7.0
IDENT_DWELL = 8          # algorithm steps the HUD keeps "learning A" on screen after t = N


def smooth(s):
    s = max(0.0, min(1.0, s))
    return s * s * (3.0 - 2.0 * s)


def lookat(pos, target, up=(0.0, 0.0, 1.0)):
    """Axis-angle orientation of a Webots camera at pos looking at target."""
    x = np.array(target, float) - np.array(pos, float)
    x /= np.linalg.norm(x)
    y = np.cross(np.array(up, float), x)
    y /= np.linalg.norm(y)
    z = np.cross(x, y)
    R = np.column_stack([x, y, z])
    angle = math.acos(max(-1.0, min(1.0, (np.trace(R) - 1.0) / 2.0)))
    axis = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])
    n = float(np.linalg.norm(axis))
    if n < 1e-8:
        return [0.0, 0.0, 1.0, 0.0]
    axis /= n
    return [float(axis[0]), float(axis[1]), float(axis[2]), float(angle)]


# Three-quarter view from the south, 36 degrees up, aimed left of the scene
# centre: all six stations, every UAV lane and the charging robot's depot lie right
# of the 300-pixel HUD column, both in the 1280x720 movie frame and in the
# 1025x696 view of the Webots window (solved with Webots' horizontal field of
# view of 1.05 rad).  The intro eases from WIDE to NEAR.
WIDE_POS = np.array([0.0, -20.0, 14.6])
WIDE_TGT = np.array([-3.2, 0.0, -0.1])
NEAR_POS = np.array([0.0, -17.92, 12.92])
NEAR_TGT = np.array([-3.0, 0.0, -0.1])
# RV_DEMO_CAMERA="px,py,pz,tx,ty,tz" holds one fixed pose instead (e.g. for the paper's still)
if os.environ.get("RV_DEMO_CAMERA"):
    _c = [float(v) for v in os.environ["RV_DEMO_CAMERA"].split(",")]
    WIDE_POS = NEAR_POS = np.array(_c[:3])
    WIDE_TGT = NEAR_TGT = np.array(_c[3:6])


class Demo:
    def __init__(self):
        self.sv = Supervisor()
        self.ts = int(self.sv.getBasicTimeStep())
        assert self.ts == C.BASIC_TIME_STEP, "WorldInfo.basicTimeStep must equal rendezvous_common.BASIC_TIME_STEP"
        custom = self.sv.getCustomData() or ""
        env = os.environ.get
        self.batch = BATCH
        self.autoquit = self.batch or "autoquit" in custom or env("RV_DEMO_AUTOQUIT") == "1"
        self.snapshots = (not self.batch) and ("snapshots" in custom or env("RV_DEMO_SNAPSHOTS") == "1")
        self.movie = (not self.batch) and ("movie" in custom or env("RV_DEMO_MOVIE") == "1")
        self.flights_on = not self.batch
        self.hud_on = (not self.batch) and env("RV_DEMO_HUD", "1") != "0"
        self.trails = (not self.batch) and env("RV_DEMO_TRAILS", "1") != "0"
        self.recording = self.movie or self.snapshots
        self.direct_camera = True          # dropped as soon as the user moves the view (unless recording)
        self.cam_set = None

        out_root = os.path.normpath(os.path.join(HERE, "..", "..", "output"))
        self.media_dir = os.path.abspath(env("RV_DEMO_SNAPDIR") or out_root)
        os.makedirs(self.media_dir, exist_ok=True)
        self.log_dir = os.path.abspath(env("RV_DEMO_OUT") or os.path.join(out_root, "last_run"))
        os.makedirs(self.log_dir, exist_ok=True)
        self.movie_path = os.path.join(out_root, "disaster_response.mp4")

        self.snapshot_steps = {}
        self.snapshot_steps[8] = "01_start"
        self.snapshot_steps[max(9, C.N_DATA // 2)] = "02_data_collection"
        lost = min(C.T_TOTAL - 1, C.N_DATA + 4)
        self.snapshot_steps.setdefault(lost, "03_telemetry_lost")
        mid = min(C.T_TOTAL - 1, C.N_DATA + max(15, C.T_TRACK // 2))
        self.snapshot_steps.setdefault(mid, "04_forecast_tracking")

        self.emitter = self.sv.getDevice("emitter")
        self.status_rx = self.sv.getDevice("status")
        self.status_rx.enable(self.ts)

        # ---- scene nodes ----
        self.uav = [self.sv.getFromDef("UAV_%d" % i) for i in range(C.M)]
        self.uav_tr = [n.getField("translation") for n in self.uav]
        self.uav_rot = [n.getField("rotation") for n in self.uav]
        self.station = [self.sv.getFromDef("ROBOT_%d" % i) for i in range(C.M)]
        self.station_home = [(list(n.getField("translation").getSFVec3f()),
                              list(n.getField("rotation").getSFRotation())) for n in self.station]
        self.charger = self.sv.getFromDef("CHARGER")    # the charging robot; it drives itself
        self.driven = 0.0
        self.charger_last = None
        self.beads = [self.sv.getFromDef("PATH_%d" % k).getField("translation") for k in range(C.PATH_BEADS)]
        self.bead_n, self.last_bead = 0, None
        self.uav_beads = [
            [self.sv.getFromDef("UPATH_%d_%d" % (i, k)).getField("translation") for k in range(C.UAV_PATH_BEADS)]
            for i in range(C.M)]
        self.uav_bead_n = [0] * C.M
        self.uav_last = [None] * C.M
        self.flames, self.flame_home = self._fields("FLAME_%d", 8)
        self.smokes, self.smoke_home = self._fields("SMOKE_%d", 6)
        view = self.sv.getFromDef("VIEW")
        self.view_pos = view.getField("position")
        self.view_rot = view.getField("orientation")
        view.getField("fieldOfView").setSFFloat(1.05)
        self.est_tr = [self.sv.getFromDef("EST_%d" % i).getField("translation") for i in range(C.M)]
        self.xstar_tr = self.sv.getFromDef("XSTAR").getField("translation")
        self.net_pts = self.sv.getFromDef("NET_COORD").getField("point")
        self.sense_pts = self.sv.getFromDef("SENSE_COORD").getField("point")
        self.sense_alpha = self.sv.getFromDef("SENSE_MAT").getField("transparency")

        # ---- latent process ----
        self.rng = np.random.default_rng(SEED)
        self.theta = self.rng.standard_normal((C.M, 2)) * C.P0_STD
        self.t = 0                       # next algorithm step to start
        b0 = np.stack([C.tasking(i, 0) + self.theta[i] for i in range(C.M)])
        self.pos_prev = b0 * C.SCALE
        self.pos_cur = self.pos_prev.copy()
        self.alt = np.array([C.uav_altitude(i, 0) for i in range(C.M)])
        self.alt_target = self.alt.copy()
        self.yaw = np.zeros(C.M)

        # ---- records (paper units) ----
        self.xstar_hist = {}             # t -> x*(t)
        self.theta_hist = {}             # t -> theta(t), (M, 2)
        self.route_hist = {}             # t -> p(t), (M, 2)
        self.tel_hist = {}               # t -> telemetry delivered, (M, 2), t < N
        self.charger_hist = {}           # t -> charging station position when step t starts
        self.x_hist = [{0: np.zeros(2)} for _ in range(C.M)]   # x_i(t); x_i(0) = 0
        self.fc_hist = [{} for _ in range(C.M)]                  # forecast theta_hat_i(t), t >= N
        self.status = {}
        self.stage = None                # identification progress shown on the HUD
        self.round = 0
        self.t_plotted = -1
        self.ident_seen_at = None

        self.phase = "run"
        self.b = 0
        self.charge_order = list(np.argsort(-np.asarray(C.PRIORITIES)))[:3]
        self.charge_i = 0 if self.flights_on else len(self.charge_order)
        self.flight = None
        self.swap_shots = set()
        self.close_b0 = None
        self.movie_started = False
        self.movie_stopped = False
        self.encode_b0 = None
        self.wall_t0 = time.time()
        self.final = None

        self.hud = H.Hud(self.sv, C, C.T_TOTAL) if self.hud_on else None
        if not self.hud_on and not self.batch:
            H.clear_displays(self.sv)     # an unused overlay would otherwise show as a black box
        self.clear_old_labels()

    def _fields(self, pattern, n):
        fields, homes = [], []
        for k in range(n):
            node = self.sv.getFromDef(pattern % k)
            if node is None:
                break
            f = node.getField("translation")
            fields.append(f)
            homes.append(list(f.getSFVec3f()))
        return fields, homes

    def clear_old_labels(self):
        """Older versions of this controller drew text labels; remove any left on screen."""
        for k in range(12):
            self.sv.setLabel(k, "", 0.0, 0.0, 0.03, 0x000000, 1.0, "Arial")

    # ------------------------------------------------------------------ steps
    def algorithm_step(self, t):
        """Advance the latent process to time t and hand out the measurements."""
        if t > 0:
            self.theta = self.theta @ C.A_TRUE.T + self.rng.standard_normal((C.M, 2)) * C.Q_STD
        route = np.stack([C.tasking(i, t) for i in range(C.M)])
        b = route + self.theta
        self.theta_hist[t] = self.theta.copy()
        self.route_hist[t] = route
        self.xstar_hist[t] = C.vehicle_point(self.theta, t)
        self.charger_hist[t] = np.array(self.charger.getPosition()[:2], dtype=float) / C.SCALE
        self.pos_prev, self.pos_cur = self.pos_cur, b * C.SCALE
        self.alt_target = np.array([C.uav_altitude(i, t) for i in range(C.M)])
        tel = np.full((C.M, 2), np.nan)
        for i in range(C.M):
            self.emitter.setChannel(C.CH_TELEMETRY_BASE + i)
            if t < C.N_DATA:
                y = b[i] + self.rng.standard_normal(2) * C.SENSOR_STD
                tel[i] = y
                self.emitter.send(C.pack(kind="tick", t=t, y=[float(y[0]), float(y[1])]))
            else:
                self.emitter.send(C.pack(kind="tick", t=t, y=None))
        self.tel_hist[t] = tel

    def read_status(self):
        while self.status_rx.getQueueLength() > 0:
            try:
                msg = C.unpack(self.status_rx.getString())
                kind = msg.get("kind")
                if kind == "status":
                    i = msg["i"]
                    self.status[i] = msg
                    self.x_hist[i][msg["t"]] = np.array(msg["x"], dtype=float)
                    if "fc" in msg:
                        self.fc_hist[i][msg["fc_t"]] = np.array(msg["fc"], dtype=float)
                elif kind == "progress":
                    self.stage = msg["stage"]
                    self.round = max(self.round, int(msg["r"]))
            finally:
                self.status_rx.nextPacket()

    def t_known(self):
        """Largest t such that every station has reported x_i(t)."""
        return min(max(h) for h in self.x_hist)

    def identified(self):
        return all(self.status.get(i, {}).get("A") is not None for i in range(C.M))

    def watch_charger(self):
        """The charging robot drives itself; record how far it went and leave its track."""
        cur = np.array(self.charger.getPosition()[:2], dtype=float)
        if self.charger_last is not None:
            self.driven += float(np.linalg.norm(cur - self.charger_last))
        self.charger_last = cur
        if self.trails:
            self.drop_bead(cur)

    def drop_bead(self, cur):
        """Ground track of the charging robot: a ring buffer of dots (the last few metres)."""
        if self.last_bead is not None and float(np.linalg.norm(cur - self.last_bead)) < C.PATH_SPACING:
            return
        self.beads[self.bead_n % len(self.beads)].setSFVec3f([float(cur[0]), float(cur[1]), 0.05])
        self.bead_n += 1
        self.last_bead = np.array(cur, dtype=float)

    def drop_uav_trails(self):
        """Recent path of each UAV: a ring buffer of dots in its color (about one lap)."""
        for i in range(C.M):
            p = np.array(self.uav_tr[i].getSFVec3f()[:2], dtype=float)
            last = self.uav_last[i]
            if last is not None and float(np.linalg.norm(p - last)) < C.UAV_PATH_SPACING:
                continue
            k = self.uav_bead_n[i] % C.UAV_PATH_BEADS
            self.uav_beads[i][k].setSFVec3f([float(p[0]), float(p[1]), 0.04 + 0.004 * i])
            self.uav_bead_n[i] += 1
            self.uav_last[i] = p

    def flicker_fire(self):
        """The hall is burning: flames jump and the smoke column drifts."""
        s = self.b * self.ts / 1000.0
        for k, (field, home) in enumerate(zip(self.flames, self.flame_home)):
            hop = 0.05 * math.sin(s * 9.0 + k * 1.7) + 0.02 * math.sin(s * 23.0 + k)
            field.setSFVec3f([home[0], home[1] + 0.02 * math.sin(s * 5.0 + k), home[2] + hop])
        for k, (field, home) in enumerate(zip(self.smokes, self.smoke_home)):
            rise = (s * 0.15 + k * 0.4) % 1.6
            field.setSFVec3f([
                home[0] + 0.12 * math.sin(s * 0.7 + k),
                home[1] + 0.08 * math.cos(s * 0.5 + k),
                home[2] + rise])

    def camera(self):
        """Ease from the wide to the near view, then hold it.  If the user moves
        the view in the Webots window, stop directing it (unless recording)."""
        if not self.direct_camera or self.batch:
            return
        if self.cam_set is not None and not self.recording:
            pos_now = self.view_pos.getSFVec3f()
            if max(abs(a - b) for a, b in zip(pos_now, self.cam_set)) > 1e-4:
                self.direct_camera = False
                return
        if self.phase in ("closing", "done") and self.close_b0 is not None:
            u = 1.0 - smooth((self.b - self.close_b0) * self.ts / 1000.0 / 3.5)
        else:
            u = smooth((self.b * self.ts / 1000.0 - 6.0) / 9.0)
        pos = WIDE_POS + u * (NEAR_POS - WIDE_POS)
        tgt = WIDE_TGT + u * (NEAR_TGT - WIDE_TGT)
        self.cam_set = [float(pos[0]), float(pos[1]), float(pos[2])]
        self.view_pos.setSFVec3f(self.cam_set)
        self.view_rot.setSFRotation(lookat(pos, tgt))

    # ---------------------------------------------------------------- metrics
    def errors_at(self, t):
        """(rms of ||x_i(t) - x*(t)||, ||charging station - x*(t)||, disagreement), paper units."""
        if t not in self.xstar_hist or any(t not in h for h in self.x_hist):
            return None
        X = np.stack([h[t] for h in self.x_hist])
        xs = self.xstar_hist[t]
        track = float(math.sqrt(np.mean(np.sum((X - xs) ** 2, axis=1))))
        dis = float(math.sqrt(np.mean(np.sum((X - X.mean(axis=0)) ** 2, axis=1))))
        ch = self.charger_hist.get(t)
        charger = None if ch is None else float(np.linalg.norm(ch - xs))
        return track, charger, dis

    def id_errors(self):
        idc = [self.status[i].get("id_coop") for i in range(C.M) if i in self.status]
        idl = [self.status[i].get("id_local") for i in range(C.M) if i in self.status]
        return [v for v in idc if v is not None], [v for v in idl if v is not None]

    # ---------------------------------------------------------------- logging
    def write_logs(self):
        """Everything analyze_runs.py needs to audit and replay this run."""
        T = C.T_TOTAL
        cfg = {
            "seed": SEED, "m": C.M, "N": C.N_DATA, "T_track": C.T_TRACK, "T_total": T,
            "k": C.K_WINDOW, "tau": C.TAU, "alpha": C.ALPHA, "rho_max": C.RHO_MAX,
            "A": C.A_TRUE.tolist(), "q_std": C.Q_STD, "p0_std": C.P0_STD, "sensor_std": C.SENSOR_STD,
            "h": list(C.PRIORITIES), "slots": C.SLOTS.tolist(),
            "patrol_radius": C.PATROL_RADIUS, "patrol_period": C.PATROL_PERIOD, "patrol_sign": C.PATROL_SIGN,
            "edges": [[a + 1, b + 1] for a, b in C.edges()],
            "W": [[C.metropolis_row(i).get(j, 0.0) for j in range(C.M)] for i in range(C.M)],
            "agencies": C.AGENCIES, "sites": C.SITES,
            "scale_m_per_unit": C.SCALE, "basic_time_step_ms": self.ts, "substeps": C.SUBSTEPS,
            "units": "paper units (the paper reads one unit as 10 m; the diorama draws it as %.2f m)" % C.SCALE,
        }
        W = np.array(cfg["W"])
        cfg["sigma"] = float(np.linalg.norm(W - np.ones((C.M, C.M)) / C.M, 2))
        with open(os.path.join(self.log_dir, "run_config.json"), "w") as f:
            json.dump(cfg, f, indent=1)

        head = ["t", "phase", "xs_1", "xs_2"]
        for i in range(1, C.M + 1):
            head += ["x%d_1" % i, "x%d_2" % i, "th%d_1" % i, "th%d_2" % i, "p%d_1" % i, "p%d_2" % i,
                     "y%d_1" % i, "y%d_2" % i, "f%d_1" % i, "f%d_2" % i]
        head += ["c_1", "c_2"]

        def fmt(v):
            return "" if v is None or not np.isfinite(v) else repr(float(v))

        with open(os.path.join(self.log_dir, "steps.csv"), "w", newline="") as f:
            wr = csv.writer(f)
            wr.writerow(head)
            for t in range(T):
                row = [t, "collect" if t < C.N_DATA else "track"]
                row += [fmt(v) for v in self.xstar_hist[t]]
                for i in range(C.M):
                    x = self.x_hist[i].get(t)
                    row += [fmt(None if x is None else x[0]), fmt(None if x is None else x[1])]
                    row += [fmt(v) for v in self.theta_hist[t][i]]
                    row += [fmt(v) for v in self.route_hist[t][i]]
                    row += [fmt(v) for v in self.tel_hist[t][i]]
                    fc = self.fc_hist[i].get(t)
                    row += [fmt(None if fc is None else fc[0]), fmt(None if fc is None else fc[1])]
                row += [fmt(v) for v in self.charger_hist[t]]
                wr.writerow(row)

        with open(os.path.join(self.log_dir, "stations.csv"), "w", newline="") as f:
            wr = csv.writer(f)
            wr.writerow(["i", "agency", "h", "neighbors", "a11", "a12", "a21", "a22", "l11", "l12", "l21", "l22",
                         "rho_coop", "rho_local", "id_coop", "id_local", "msgs_sent", "floats_sent", "bytes_sent",
                         "msgs_x", "msgs_s", "msgs_m", "floats_x", "floats_s", "floats_m"])
            for i in range(C.M):
                st = self.status[i]
                sent = st["sent"]
                wr.writerow([i + 1, C.AGENCIES[i], C.PRIORITIES[i], " ".join(str(j + 1) for j in C.neighbors(i))]
                            + [repr(v) for v in st["A"]] + [repr(v) for v in st["Al"]]
                            + [st["rho"], st["rho_l"], st["id_coop"], st["id_local"],
                               st["msgs"], st["reals"], st["nbytes"],
                               sent["x"][0], sent["s"][0], sent["m"][0], sent["x"][1], sent["s"][1], sent["m"][1]])

        # headline numbers (the full analysis is tools/analyze_runs.py)
        N = C.N_DATA
        lo, hi = N + 50, min(N + 200, T)
        errs = [self.errors_at(t) for t in range(T)]
        track = np.array([e[0] if e else np.nan for e in errs])
        window = track[lo:hi] if hi > lo else track[N:]
        idc, idl = self.id_errors()
        summary = {
            "seed": SEED, "N": N, "T_total": T,
            "id_err_coop_mean": float(np.mean(idc)), "id_err_local_mean": float(np.mean(idl)),
            "id_ratio_local_over_coop": float(np.mean(idl) / max(np.mean(idc), 1e-12)),
            "tracking_rmse_window": float(np.sqrt(np.nanmean(window ** 2))),
            "tracking_window": [lo, hi],
            "tracking_rmse_outage": float(np.sqrt(np.nanmean(track[N:] ** 2))),
            "reals_sent_per_station": [int(self.status[i]["reals"]) for i in range(C.M)],
            "msgs_sent_per_station": [int(self.status[i]["msgs"]) for i in range(C.M)],
            "charging_robot_driven_m": self.driven,
            "wall_clock_s": time.time() - self.wall_t0,
            "simulated_s": self.b * self.ts / 1000.0,
        }
        with open(os.path.join(self.log_dir, "summary.json"), "w") as f:
            json.dump(summary, f, indent=1)
        self.final = summary

        if not self.batch:   # the short table older versions wrote, kept for existing scripts
            with open(os.path.join(self.media_dir, "last_run.csv"), "w", newline="") as f:
                wr = csv.writer(f)
                wr.writerow(["t", "xstar_1", "xstar_2", "track_err_units", "disagreement_units",
                             "charger_to_xstar_units", "id_err_coop_mean", "id_err_local_mean"])
                for t in range(T):
                    e = errs[t]
                    wr.writerow([t, "%.5f" % self.xstar_hist[t][0], "%.5f" % self.xstar_hist[t][1],
                                 "" if not e else "%.5f" % e[0], "" if not e else "%.5f" % e[2],
                                 "" if not e or e[1] is None else "%.4f" % e[1],
                                 "" if t < N else "%.5f" % np.mean(idc), "" if t < N else "%.5f" % np.mean(idl)])

    def summary_print(self):
        s = self.final
        print("[supervisor] horizon done.  logs: %s" % self.log_dir)
        print("[supervisor] ||A_hat - A||_F  cooperative mean %.4f   local-only mean %.4f   (%.1fx)"
              % (s["id_err_coop_mean"], s["id_err_local_mean"], s["id_ratio_local_over_coop"]))
        print("[supervisor] tracking RMSE over t in [%d, %d): %.3f units;  over the whole outage: %.3f units"
              % (s["tracking_window"][0], s["tracking_window"][1], s["tracking_rmse_window"], s["tracking_rmse_outage"]))
        print("[supervisor] each station sent %s reals in %s messages; wall clock %.1f s"
              % (sorted(set(s["reals_sent_per_station"])), sorted(set(s["msgs_sent_per_station"])), s["wall_clock_s"]))

    # -------------------------------------------------------------------- HUD
    def hud_phase(self, t_disp):
        if self.phase in ("closing", "done"):
            return "done"
        if t_disp < C.N_DATA:
            return "collect"
        if not self.identified():
            return "identify"
        if self.ident_seen_at is None:
            self.ident_seen_at = t_disp
        return "identify" if t_disp < self.ident_seen_at + IDENT_DWELL else "track"

    def update_hud(self, force=False):
        if self.hud is None:
            return
        tk = self.t_known()
        # chart: one new point per algorithm step known to every station
        while self.t_plotted + 1 <= min(tk, C.T_TOTAL - 1):
            t = self.t_plotted + 1
            e = self.errors_at(t)
            if e is None:
                break
            self.hud.chart_add(t, {"track": e[0], "charger": e[1], "dis": e[2]})
            self.t_plotted = t
        if not force and self.b % C.SUBSTEPS != 1:
            return
        t_disp = min(tk, C.T_TOTAL)
        phase = self.hud_phase(t_disp)
        idc, idl = self.id_errors()
        # three lines of at most ~38 characters (300-pixel panel)
        if phase == "collect":
            lines = ["Station i reads only UAV i (yellow)",
                     "and radios its 2 neighbors (white).",
                     "The robot drives to their mean."]
        elif phase == "identify":
            lines = ["Telemetry lost at t = N.",
                     "%d rounds of averaging 2×2 moments:" % C.TAU,
                     "every station learns the same A."]
        elif phase == "track":
            lines = ["No station sees its UAV any more.",
                     "Each forecasts its own with its A;",
                     "the robot drives to their mean."]
            if self.flight is not None:
                i = self.flight["i"]
                name = FLIGHT[self.flight["seg"]][0]
                who = "The %s UAV" % C.AGENCIES[i]
                second = {"approach": "flies to the charging robot,",
                          "land": "lands on the moving robot,",
                          "charge": "charges while the robot drives,",
                          "takeoff": "takes off from the robot,",
                          "return": "returns to its lane."}[name]
                lines = [who, second, "Scenery only: x*(t) is unchanged."]
        else:
            s = self.final or {}
            lines = ["Done: %d steps without telemetry." % C.T_TRACK,
                     "Tracking RMSE %.2f units." % s.get("tracking_rmse_window", float("nan")),
                     "A learned %.1f× better together." % s.get("id_ratio_local_over_coop", float("nan"))]
        self.hud.draw_top(t_disp, self.b * self.ts / 1000.0, phase, lines)
        rows = []
        for i in range(C.M):
            st = self.status.get(i, {})
            rows.append(dict(live=t_disp < C.N_DATA, coop=st.get("id_coop"), local=st.get("id_local")))
        reals = max([int(self.status[i].get("reals", 0)) for i in self.status] or [0])
        if self.identified():
            summ = dict(stage="done", coop=float(np.mean(idc)), local=float(np.mean(idl)),
                        ratio=float(np.mean(idl) / max(np.mean(idc), 1e-12)), reals=reals)
        elif self.stage == "consensus":
            summ = dict(stage="consensus", round=self.round, reals=reals)
        else:
            summ = dict(stage=None, reals=reals)
        self.hud.draw_side(rows, t_disp, summ)

    # ---------------------------------------------------------------- scene
    def place_uav(self, i, p, yaw):
        self.uav_tr[i].setSFVec3f([float(p[0]), float(p[1]), float(p[2])])
        self.uav_rot[i].setSFRotation([0, 0, 1, float(yaw)])

    def pin_stations(self):
        """Command posts stand still."""
        for n, (tr, rot) in zip(self.station, self.station_home):
            n.getField("translation").setSFVec3f(tr)
            n.getField("rotation").setSFRotation(rot)
            n.resetPhysics()

    def update_scene(self, move_uavs=True, skip=()):
        if move_uavs:
            frac = 1.0 if self.t >= C.T_TOTAL else ((self.b % C.SUBSTEPS) + 1) / C.SUBSTEPS
            self.alt += 0.035 * (self.alt_target - self.alt)
            for i in range(C.M):
                if i in skip:
                    continue
                p = self.pos_prev[i] + frac * (self.pos_cur[i] - self.pos_prev[i])
                v = self.pos_cur[i] - self.pos_prev[i]
                if np.linalg.norm(v) > 1e-3:
                    self.yaw[i] = math.atan2(v[1], v[0])
                self.place_uav(i, [p[0], p[1], self.alt[i]], self.yaw[i])
        if self.xstar_hist:
            xs = self.xstar_hist[max(self.xstar_hist)] * C.SCALE
            self.xstar_tr.setSFVec3f([float(xs[0]), float(xs[1]), 0.0])
        for i in range(C.M):
            rp = self.station[i].getPosition()
            self.net_pts.setMFVec3f(i, [rp[0], rp[1], C.MAST_TOP_Z])
            up = self.uav_tr[i].getSFVec3f()
            self.sense_pts.setMFVec3f(2 * i, [rp[0], rp[1], C.MAST_TOP_Z])
            self.sense_pts.setMFVec3f(2 * i + 1, [up[0], up[1], up[2] - 0.08])
            if i in self.status:
                e = np.array(self.status[i]["x"]) * C.SCALE
                self.est_tr[i].setSFVec3f([float(e[0]), float(e[1]), 0.0])
        sensing = self.phase == "run" and (self.t - 1) < C.N_DATA
        self.sense_alpha.setSFFloat(0.15 if sensing else 1.0)

    # --------------------------------------------------------------- recharge
    def charge_time(self, k):
        marks = (C.T_TRACK // 5, C.T_TRACK // 2, (7 * C.T_TRACK) // 10)
        return C.N_DATA + max(15, marks[k])

    def dock_world(self):
        """Where a landed UAV sits: on the pad of the charging robot, which keeps driving."""
        p = np.array(self.charger.getPosition(), dtype=float)
        R = np.array(self.charger.getOrientation(), dtype=float).reshape(3, 3)
        return p + R @ C.PAD_LOCAL + np.array([0.0, 0.0, C.UAV_PAD_CLEARANCE])

    def charger_forward_yaw(self):
        m = self.charger.getOrientation()
        return math.atan2(m[3], m[0])

    def seg_goal(self, i, name, origin):
        dock = self.dock_world()
        cruise = C.uav_altitude(i, 0)
        if name in ("approach", "takeoff"):
            return np.array([dock[0], dock[1], cruise])
        if name in ("land", "charge"):
            return dock
        if name == "return":
            q = self.pos_cur[i]
            return np.array([q[0], q[1], cruise])
        return origin.copy()

    def maybe_start_flight(self):
        if self.flight is not None or self.charge_i >= len(self.charge_order):
            return
        if self.t <= self.charge_time(self.charge_i):
            return
        i = int(self.charge_order[self.charge_i])
        self.flight = {"i": i, "which": self.charge_i, "seg": 0, "b0": self.b,
                       "origin": np.array(self.uav_tr[i].getSFVec3f(), dtype=float)}
        self.charge_i += 1
        print("[supervisor] %s UAV (h = %.1f) flies to the charging robot" % (C.AGENCIES[i], C.PRIORITIES[i]))

    def advance_flight(self):
        f = self.flight
        i = f["i"]
        name, dur = FLIGHT[f["seg"]]
        elapsed = (self.b - f["b0"]) * self.ts / 1000.0
        goal = self.seg_goal(i, name, f["origin"])
        s = smooth(elapsed / dur) if dur else 1.0
        p = goal if name == "charge" else f["origin"] + s * (goal - f["origin"])
        if name in ("land", "charge", "takeoff"):
            yaw = self.charger_forward_yaw()
        else:
            d = goal - f["origin"]
            yaw = math.atan2(d[1], d[0]) if np.linalg.norm(d[:2]) > 0.05 else self.yaw[i]
        self.yaw[i] = yaw
        self.place_uav(i, p, yaw)
        if name == "charge" and elapsed > 0.45 * dur and f["which"] not in self.swap_shots:
            self.swap_shots.add(f["which"])
            if f["which"] < 2:
                self.snapshot("05_fire_charging" if f["which"] == 0 else "06_rescue_charging")
        if elapsed < dur:
            return
        if f["seg"] < len(FLIGHT) - 1:
            f["seg"] += 1
            f["b0"] = self.b
            f["origin"] = np.array(self.uav_tr[i].getSFVec3f(), dtype=float)
            return
        print("[supervisor] %s UAV back on its route" % C.AGENCIES[i])
        self.flight = None

    def begin_closing(self):
        self.write_logs()
        self.summary_print()
        if self.batch:
            self.phase = "done"
            return
        self.phase = "closing"
        self.close_b0 = self.b
        self.update_hud(force=True)   # drawn on the next step; the closing snapshot waits 1.5 s

    # ------------------------------------------------------------------- movie
    def start_movie(self):
        if self.movie and not self.movie_started and self.sv.movieIsReady():
            # 2x: the data collection stays on screen long enough to read.
            self.sv.movieStartRecording(self.movie_path, 1280, 720, 0, 85, 2, False)
            self.movie_started = True
            print("[supervisor] recording %s at 2x" % self.movie_path)

    def finish_movie(self):
        """Stop the recording and wait until the file is encoded.  True when done."""
        if not self.movie:
            return True
        if not self.movie_started:
            print("[supervisor] movie was requested but recording never became ready")
            return True
        if not self.movie_stopped:
            self.sv.movieStopRecording()
            self.movie_stopped = True
            self.encode_b0 = self.b
            print("[supervisor] encoding the movie...")
            return False
        if self.sv.movieIsReady():
            print("[supervisor] movie %s: %s" % ("encoding FAILED" if self.sv.movieFailed() else "written",
                                                 self.movie_path))
            return True
        if self.encode_b0 is not None and (self.b - self.encode_b0) * self.ts > 600000:
            print("[supervisor] movie encoding still running after 600 s of simulated time; giving up")
            return True
        return False

    def snapshot(self, tag):
        if self.snapshots:
            path = os.path.join(self.media_dir, "snapshot_%s.png" % tag)
            self.sv.exportImage(path, 100)
            print("[supervisor] snapshot %s" % os.path.basename(path))

    # ------------------------------------------------------------------- main
    def run(self):
        print("[supervisor] seed %d, N = %d, T = %d, %.2f s per algorithm step%s" % (
            SEED, C.N_DATA, C.T_TOTAL, C.SUBSTEPS * self.ts / 1000.0, ", batch" if self.batch else ""))
        if self.flights_on:
            order = ", ".join("%s (h=%.1f) at step %d" % (C.AGENCIES[int(i)], C.PRIORITIES[int(i)], self.charge_time(k))
                              for k, i in enumerate(self.charge_order))
            print("[supervisor] recharge order: %s" % order)
        while self.sv.step(self.ts) != -1:
            self.start_movie()
            self.read_status()
            self.pin_stations()
            self.watch_charger()
            self.camera()
            if not self.batch:
                self.flicker_fire()
            if self.phase == "run":
                if self.b % C.SUBSTEPS == 0 and self.t < C.T_TOTAL:
                    self.algorithm_step(self.t)
                    self.t += 1
                self.maybe_start_flight()
                flying = () if self.flight is None else (self.flight["i"],)
                if not self.batch:
                    self.update_scene(True, skip=flying)
                if self.flight is not None:
                    self.advance_flight()
                self.update_hud()
                if self.b % C.SUBSTEPS == C.SUBSTEPS - 1 and (self.t - 1) in self.snapshot_steps:
                    self.snapshot(self.snapshot_steps[self.t - 1])
                horizon_done = self.t >= C.T_TOTAL and self.t_known() >= C.T_TOTAL
                if horizon_done and self.flight is None and self.charge_i >= len(self.charge_order):
                    self.begin_closing()
            elif self.phase == "closing":
                self.update_scene(True)
                self.update_hud()
                held = (self.b - self.close_b0) * self.ts / 1000.0
                if held >= 1.5 and "07" not in self.swap_shots:
                    self.swap_shots.add("07")
                    self.snapshot("07_back_on_watch")
                if held >= CLOSING_SECONDS:
                    self.phase = "done"
            else:
                if not self.batch:
                    self.update_scene(True)
                if self.finish_movie() and self.autoquit:
                    self.sv.simulationQuit(0)
                    return
            if self.trails:
                self.drop_uav_trails()
            self.b += 1


if __name__ == "__main__":
    Demo().run()
