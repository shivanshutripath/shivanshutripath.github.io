"""
charging_vehicle.py
===================

Drives the charging vehicle to the position the six agency stations have
agreed on.  The vehicle is not an agent: it never sees a UAV and never joins
the consensus.  The supervisor sends the mean of the stations' iterates on
channel 3, in metres, and this controller follows it (differential drive,
GPS + IMU).
"""
import math
import os
import sys

import numpy as np
from controller import Robot

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "lib"))
import rendezvous_common as C  # noqa: E402

WHEEL_RADIUS = 0.14
AXLE = 0.80          # distance between the driven wheels (m), anchors at y = +/-0.40
V_MAX = 1.35         # m/s
W_MAX = 1.8          # rad/s
K_V, K_W = 1.3, 2.6
GOAL_TOL = 0.10      # m


class ChargingVehicle:
    def __init__(self):
        self.rb = Robot()
        self.ts = int(self.rb.getBasicTimeStep())
        self.left = self.rb.getDevice("left wheel")
        self.right = self.rb.getDevice("right wheel")
        for m in (self.left, self.right):
            m.setPosition(float("inf"))
            m.setVelocity(0.0)
        self.gps = self.rb.getDevice("gps")
        self.imu = self.rb.getDevice("imu")
        self.gps.enable(self.ts)
        self.imu.enable(self.ts)
        self.rx = self.rb.getDevice("orders")
        self.rx.enable(self.ts)
        self.goal = None

    def poll(self):
        while self.rx.getQueueLength() > 0:
            try:
                msg = C.unpack(self.rx.getString())
                if msg.get("kind") == "target":
                    self.goal = np.array([msg["x"], msg["y"]], dtype=float)
            finally:
                self.rx.nextPacket()

    def drive(self):
        if self.goal is None:
            return
        p = self.gps.getValues()
        yaw = self.imu.getRollPitchYaw()[2]
        if any(map(math.isnan, p)) or math.isnan(yaw):
            return
        d = self.goal - np.array(p[:2])
        dist = float(np.linalg.norm(d))
        if dist < GOAL_TOL:
            v = w = 0.0
        else:
            e = C.wrap_angle(math.atan2(d[1], d[0]) - yaw)
            v = min(V_MAX, K_V * dist) * max(0.15, math.cos(e)) if abs(e) < 1.2 else 0.0
            # creep forward even at a large heading error once nearly aligned,
            # but turn in place when the target is behind the cab
            if abs(e) >= 1.2:
                v = 0.0
            w = max(-W_MAX, min(W_MAX, K_W * e))
        wl = (v - w * AXLE / 2) / WHEEL_RADIUS
        wr = (v + w * AXLE / 2) / WHEEL_RADIUS
        lim = self.left.getMaxVelocity()
        self.left.setVelocity(max(-lim, min(lim, wl)))
        self.right.setVelocity(max(-lim, min(lim, wr)))

    def run(self):
        print("[truck] charging vehicle waiting for the stations' agreed position")
        while self.rb.step(self.ts) != -1:
            self.poll()
            self.drive()


if __name__ == "__main__":
    ChargingVehicle().run()
