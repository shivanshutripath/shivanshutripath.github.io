#!/usr/bin/env python3
"""
make_run.py -- regenerate the project page's data/run.js (window.RUN) from the
logs of the Webots run that was recorded as the page's 3D web animation:

    webots_demo/output/web_animation/logs/{run_config.json, steps.csv, stations.csv, summary.json}
    PAGE/webots/disaster_response.json   (the web animation; only for the frame map
                                          and the recharge-flight paths)
    PAGE/webots/disaster_response.w3d    (the scene; only for the footprints of the top view)

    python3 tools/make_run.py PAGE [--out FILE] [--check]

PAGE is the folder of the project page (cooperative-learning/); the file is
written to PAGE/data/run.js unless --out names another one.

Units: paper units (the paper reads one unit as 10 m; the Webots diorama draws a
unit as 0.5 m).  b_i(t) = p_i(t) + theta_i(t) (UAV position), fp_i(t) = p_i(t) + f_i(t)
(forecast UAV position, t >= N).  Every derived number is checked against
summary.json and stations.csv before the file is written.

err.track is the stations' RMS distance to x*(t) in the run (they learn A
together, tau = 3); err.local is the same distance had every station learned A
alone (tau = 0): the gradient-tracking recursion replayed on the same telemetry
with the stations' own local estimates, by replay() of analyze_runs.py, which
first reproduces the logged iterates from the estimates they learned together.
"""
import argparse
import csv
import json
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import analyze_runs  # noqa: E402  (replay of Algorithm 1 on the recorded telemetry)

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # webots_demo/
LOGS = os.path.join(PROJ, "output", "web_animation", "logs")
_ap = argparse.ArgumentParser(description="Write the project page's data/run.js from the logs of the recorded run.")
_ap.add_argument("page", help="the folder of the project page (cooperative-learning/)")
_ap.add_argument("--out", help="the file to write (default: PAGE/data/run.js)")
_ap.add_argument("--check", action="store_true", help="run the checks only; write nothing")
ARGS = _ap.parse_args()
PAGE = os.path.abspath(ARGS.page)
ANIM = os.path.join(PAGE, "webots", "disaster_response.json")
OUT = ARGS.out or os.path.join(PAGE, "data", "run.js")

AGENCIES = ["Police", "Fire", "Medical", "Search & rescue", "Utilities", "Civil protection"]
SCENE_M = 0.5                 # metres per paper unit in the diorama
UNIT_M = 10                   # metres per paper unit in the paper
FRAMES_PER_STEP = 10          # one algorithm step = 10 basic steps of 32 ms
UAV_IDS = [381, 441, 501, 561, 621, 681]
ROBOT_ID = 1107
BEAM_ID = 3729
PIN_IDS = [3738, 3747, 3756, 3765, 3774, 3783]
FLIGHT_SEGMENTS = [("approach", 3.4), ("land", 2.4), ("charge", 3.2), ("takeoff", 2.0), ("return", 3.4)]


def fnum(v, nd=4):
    if v is None or (isinstance(v, float) and not math.isfinite(v)):
        return None
    r = round(float(v), nd)
    return 0.0 if r == 0 else r


def sig(v, n=5):
    if v is None or not math.isfinite(v):
        return None
    if v == 0:
        return 0.0
    return float("%.*g" % (n, v))


def main():
    cfg = json.load(open(os.path.join(LOGS, "run_config.json")))
    summ = json.load(open(os.path.join(LOGS, "summary.json")))
    rows = list(csv.DictReader(open(os.path.join(LOGS, "steps.csv"))))
    srows = list(csv.DictReader(open(os.path.join(LOGS, "stations.csv"))))
    M, N, T = cfg["m"], cfg["N"], cfg["T_total"]
    assert len(rows) == T and M == 6

    def val(r, k):
        s = r[k]
        return float(s) if s != "" else None

    xs = np.array([[val(r, "xs_1"), val(r, "xs_2")] for r in rows])
    c = np.array([[val(r, "c_1"), val(r, "c_2")] for r in rows])
    X = np.array([[[val(r, "x%d_1" % i), val(r, "x%d_2" % i)] for i in range(1, M + 1)] for r in rows], dtype=float)
    TH = np.array([[[val(r, "th%d_1" % i), val(r, "th%d_2" % i)] for i in range(1, M + 1)] for r in rows], dtype=float)
    P = np.array([[[val(r, "p%d_1" % i), val(r, "p%d_2" % i)] for i in range(1, M + 1)] for r in rows], dtype=float)
    Y = np.array([[[val(r, "y%d_1" % i) if val(r, "y%d_1" % i) is not None else np.nan,
                    val(r, "y%d_2" % i) if val(r, "y%d_2" % i) is not None else np.nan] for i in range(1, M + 1)] for r in rows])
    Fc = np.array([[[val(r, "f%d_1" % i) if val(r, "f%d_1" % i) is not None else np.nan,
                     val(r, "f%d_2" % i) if val(r, "f%d_2" % i) is not None else np.nan] for i in range(1, M + 1)] for r in rows])
    B = P + TH
    FP = P + Fc
    phase = [r["phase"] for r in rows]

    # ---------------------------------------------------------------- checks against the logs
    h = np.array(cfg["h"])
    xs_check = (h[:, None] * B).sum(axis=1) / h.sum()
    assert np.abs(xs_check - xs).max() < 1e-9, "x*(t) is not the h-weighted mean of b_i(t)"
    track = np.sqrt(np.mean(np.sum((X - xs[:, None, :]) ** 2, axis=2), axis=1))
    dis = np.sqrt(np.mean(np.sum((X - X.mean(axis=1, keepdims=True)) ** 2, axis=2), axis=1))
    rob = np.linalg.norm(c - xs, axis=1)
    lo, hi = summ["tracking_window"]
    rmse = float(np.sqrt(np.mean(track[lo:hi] ** 2)))
    assert abs(rmse - summ["tracking_rmse_window"]) < 1e-12, (rmse, summ["tracking_rmse_window"])
    rmse_out = float(np.sqrt(np.mean(track[N:] ** 2)))
    assert abs(rmse_out - summ["tracking_rmse_outage"]) < 1e-12
    A = np.array(cfg["A"])
    Ahat = [np.array([[float(s["a11"]), float(s["a12"])], [float(s["a21"]), float(s["a22"])]]) for s in srows]
    Aloc = [np.array([[float(s["l11"]), float(s["l12"])], [float(s["l21"]), float(s["l22"])]]) for s in srows]
    idc = [float(s["id_coop"]) for s in srows]
    idl = [float(s["id_local"]) for s in srows]
    for i in range(M):
        assert abs(np.linalg.norm(Ahat[i] - A) - idc[i]) < 1e-12
        assert abs(np.linalg.norm(Aloc[i] - A) - idl[i]) < 1e-12
    assert abs(np.mean(idc) - summ["id_err_coop_mean"]) < 1e-15
    assert abs(np.mean(idl) - summ["id_err_local_mean"]) < 1e-15
    rho_c = [float(s["rho_coop"]) for s in srows]
    rho_l = [float(s["rho_local"]) for s in srows]
    rad_c = [float(np.max(np.abs(np.linalg.eigvals(a)))) for a in Ahat]
    rad_l = [float(np.max(np.abs(np.linalg.eigvals(a)))) for a in Aloc]
    for i in range(M):
        # the logged rho is the radius before the safeguard; the logged matrix is after it
        exp_c = min(rho_c[i], cfg["rho_max"])
        exp_l = min(rho_l[i], cfg["rho_max"])
        assert abs(rad_c[i] - exp_c) < 1e-9, (i, rad_c[i], rho_c[i])
        assert abs(rad_l[i] - exp_l) < 1e-9, (i, rad_l[i], rho_l[i])
    reals = [int(s["floats_sent"]) for s in srows]
    msgs = [int(s["msgs_sent"]) for s in srows]
    assert reals == summ["reals_sent_per_station"] and msgs == summ["msgs_sent_per_station"]
    # telemetry only before N, forecasts only from N on
    assert np.all(np.isfinite(Y[:N])) and np.all(np.isnan(Y[N:]))
    assert np.all(np.isnan(Fc[:N])) and np.all(np.isfinite(Fc[N:]))

    # ---------------------------------------------------------------- alone: each station with its own estimate
    wr = analyze_runs.Run(LOGS)
    est, anchors, _ = analyze_runs.reference_estimates(wr)
    assert np.abs(est["coop"][0] - np.array(Ahat)).max() < 1e-12, "together estimates differ from the reference code"
    assert np.abs(est["local"][0] - np.array(Aloc)).max() < 1e-12, "local estimates differ from the reference code"
    d_rep = np.abs(analyze_runs.replay(wr, np.array(Ahat), anchors) - X).max()
    assert d_rep < 1e-9, ("the replay does not reproduce the Webots iterates", d_rep)
    local = analyze_runs.error_series(wr, analyze_runs.replay(wr, np.array(Aloc), anchors))
    assert np.abs(local[:N] - track[:N]).max() < 1e-9, "alone and together must agree before t = N"
    rmse_local = float(np.sqrt(np.mean(local[lo:hi] ** 2)))
    assert abs(rmse_local - analyze_runs.tracking_rmse(wr, analyze_runs.replay(wr, np.array(Aloc), anchors),
                                                       lo - N, hi - N)) < 1e-12

    # ---------------------------------------------------------------- the web animation: frame map + flights
    anim = json.load(open(ANIM))
    frames = anim["frames"]
    nf = len(frames)
    track_ids = UAV_IDS + [ROBOT_ID, BEAM_ID] + PIN_IDS
    cur = {k: None for k in track_ids}
    tr = {k: np.full((nf, 3), np.nan) for k in track_ids}
    for k, f in enumerate(frames):
        for u in f.get("updates", []):
            if u["id"] in cur and "translation" in u:
                cur[u["id"]] = [float(s) for s in u["translation"].split()]
        for i in track_ids:
            if cur[i] is not None:
                tr[i][k] = cur[i]
    times = [f["time"] for f in frames]
    # beam: x*(t) from frame 10t to 10t+9
    beam = tr[BEAM_ID][:, :2] / SCENE_M
    for t in range(T):
        for k in range(10 * t, 10 * t + 10):
            assert np.linalg.norm(beam[k] - xs[t]) < 2e-4, ("beam", t, k)
    # pins: x_i(t) from frame 10t-6 to 10t+3 (t >= 2); x_i(N) only from frame 10N-3, after the
    # three consensus rounds on the moments that end step N-1
    for i in range(M):
        pin = tr[PIN_IDS[i]][:, :2] / SCENE_M
        for t in range(2, T):
            for k in range(10 * t - (3 if t == N else 6), 10 * t + 4):
                assert np.linalg.norm(pin[k] - X[t, i]) < 2e-4, ("pin", i, t, k)
    # robot: c(t) is the robot at frame 10t-1
    robot = tr[ROBOT_ID][:, :2] / SCENE_M
    d_rob = max(np.linalg.norm(robot[10 * t - 1] - c[t]) for t in range(1, T))
    assert d_rob < 2e-3, d_rob
    # UAVs: b_i(t) at frame 10t+9 unless the UAV is on a recharge flight
    U = np.stack([tr[k] for k in UAV_IDS])          # metres
    # Recharge flights, as rendezvous_supervisor.py schedules them: the three UAVs with the
    # highest h_i, one at a time; flight k starts on the first frame (= supervisor iteration)
    # on which the next step to start exceeds N + max(15, mark_k) and no flight is under way;
    # a segment of d seconds lasts ceil(1000 d / 32) frames.
    T_track = T - N
    marks = (T_track // 5, T_track // 2, (7 * T_track) // 10)
    charge_steps = [N + max(15, m) for m in marks]
    order = [int(i) for i in np.argsort(-h, kind="stable")[:3]]
    lane = np.full((M, nf, 2), np.nan)              # where each UAV is when it is not on a flight
    for k in range(nf):
        t = min(k // FRAMES_PER_STEP, T - 1)
        if k >= 10 * T - 10:
            lane[:, k] = B[T - 1]                    # after the last step every UAV snaps to b_i(T-1)
        elif t == 0:
            lane[:, k] = B[0]
        else:
            fr = ((k % 10) + 1) / 10.0
            lane[:, k] = B[t - 1] + fr * (B[t] - B[t - 1])
    flights = []
    busy_until = -1
    for n_f, i in enumerate(order):
        start = max(FRAMES_PER_STEP * charge_steps[n_f], busy_until + 1)
        segs, b0 = [], start
        for name, dur in FLIGHT_SEGMENTS:
            n = -(-int(round(dur * 1000)) // anim["basicTimeStep"])
            segs.append([name, b0, b0 + n])
            b0 += n
        end = b0
        busy_until = end
        dev = np.linalg.norm(U[i, :, :2] / SCENE_M - lane[i], axis=1)
        outside = np.r_[0:start, end + 1:10 * T - 10]
        bad = outside[dev[outside] > 5e-3]   # the recorder rounds translations (mm)
        assert len(bad) == 0, ("UAV off its lane outside its flight", i, bad[:10].tolist(), dev[bad[:10]].tolist())
        charge = segs[2]
        pad = np.array([np.linalg.norm(U[i, k, :2] - tr[ROBOT_ID][k, :2]) for k in range(charge[1], charge[2])])
        assert pad.max() < 0.12, ("not on the pad while charging", i, float(pad.max()))
        path = []
        for k in range(start, end + 1, 2):
            p = U[i, k]
            path.append([fnum(p[0] / SCENE_M, 3), fnum(p[1] / SCENE_M, 3), fnum(p[2], 3)])
        flights.append({"i": i, "agency": AGENCIES[i], "h": float(h[i]), "afterStep": charge_steps[n_f],
                        "frame0": start, "frame1": end, "every": 2,
                        "t0": start / FRAMES_PER_STEP, "t1": end / FRAMES_PER_STEP,
                        "segments": segs, "path": path})
    # the supervisor log: "fire (h=1.4) at step 140, search & rescue (h=1.2) at step 200, police (h=1.0) at step 240"
    assert [f["i"] for f in flights] == [1, 3, 0] and charge_steps == [140, 200, 240]

    end_frame = FRAMES_PER_STEP * (T - 1) + 9
    time_map = {
        "framesPerStep": FRAMES_PER_STEP, "msPerFrame": anim["basicTimeStep"], "frames": nf,
        "lastTimeMs": times[-1], "endFrame": end_frame,
        "stepOfFrame": "t = floor(frame / 10): the gold beam shows x*(t) on frames 10t .. 10t+9",
        "seekOffset": 1, "uavOffset": 9, "pinOffset": -6, "robotOffset": -1,
        "notes": ["frame k is shown at time 32 (k - 1) ms for k >= 1 (frames 0 and 1 are both at 0 ms), so frame 10t + 1 is at exactly t x 0.32 s",
                  "UAV i reaches b_i(t) on frame 10t + 9 (it flies from b_i(t-1) during frames 10t .. 10t+9), except on recharge flights",
                  "the pin of station i shows x_i(t) on frames 10t - 6 .. 10t + 3 (it is computed during step t - 1)",
                  "the charging robot is at c(t) on frame 10t - 1",
                  "frames after %d are the 7 s that close the run (nothing moves)" % end_frame],
        "ids": {"uav": UAV_IDS, "robot": ROBOT_ID, "beam": BEAM_ID, "pins": PIN_IDS},
    }

    station_xy = [[fnum(6.55 * math.cos(2 * math.pi * i / M) / SCENE_M, 3), fnum(6.55 * math.sin(2 * math.pi * i / M) / SCENE_M, 3)]
                  for i in range(M)]
    edges = [[a - 1, b - 1] for a, b in cfg["edges"]]
    neighbors = [[int(j) - 1 for j in s["neighbors"].split()] for s in srows]
    for i in range(M):
        assert sorted(neighbors[i]) == sorted([b if a == i else a for a, b in edges if i in (a, b)])

    def flat2(arr):
        out = []
        for v in arr.reshape(-1, 2):
            out += [fnum(v[0]), fnum(v[1])]
        return out

    # ---------------------------------------------------------------- scenery for the top view (from the w3d)
    import re
    w3d = open(os.path.join(PAGE, "webots", "disaster_response.w3d"), encoding="utf-8").read()
    w3d = re.sub(r"\s*docUrl='[^']*'", "", w3d)
    tufts = []
    for m in re.finditer(r"<Pose id='n\d+' translation='([^']*)'(?: rotation='[^']*')?><Shape id='n\d+'><PBRAppearance id='n\d+' "
                         r"baseColor='(0\.[23]\d* 0\.[5-7]\d* 0\.12)'[^>]*></PBRAppearance><Box id='n\d+' size='([^']*)'>", w3d):
        x, y, _ = [float(v) for v in m.group(1).split()]
        tufts.append([fnum(x / SCENE_M, 2), fnum(y / SCENE_M, 2)])

    def find(pattern):
        m = re.search(pattern, w3d)
        assert m, pattern
        return m

    scorch = find(r"<Pose id='n\d+' translation='([^']*)'><Shape id='n\d+'><PBRAppearance id='n\d+' baseColor='0\.55 0\.42 0\.18'[^>]*>"
                  r"</PBRAppearance><Cylinder id='n\d+' height='[^']*' radius='([^']*)'>")
    char = find(r"<Pose id='n\d+' translation='([^']*)'><Shape id='n\d+'><PBRAppearance id='n\d+' baseColor='0\.08 0\.05 0\.04'[^>]*>"
                r"</PBRAppearance><Cylinder id='n\d+' height='[^']*' radius='([^']*)'>")
    road = find(r"<Pose id='n\d+' translation='([^']*)'><Shape id='n\d+'><PBRAppearance id='n\d+' baseColor='0\.42 0\.36 0\.24'[^>]*>"
                r"</PBRAppearance><Box id='n\d+' size='([^']*)'>")
    pad = find(r"<Pose id='n\d+' translation='([^']*)'><Shape id='n\d+'><PBRAppearance id='n\d+' baseColor='0\.55 0\.48 0\.28'[^>]*>"
               r"</PBRAppearance><Box id='n\d+' size='([^']*)'>")
    ruins_at = [float(v) for v in find(r"<Pose id='n\d+' translation='([^']*)'><Pose id='n\d+' translation='[^']*'><Shape id='n\d+'>"
                                       r"<PBRAppearance id='n\d+' baseColor='0\.32 0\.2 0\.16'").group(1).split()]
    group = w3d[w3d.index("baseColor='0.32 0.2 0.16'") - 200:]
    group = group[:group.index("</Pose></Pose>\n") + 14] if "</Pose></Pose>\n" in group else group[:3000]
    ruins = []
    for m in re.finditer(r"<Pose id='n\d+' translation='([^']*)'(?: rotation='[^']*')?><Shape id='n\d+'><PBRAppearance id='n\d+' "
                         r"baseColor='([^']*)'[^>]*></PBRAppearance><Box id='n\d+' size='([^']*)'>", group):
        x, y, _ = [float(v) for v in m.group(1).split()]
        sx, sy, sz = [float(v) for v in m.group(3).split()]
        ruins.append([fnum((ruins_at[0] + x) / SCENE_M, 2), fnum((ruins_at[1] + y) / SCENE_M, 2),
                      fnum(sx / SCENE_M, 2), fnum(sy / SCENE_M, 2), fnum(sz, 2)])

    def rect(m):
        x, y, _ = [float(v) for v in m.group(1).split()]
        sx, sy, _ = [float(v) for v in m.group(2).split()]
        return [fnum(x / SCENE_M, 2), fnum(y / SCENE_M, 2), fnum(sx / SCENE_M, 2), fnum(sy / SCENE_M, 2)]

    def disk(m):
        x, y, _ = [float(v) for v in m.group(1).split()]
        return [fnum(x / SCENE_M, 2), fnum(y / SCENE_M, 2), fnum(float(m.group(2)) / SCENE_M, 2)]

    scene = {"ground": [-20, -20, 40, 40], "scorch": disk(scorch), "char": disk(char), "road": rect(road), "pad": rect(pad),
             "ruins": ruins, "tufts": tufts,
             "note": "top-view footprints from webots/disaster_response.w3d, paper units; rects are [cx, cy, w, h], disks [cx, cy, r]"}
    assert len(tufts) > 40 and len(ruins) >= 4, (len(tufts), len(ruins))

    run = {
        "seed": cfg["seed"], "N": N, "T": T, "dt": cfg["substeps"] * cfg["basic_time_step_ms"] / 1000.0,
        "unitM": UNIT_M, "sceneM": SCENE_M, "k": cfg["k"], "tau": cfg["tau"], "alpha": cfg["alpha"], "rhoMax": cfg["rho_max"],
        "agencies": AGENCIES, "sites": cfg["sites"], "h": [float(v) for v in h],
        "stations": station_xy, "edges": edges, "neighbors": neighbors,
        "W": [[fnum(v, 6) for v in row] for row in cfg["W"]], "sigma": fnum(cfg["sigma"], 6),
        "warehouse": [0.0, 0.7], "depot": [0.0, -14.8],
        "A": [[fnum(v, 6) for v in row] for row in A.tolist()],
        "idCoop": [sig(v) for v in idc], "idLocal": [sig(v) for v in idl],
        "Ahat": [[[fnum(v, 6) for v in row] for row in a.tolist()] for a in Ahat],
        "Alocal": [[[fnum(v, 6) for v in row] for row in a.tolist()] for a in Aloc],
        "rho": {"coop": [fnum(v, 6) for v in rho_c], "local": [fnum(v, 6) for v in rho_l],
                "note": "spectral radius of M1 M0^-1 before the safeguard; if it exceeds rhoMax the estimate is rescaled to rhoMax"},
        "comm": {"msgs": msgs, "reals": reals, "bytes": [int(s["bytes_sent"]) for s in srows],
                 "x": [int(srows[0]["msgs_x"]), int(srows[0]["floats_x"])],
                 "s": [int(srows[0]["msgs_s"]), int(srows[0]["floats_s"])],
                 "m": [int(srows[0]["msgs_m"]), int(srows[0]["floats_m"])]},
        "summary": {"idCoop": sig(summ["id_err_coop_mean"]), "idLocal": sig(summ["id_err_local_mean"]),
                    "ratio": sig(summ["id_ratio_local_over_coop"], 4), "rmse": sig(summ["tracking_rmse_window"]),
                    "rmseLocal": sig(rmse_local),
                    "rmseOutage": sig(summ["tracking_rmse_outage"]), "window": summ["tracking_window"],
                    "drivenM": sig(summ["charging_robot_driven_m"], 4), "reals": reals[0], "msgs": msgs[0]},
        "phase": phase,
        "xs": flat2(xs), "c": flat2(c), "xi": flat2(X), "b": flat2(B), "y": flat2(Y), "fp": flat2(FP),
        "err": {"track": [sig(v, 4) for v in track], "local": [sig(v, 4) for v in local],
                "robot": [sig(v, 4) for v in rob], "dis": [sig(v, 4) for v in dis]},
        "flights": flights,
        "timeMap": time_map,
        "scene": scene,
        "source": "webots_demo/output/web_animation/logs (seed 2026, N = 100, 200 tracking steps); "
                  "generated by webots_demo/tools/make_run.py",
    }
    if ARGS.check:
        print("checks passed; flights:", [(f["agency"], f["frame0"], f["frame1"], f["t0"], f["t1"]) for f in flights])
        print("segments:", [f["segments"] for f in flights])
        return
    text = ("/* The Webots run of the project page (seed 2026, N = 100, 200 tracking steps), from\n"
            "   webots_demo/output/web_animation/logs/.  Paper units (1 unit = 10 m in the paper; the\n"
            "   diorama draws a unit as 0.5 m).  Flat arrays: xs, c: [x, y] per step t; xi, b, y, fp:\n"
            "   [x, y] per step t and station i (index 12 t + 2 i).  err.track: the stations' RMS distance\n"
            "   to x*(t) (they learn A together); err.local: the same had each learned A alone (tau = 0),\n"
            "   replayed on the same telemetry.  Generated by webots_demo/tools/make_run.py. */\n"
            "window.RUN = " + json.dumps(run, separators=(",", ":"), allow_nan=False) + ";\n")
    with open(OUT, "w") as f:
        f.write(text)
    print("wrote %s (%.1f KB)" % (OUT, len(text) / 1024))
    print("rmse window %.6f (alone %.6f)  outage %.6f  idCoop %.6f  idLocal %.6f  ratio %.4f  reals %d msgs %d" % (
        rmse, rmse_local, rmse_out, np.mean(idc), np.mean(idl), np.mean(idl) / np.mean(idc), reals[0], msgs[0]))


if __name__ == "__main__":
    main()
