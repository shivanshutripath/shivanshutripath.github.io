#!/usr/bin/env python3
"""
check_initial_deviation.py -- why are the identification errors of the Webots
runs about twice those of the paper's Figure 2(b)?  Repeats the identification
on synthetic data of the simulated instance (m = 6, A, Q, telemetry error 0.75,
k = 2, the 6-ring) with the paper's reference code, for the two initial
deviations P0 = 2.5^2 I (simulation) and 4^2 I (Table 1).  Takes about 3 minutes.

    python3 tools/check_initial_deviation.py

Result quoted in Section 5.2 of the paper (300 trials, N = 100, exact averaging):
P0 = 2.5^2 I -> 0.0125,  P0 = 4^2 I -> 0.0066.
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "paper_v4_package", "code"))
import experiments as ref  # noqa: E402

m, k = 6, 2
A = 0.99 * ref.rot(0.15)
W = ref.metropolis(ref.ring_graph(6))


class _Case:
    m, n, p, R = 6, 2, 2, np.eye(2)


rng = np.random.default_rng(7)
for p0 in (2.5, 4.0):
    row = []
    for N in (30, 50, 100, 150, 200):
        errs, errs3 = [], []
        for trial in range(300):
            th = np.zeros((N, m, 2))
            th[0] = rng.standard_normal((m, 2)) * p0
            for t in range(1, N):
                th[t] = th[t - 1] @ A.T + rng.standard_normal((m, 2)) * 0.05
            y = th + rng.standard_normal((N, m, 2)) * 0.75      # telemetry minus the known route
            Y = np.transpose(y, (1, 0, 2))
            Cs = np.broadcast_to(np.eye(2), (m, N, 2, 2))
            tt = ref.window_estimates(_Case(), Y, Cs, N, k)
            M0, M1 = ref.iv_moments(tt, N, k)
            Ae, _ = ref.identify(M0, M1, W, None)
            A3, _ = ref.identify(M0, M1, W, 3)
            errs.append(np.linalg.norm(Ae - A, axis=(1, 2)))
            errs3.append(np.linalg.norm(A3 - A, axis=(1, 2)))
        row.append((N, np.median(errs), np.median(errs3)))
    print("P0 = %.1f^2 I:  " % p0 + "  ".join("N=%d exact %.4f tau3 %.4f" % r for r in row))
