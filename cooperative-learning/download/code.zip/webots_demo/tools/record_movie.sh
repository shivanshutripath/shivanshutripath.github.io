#!/bin/sh
# Records output/disaster_response.mp4 (1280x720, played at 2x) and the stills
# output/snapshot_*.png, then quits.  Run from anywhere:
#
#     sh webots_demo/tools/record_movie.sh
#
# Webots enlarges its window to fit a 1280x720 view while it records and saves
# that size in its preferences; a later start with --minimize then hangs on
# this Mac.  The script puts the saved size back afterwards.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
DEMO="$(cd "$HERE/.." && pwd)"
WEBOTS="${WEBOTS:-/Applications/Webots-nightly.app/Contents/MacOS/webots}"
PY="${PYTHON:-/Users/shivanshutripathi/miniconda3/bin/python3}"
DOMAIN=com.cyberbotics.Webots-R2025a

saved_size="$(defaults read "$DOMAIN" MainWindow.size 2>/dev/null || true)"
"$PY" "$DEMO/tools/make_world.py" --wbproj-only            # HUD panels back in their column
cd "$DEMO" || exit 1
RV_DEMO_MOVIE=1 RV_DEMO_SNAPSHOTS=1 RV_DEMO_AUTOQUIT=1 \
  "$WEBOTS" --batch --mode=fast --minimize --stdout --stderr worlds/disaster_response.wbt
status=$?
if [ -n "$saved_size" ]; then
  defaults write "$DOMAIN" MainWindow.size -string "$saved_size"
  echo "restored Webots window size $saved_size"
fi
ls -la "$DEMO/output/disaster_response.mp4" 2>/dev/null
exit $status
