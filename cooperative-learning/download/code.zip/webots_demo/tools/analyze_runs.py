#!/usr/bin/env python3
"""
analyze_runs.py
===============

Reads the Webots runs written by ``collect_data.py`` (one folder per seed, each
written by the supervisor of ``worlds/disaster_response.wbt``), checks them
against the reference implementation of the paper, replays the baselines on
the same recorded telemetry, and writes the numbers quoted in the paper's
Webots section (Section 5.2), the data files, and a table and TikZ figures
of all runs (output/analysis/*.tex; not part of the paper, whose
supplementary material holds only the proofs).

    python3 tools/analyze_runs.py output/runs_N100 [output/runs_N50 ...]
            [--figure-run output/runs_N100/seed_2026]
            [--splice ../paper_v4_package/main.tex]
            [--out output/analysis]

What it does for every run
--------------------------
1. Loads ``run_config.json``, ``steps.csv`` and ``stations.csv``.
2. Re-identifies A from the telemetry the stations received, with the functions
   ``window_estimates``, ``iv_moments`` and ``identify`` of
   ``paper_v4_package/code/experiments.py`` (the code behind the paper's
   figures), and compares the result with the estimates the six station
   controllers computed inside Webots.
3. Replays the gradient-tracking recursion (11) offline with the stations'
   own estimates and compares it with the iterates logged in Webots.
4. Replays the same recursion, on the same telemetry, with local
   identification (tau = 0), exact averaging (tau = inf), the true A
   (oracle), and A = I (persistence), so that every method is compared on
   identical data.
5. Computes the paper's metrics: the identification error ||A_i - A||_F per
   station, and the tracking RMSE over t in [N+50, N+200) (Section 5.1,
   "Results of (A)").

Only numpy is required.
"""
import argparse
import csv
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))
REF_CODE = os.path.join(ROOT, "paper_v4_package", "code")
sys.path.insert(0, REF_CODE)
import experiments as ref  # noqa: E402  (the paper's reference implementation)

METHODS = ["coop", "local", "exact", "oracle", "persistence"]
LABEL = {"coop": "cooperative ($\\tau=3$)", "local": "local ($\\tau=0$)", "exact": "exact averaging",
         "oracle": "oracle $A$", "persistence": "persistence"}


# ----------------------------------------------------------------------------
# loading
# ----------------------------------------------------------------------------
class Run:
    """One Webots run, as written by the supervisor."""

    def __init__(self, folder):
        self.folder = folder
        with open(os.path.join(folder, "run_config.json")) as f:
            self.cfg = json.load(f)
        c = self.cfg
        self.seed, self.m, self.N = c["seed"], c["m"], c["N"]
        self.k, self.tau, self.alpha = c["k"], c["tau"], c["alpha"]
        self.rho_max = c["rho_max"]
        self.A = np.array(c["A"], dtype=float)
        self.h = np.array(c["h"], dtype=float)
        self.W = np.array(c["W"], dtype=float)
        self.T = c["T_total"]

        rows = list(csv.DictReader(open(os.path.join(folder, "steps.csv"))))
        m, T = self.m, len(rows)
        self.t = np.array([int(r["t"]) for r in rows])
        assert np.all(self.t == np.arange(T)), "steps.csv must hold t = 0, 1, ..., T-1"

        def col(name):
            return np.array([np.nan if r[name] == "" else float(r[name]) for r in rows])

        def pair(prefix):
            return np.column_stack([col(prefix + "_1"), col(prefix + "_2")])

        self.xstar = pair("xs")
        self.X = np.stack([pair("x%d" % (i + 1)) for i in range(m)], axis=1)        # iterates x_i(t)
        self.Theta = np.stack([pair("th%d" % (i + 1)) for i in range(m)], axis=1)   # true deviations
        self.P = np.stack([pair("p%d" % (i + 1)) for i in range(m)], axis=1)        # known routes p_i(t)
        self.Ypos = np.stack([pair("y%d" % (i + 1)) for i in range(m)], axis=1)     # telemetry, t < N
        self.F = np.stack([pair("f%d" % (i + 1)) for i in range(m)], axis=1)        # station forecasts, t >= N
        self.charger = pair("c")
        self.T = T

        st = list(csv.DictReader(open(os.path.join(folder, "stations.csv"))))
        self.st = st
        self.A_coop = np.array([[[float(s["a11"]), float(s["a12"])], [float(s["a21"]), float(s["a22"])]] for s in st])
        self.A_loc = np.array([[[float(s["l11"]), float(s["l12"])], [float(s["l21"]), float(s["l22"])]] for s in st])
        self.floats = np.array([int(s["floats_sent"]) for s in st])
        self.msgs = np.array([int(s["msgs_sent"]) for s in st])
        self.bytes = np.array([int(s["bytes_sent"]) for s in st])
        summ = os.path.join(folder, "summary.json")
        self.summary = json.load(open(summ)) if os.path.exists(summ) else {}


# ----------------------------------------------------------------------------
# reference identification (experiments.py) on the recorded telemetry
# ----------------------------------------------------------------------------
class _Case:
    """Minimal stand-in for experiments.CaseStudy: what window_estimates needs."""

    def __init__(self, m):
        self.m, self.n, self.p = m, 2, 2
        self.R = np.eye(2)   # C_i is constant, so R cancels in the Gauss--Markov estimate


def reference_estimates(run):
    """Window estimates, IV moments and A-hat for every method, computed by the
    paper's reference code from the telemetry that Webots delivered."""
    m, N, k = run.m, run.N, run.k
    cs = _Case(m)
    # gradient measurements ytilde_i(t) = -2 h_i (y_i(t) - p_i(t)) and C_i = -2 h_i I
    Y = np.zeros((m, N, 2))
    Cs = np.zeros((m, N, 2, 2))
    for i in range(m):
        Y[i] = -2.0 * run.h[i] * (run.Ypos[:N, i] - run.P[:N, i])
        Cs[i] = -2.0 * run.h[i] * np.eye(2)
    th = ref.window_estimates(cs, Y, Cs, N, k)         # (m, N-k+1, 2)
    M0, M1 = ref.iv_moments(th, N, k)
    est = {
        "coop": ref.identify(M0, M1, run.W, run.tau, run.rho_max),
        "local": ref.identify(M0, M1, run.W, 0, run.rho_max),
        "exact": ref.identify(M0, M1, run.W, None, run.rho_max),
    }
    est["oracle"] = (np.repeat(run.A[None], m, axis=0), np.full(m, max(abs(np.linalg.eigvals(run.A)))))
    est["persistence"] = (np.repeat(np.eye(2)[None], m, axis=0), np.ones(m))
    anchors = th[:, N - k]                               # theta_tilde_i(N-k)
    recon = th - run.Theta[:N - k + 1].transpose(1, 0, 2)
    return est, anchors, float(np.sqrt(np.mean(np.sum(recon ** 2, axis=2))))


# ----------------------------------------------------------------------------
# replay of the gradient-tracking recursion (the station controllers' order)
# ----------------------------------------------------------------------------
def replay(run, A_hat, anchors):
    """x_i(t), t = 0..T-1, from Algorithm 1 with the given estimates.

    Station order (rendezvous_robot.py): at t = 0, s(0) = g(0); for t >= 1,
    s(t) = W (s(t-1) + g(t) - g(t-1)) with g(t) taken at x(t); then
    x(t+1) = W (x(t) - alpha s(t)).  g(t) = 2 h_i (x_i - y_i(t)) for t < N and
    2 h_i (x_i - p_i(t) - A_i^(t-N+k) theta~_i(N-k)) for t >= N.
    """
    m, N, k, T = run.m, run.N, run.k, run.T
    W, alpha, h = run.W, run.alpha, run.h[:, None]
    powers = np.repeat(np.eye(2)[None], m, axis=0)
    fore_t = [N - k]

    def forecast(t):
        nonlocal powers
        while fore_t[0] < t:
            powers = np.einsum("iab,ibc->iac", powers, A_hat)
            fore_t[0] += 1
        return np.einsum("iab,ib->ia", powers, anchors)

    def grad(t, X):
        if t < N:
            return 2.0 * h * (X - run.Ypos[t])
        return 2.0 * h * (X - run.P[t] - forecast(t))

    X = np.zeros((m, 2))
    out = np.zeros((T, m, 2))
    out[0] = X
    G = grad(0, X)
    S = G.copy()
    for t in range(T - 1):
        if t > 0:
            Gt = grad(t, X)
            S = W @ (S + Gt - G)
            G = Gt
        X = W @ (X - alpha * S)
        out[t + 1] = X
    return out


# ----------------------------------------------------------------------------
# metrics (Section 5.1, "Results of (A)")
# ----------------------------------------------------------------------------
def tracking_rmse(run, X, lo=50, hi=200):
    """Network-average RMSE over t in [N+lo, N+hi)."""
    t0, t1 = run.N + lo, min(run.N + hi, run.T)
    e = np.sum((X[t0:t1] - run.xstar[t0:t1, None, :]) ** 2, axis=2)
    return float(np.sqrt(np.mean(e)))


def error_series(run, X):
    """(1/m sum_i ||x_i(t) - x*(t)||^2)^(1/2) for every t."""
    return np.sqrt(np.mean(np.sum((X - run.xstar[:, None, :]) ** 2, axis=2), axis=1))


def disagreement_series(X):
    return np.sqrt(np.mean(np.sum((X - X.mean(axis=1, keepdims=True)) ** 2, axis=2), axis=1))


def analyze(run):
    est, anchors, recon = reference_estimates(run)
    res = {"seed": run.seed, "N": run.N, "recon": recon}
    # (2) the stations' estimates against the reference implementation
    res["dA_coop"] = float(np.max(np.abs(est["coop"][0] - run.A_coop)))
    res["dA_local"] = float(np.max(np.abs(est["local"][0] - run.A_loc)))
    # (3) replay with the stations' own estimates against the Webots iterates
    n_logged = int(np.max(np.where(~np.isnan(run.X[:, :, 0]).all(axis=1))[0])) + 1
    X_web = run.X[:n_logged]
    X_rep = replay(run, run.A_coop, anchors)[:n_logged]
    res["dX_replay"] = float(np.max(np.abs(X_rep - X_web)))
    # forecasts reported by the stations (t >= N) against the replayed forecasts
    res["ids"] = {}
    res["unstable"] = {}
    res["rmse"] = {}
    res["series"] = {}
    for key in METHODS:
        A_hat, rho = est[key]
        res["ids"][key] = np.linalg.norm(A_hat - run.A, axis=(1, 2))
        res["unstable"][key] = int(np.sum(rho >= 1.0))
        X = run.X if key == "coop" else replay(run, A_hat, anchors)
        res["rmse"][key] = tracking_rmse(run, X)
        res["series"][key] = error_series(run, X)
    res["rmse_outage"] = tracking_rmse(run, run.X, 0, run.T - run.N)
    res["dis"] = disagreement_series(run.X)
    res["charger_err"] = np.linalg.norm(run.charger - run.xstar, axis=1)
    res["charger_rmse"] = float(np.sqrt(np.nanmean(res["charger_err"][run.N + 50:run.N + 200] ** 2)))
    res["agreed_rmse"] = float(np.sqrt(np.mean(np.sum((run.X.mean(axis=1) - run.xstar)[run.N + 50:run.N + 200] ** 2, axis=1))))
    res["floats"], res["msgs"], res["bytes"] = run.floats, run.msgs, run.bytes
    res["wall"] = run.summary.get("wall_clock_s")
    return res


# ----------------------------------------------------------------------------
# output helpers
# ----------------------------------------------------------------------------
def q(v):
    v = np.asarray(v, float).ravel()
    return float(np.median(v)), float(np.percentile(v, 25)), float(np.percentile(v, 75))


def num(v):
    s = "%.4g" % v
    if "e" in s:
        mant, exp = s.split("e")
        s = "%se%d" % (mant, int(exp))
    return s


def coords(x, y, per_line=6, indent="      "):
    pts = ["(%s,%s)" % (num(a), num(b)) for a, b in zip(x, y)]
    rows = [" ".join(pts[i:i + per_line]) for i in range(0, len(pts), per_line)]
    return ("\n" + indent).join(rows)


def write_dat(path, header, cols):
    arr = np.column_stack(cols)
    with open(path, "w") as f:
        f.write("  ".join(header) + "\n")
        for row in arr:
            f.write("  ".join("%.6g" % v for v in row) + "\n")


def summarize(results, log):
    """Pooled statistics of one batch (one value of N)."""
    N = results[0]["N"]
    out = {"N": N, "runs": len(results), "seeds": [r["seed"] for r in results]}
    for key in METHODS:
        ids = np.concatenate([r["ids"][key] for r in results])
        out["id_" + key] = q(ids)
        out["rmse_" + key] = q([r["rmse"][key] for r in results])
        out["unstable_" + key] = float(np.mean([r["unstable"][key] / len(r["ids"][key]) for r in results]))
    ratio = np.concatenate([r["ids"]["local"] / r["ids"]["coop"] for r in results])
    out["ratio_pairs"] = q(ratio)
    out["ratio_medians"] = out["id_local"][0] / out["id_coop"][0]
    out["rmse_gain_vs_local"] = q([1 - r["rmse"]["coop"] / r["rmse"]["local"] for r in results])
    out["coop_over_oracle"] = q([r["rmse"]["coop"] / r["rmse"]["oracle"] for r in results])
    out["pers_over_coop"] = q([r["rmse"]["persistence"] / r["rmse"]["coop"] for r in results])
    out["charger_rmse"] = q([r["charger_rmse"] for r in results])
    out["agreed_rmse"] = q([r["agreed_rmse"] for r in results])
    out["recon"] = q([r["recon"] for r in results])
    out["max_dA_coop"] = max(r["dA_coop"] for r in results)
    out["max_dA_local"] = max(r["dA_local"] for r in results)
    out["max_dX_replay"] = max(r["dX_replay"] for r in results)
    out["floats_per_station"] = sorted(set(int(v) for r in results for v in r["floats"]))
    out["msgs_per_station"] = sorted(set(int(v) for r in results for v in r["msgs"]))
    out["bytes_per_station"] = q(np.concatenate([r["bytes"] for r in results]))
    walls = [r["wall"] for r in results if r["wall"]]
    out["wall_clock_s"] = q(walls) if walls else None
    out["final_disagreement"] = q([r["dis"][-1] for r in results])

    log("=" * 74)
    log("Webots runs, N = %d, %d seeds (%s)" % (N, len(results), ", ".join(str(s) for s in out["seeds"])))
    log("  consistency: max |A_station - A_reference|  coop %.2e, local %.2e;  max |x_webots - x_replay| %.2e"
        % (out["max_dA_coop"], out["max_dA_local"], out["max_dX_replay"]))
    log("  identification error ||A_i - A||_F, median [IQR] over (run, station):")
    for key in ("local", "coop", "exact"):
        m_, lo, hi = out["id_" + key]
        log("     %-12s %.4f  [%.4f, %.4f]   not Schur stable before safeguard: %.0f%%"
            % (key, m_, lo, hi, 100 * out["unstable_" + key]))
    log("  local/coop: ratio of medians %.2f, median per-station ratio %.2f [%.2f, %.2f]  (sqrt m = %.2f)"
        % (out["ratio_medians"], *out["ratio_pairs"], np.sqrt(results[0]["ids"]["coop"].size)))
    log("  tracking RMSE over [N+50, N+200), median [IQR] over runs (paper units):")
    for key in METHODS:
        log("     %-12s %.4f  [%.4f, %.4f]" % ((key,) + out["rmse_" + key]))
    log("  coop vs local: %.1f%% lower (median, IQR %.1f..%.1f%%)" % tuple(100 * v for v in out["rmse_gain_vs_local"]))
    log("  coop/oracle %.3f, persistence/coop %.2f (medians)" % (out["coop_over_oracle"][0], out["pers_over_coop"][0]))
    log("  charging robot (driven) to x*: RMS %.4f units; mean of iterates to x*: %.4f units (medians)"
        % (out["charger_rmse"][0], out["agreed_rmse"][0]))
    log("  reconstruction error %.3f (median)" % out["recon"][0])
    log("  communication per station: %s reals in %s messages, %.0f bytes (median)"
        % (out["floats_per_station"], out["msgs_per_station"], out["bytes_per_station"][0]))
    if out["wall_clock_s"]:
        log("  wall clock per run: median %.1f s" % out["wall_clock_s"][0])
    return out


# ----------------------------------------------------------------------------
# figures and table (pgfplots, styles from the preamble of main.tex)
# ----------------------------------------------------------------------------
def tikz_series(res, run, every=2):
    """One run: network-average error versus time, Webots and the replayed baselines."""
    T, N = run.T, run.N
    t = np.arange(T)
    keep = sorted(set(list(range(0, T, every)) + [N - 1, N, T - 1]))
    lines = []
    style = {"coop": "cCoop, line width=0.8pt", "local": "cLocal, line width=0.8pt",
             "persistence": "cPers, densely dotted, line width=0.9pt"}
    names = {"coop": "cooperative (Webots)", "local": "local (replay)", "persistence": "persistence (replay)"}
    for key in ("persistence", "local", "coop"):
        e = res["series"][key]
        idx = [j for j in keep if (key == "coop" or j >= N - 1)]
        lines.append("\\addplot[%s] coordinates {%s};" % (style[key], coords(t[idx], np.maximum(e[idx], 1e-3))))
        lines.append("\\addlegendentry{%s}" % names[key])
    lines.append("\\addplot[gray, densely dashed, line width=0.5pt, forget plot] coordinates {(%d,0.03) (%d,30)};" % (N, N))
    lines.append("\\node[dlabel, text=gray, anchor=south west] at (axis cs:%d,0.035) {telemetry lost};" % (N + 4))
    return "\n".join(lines)


def make_figure(res, run, image):
    """Webots figure (output/analysis only; not part of the paper): (a) the scene, (b) one run."""
    T = run.T
    xt = list(range(0, T + 1, 100))
    return r"""\begin{minipage}[b]{0.43\linewidth}
  \centering
  \includegraphics[width=\linewidth]{%s}\\[2pt]
  {\small (a) Webots, during data collection}
\end{minipage}\hfill
\begin{minipage}[b]{0.545\linewidth}
  \centering
  \begin{tikzpicture}
  \begin{axis}[panel, width=\dimexpr\linewidth-2.05cm\relax, height=4.7cm,
    title={(b) One run (seed %d, $N=%d$)},
    xlabel={time $t$}, ylabel={tracking error},
    every axis y label/.style={at={(axis description cs:-0.21,0.5)}, rotate=90, anchor=south},
    xmin=0, xmax=%d, xtick={%s},
    ymode=log, ymin=0.03, ymax=30, ytick={0.1,1,10}, yticklabels={$0.1$,$1$,$10$},
    legend style={at={(0.98,0.98)}, anchor=north east, font=\scriptsize, draw=none, fill=white,
      fill opacity=0.85, text opacity=1, row sep=-2.5pt, inner sep=1pt},
  ]
%s
  \end{axis}
  \end{tikzpicture}
\end{minipage}""" % (image, run.seed, run.N, T - 1, ",".join(str(v) for v in xt), tikz_series(res, run))


def _band(tag, color, Ns, lo, hi):
    return ("\\addplot[name path=%sU, draw=none, forget plot] coordinates {%s};\n"
            "\\addplot[name path=%sL, draw=none, forget plot] coordinates {%s};\n"
            "\\addplot[band, fill=%s] fill between[of=%sU and %sL];") % (
        tag, coords(Ns, hi), tag, coords(Ns, lo), color, tag, tag)


def _ticks_log(lo, hi, cands):
    return [v for v in cands if lo <= v <= hi]


def make_sweep_figure(summaries):
    """Webots runs versus N, as Figure 2(a)-(b) of the paper (output/analysis only; not part of the paper)."""
    S = sorted(summaries, key=lambda s: s["N"])
    Ns = np.array([s["N"] for s in S], float)

    def col(key, j=0):
        return np.array([s[key][j] for s in S])

    rm = {k: col("rmse_" + k) for k in METHODS}
    ids = {k: col("id_" + k) for k in ("local", "coop", "exact")}
    ylo = 0.8 * min(min(col("rmse_coop", 1)), min(col("rmse_oracle")))
    yhi = 1.25 * max(max(col("rmse_persistence")), max(col("rmse_local", 2)))
    ilo = 0.8 * min(min(col("id_coop", 1)), min(ids["exact"]))
    ihi = 1.25 * max(col("id_local", 2))
    rt = _ticks_log(ylo, yhi, [0.1, 0.2, 0.3, 0.5, 1, 2, 3, 5])
    it = _ticks_log(ilo, ihi, [0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5])
    xt = ",".join("%d" % n for n in Ns)
    out = [r"\begin{tikzpicture}",
           r"\begin{groupplot}[panel, group style={group size=2 by 1, horizontal sep=2.3cm}]",
           r"% ---- (a) tracking RMSE versus N ----",
           "\\nextgroupplot[\n  title={(a) Tracking error, Webots},\n  xlabel={training horizon $N$},\n"
           "  ylabel={tracking RMSE},\n  xmode=log, xmin=%s, xmax=%s,\n  xtick={%s}, xticklabels={%s},\n"
           "  ymode=log, ymin=%s, ymax=%s,\n  ytick={%s}, yticklabels={%s},\n"
           "  legend to name=legWB, figlegend,\n]" % (num(0.87 * Ns[0]), num(1.15 * Ns[-1]), xt, xt, num(ylo), num(yhi),
                                                     ",".join(num(v) for v in rt), ",".join(num(v) for v in rt)),
           r"\addlegendimage{mcoop}\addlegendentry{cooperative (Webots)}",
           r"\addlegendimage{mlocal}\addlegendentry{local identification}",
           r"\addlegendimage{mpers}\addlegendentry{persistence}",
           r"\addlegendimage{moracle}\addlegendentry{oracle ($A$ known)}",
           r"\addlegendimage{mexact}\addlegendentry{exact averaging}",
           _band("wbaL", "cLocal", Ns, col("rmse_local", 1), col("rmse_local", 2)),
           _band("wbaC", "cCoop", Ns, col("rmse_coop", 1), col("rmse_coop", 2)),
           "\\addplot[mpers] coordinates {%s};" % coords(Ns, rm["persistence"]),
           "\\addplot[mlocal] coordinates {%s};" % coords(Ns, rm["local"]),
           "\\addplot[moracle] coordinates {%s};" % coords(Ns, rm["oracle"]),
           "\\addplot[mcoop] coordinates {%s};" % coords(Ns, rm["coop"]),
           r"% ---- (b) identification error versus N ----",
           "\\nextgroupplot[\n  title={(b) Identification error, Webots},\n  xlabel={training horizon $N$},\n"
           "  ylabel={$\\|\\hat A^{(i)}-A\\|_F$},\n  xmode=log, xmin=%s, xmax=%s,\n  xtick={%s}, xticklabels={%s},\n"
           "  ymode=log, ymin=%s, ymax=%s,\n  ytick={%s}, yticklabels={%s},\n]" % (
               num(0.87 * Ns[0]), num(1.15 * Ns[-1]), xt, xt, num(ilo), num(ihi),
               ",".join(num(v) for v in it), ",".join(num(v) for v in it)),
           _band("wbbL", "cLocal", Ns, col("id_local", 1), col("id_local", 2)),
           _band("wbbC", "cCoop", Ns, col("id_coop", 1), col("id_coop", 2)),
           "\\addplot[mlocal] coordinates {%s};" % coords(Ns, ids["local"]),
           "\\addplot[mexact] coordinates {%s};" % coords(Ns, ids["exact"]),
           "\\addplot[mcoop] coordinates {%s};" % coords(Ns, ids["coop"]),
           r"\end{groupplot}",
           r"\node[anchor=south] at ($(group c1r1.north)!0.5!(group c2r1.north)+(0,0.75cm)$) {\pgfplotslegendfromname{legWB}};",
           r"\end{tikzpicture}"]
    return "\n".join(out)


def make_table(summaries):
    """One row per N: medians over the runs (RMSE) and over (run, station) pairs (identification)."""
    rows = []
    for s in sorted(summaries, key=lambda s: s["N"]):
        rows.append("%d & %.3f & %.3f & %.3f & %.3f & %.4f & %.4f & %.4f & %.1f & %.0f\\%% & %.0f\\%%\\\\" % (
            s["N"], s["rmse_persistence"][0], s["rmse_local"][0], s["rmse_coop"][0], s["rmse_oracle"][0],
            s["id_local"][0], s["id_coop"][0], s["id_exact"][0], s["ratio_medians"],
            100 * s["unstable_local"], 100 * s["unstable_coop"]))
    return "\n".join(rows)


def splice(path, name, body):
    """Replace the lines between '% ---- BEGIN generated figure: <name>' and
    '% ---- END generated figure: <name> ----' (marker lines kept)."""
    lines = open(path).read().split("\n")
    begin = "% ---- BEGIN generated figure: " + name
    end = "% ---- END generated figure: " + name + " ----"
    a = [k for k, l in enumerate(lines) if l.strip() == begin or l.strip().startswith(begin + " ")]
    b = [k for k, l in enumerate(lines) if l.strip() == end]
    if len(a) != 1 or len(b) != 1 or b[0] < a[0]:
        raise SystemExit("markers for %s not found (once) in %s" % (name, path))
    lines = lines[:a[0] + 1] + body.split("\n") + lines[b[0]:]
    open(path, "w").write("\n".join(lines))


def collect_batches(paths):
    """Folders holding seed_* runs: the given ones, or their N* subfolders."""
    out = []
    for p in paths:
        subs = sorted(d for d in os.listdir(p) if os.path.isdir(os.path.join(p, d)))
        if any(d.startswith("seed_") for d in subs):
            out.append(p)
        else:
            out.extend(os.path.join(p, d) for d in subs
                       if any(e.startswith("seed_") for e in os.listdir(os.path.join(p, d))))
    return out


# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("paths", nargs="+", help="folders of seed_* runs, or a folder of N* batches (output/runs)")
    ap.add_argument("--out", default=os.path.join(HERE, "..", "output", "analysis"))
    ap.add_argument("--figure-run", default=None, help="run folder of panel (b) of the Webots figure; default N=100, seed 2026")
    ap.add_argument("--image", default="webots_scene", help="image file (in the paper's figs/) of panel (a)")
    ap.add_argument("--splice", nargs="+", default=None,
                    help="LaTeX file(s) to update between the generated-figure markers; a piece whose "
                         "markers are in none of the files is only written to --out")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    report = open(os.path.join(args.out, "webots_summary.txt"), "w")

    def log(s):
        print(s)
        report.write(s + "\n")

    summaries, all_results = [], {}
    for batch in collect_batches(args.paths):
        folders = sorted(os.path.join(batch, d) for d in os.listdir(batch)
                         if d.startswith("seed_") and os.path.exists(os.path.join(batch, d, "stations.csv")))
        if not folders:
            continue
        results = []
        for fo in folders:
            run = Run(fo)
            r = analyze(run)
            r["run"] = run
            results.append(r)
            log("  seed %d N=%d: id coop %.4f local %.4f | rmse coop %.3f local %.3f pers %.3f oracle %.3f | "
                "|dA| %.1e |dX| %.1e" % (run.seed, run.N, np.mean(r["ids"]["coop"]), np.mean(r["ids"]["local"]),
                                       r["rmse"]["coop"], r["rmse"]["local"], r["rmse"]["persistence"],
                                       r["rmse"]["oracle"], r["dA_coop"], r["dX_replay"]))
        all_results[results[0]["N"]] = results
        summaries.append(summarize(results, log))
    if not summaries:
        sys.exit("no runs found in %s" % ", ".join(args.paths))
    summaries.sort(key=lambda s: s["N"])

    allr = [r for rs in all_results.values() for r in rs]
    log("=" * 74)
    log("all %d runs: max |A_station - A_reference| = %.1e, max |x_webots - x_replay| = %.1e"
        % (len(allr), max(r["dA_coop"] for r in allr), max(r["dX_replay"] for r in allr)))
    log("N        : " + "  ".join("%7d" % s["N"] for s in summaries))
    for key in ("local", "coop", "exact"):
        log("id %-6s: " % key[:6] + "  ".join("%7.4f" % s["id_" + key][0] for s in summaries))
    log("ratio    : " + "  ".join("%7.2f" % s["ratio_medians"] for s in summaries))
    log("unstable : " + "  ".join("%6.0f%%" % (100 * s["unstable_local"]) for s in summaries))
    for key in METHODS:
        log("rmse %-4s: " % key[:4] + "  ".join("%7.3f" % s["rmse_" + key][0] for s in summaries))
    # ratios of medians, the convention of the paper (paper_v4_package/code/summarize.py)
    med = lambda s, k: s[k][0]  # noqa: E731
    log("gain     : " + "  ".join("%6.1f%%" % (100 * (1 - med(s, "rmse_coop") / med(s, "rmse_local"))) for s in summaries)
        + "   (1 - median coop / median local, as in the paper)")
    log("coop/orac: " + "  ".join("%7.3f" % (med(s, "rmse_coop") / med(s, "rmse_oracle")) for s in summaries))
    log("pers/coop: " + "  ".join("%7.2f" % (med(s, "rmse_persistence") / med(s, "rmse_coop")) for s in summaries))
    log("coop/exac: " + "  ".join("%7.3f" % (med(s, "id_coop") / med(s, "id_exact")) for s in summaries)
        + "   (identification)")
    log("unst coop: " + "  ".join("%6.1f%%" % (100 * s["unstable_coop"]) for s in summaries))

    with open(os.path.join(args.out, "webots_summary.json"), "w") as f:
        json.dump(summaries, f, indent=1)
    for N, results in all_results.items():
        seeds = np.array([r["seed"] for r in results], float)
        write_dat(os.path.join(args.out, "wb_N%d_rmse.dat" % N), ["seed"] + METHODS,
                  [seeds] + [np.array([r["rmse"][k] for r in results]) for k in METHODS])
        m = results[0]["ids"]["coop"].size
        write_dat(os.path.join(args.out, "wb_N%d_id.dat" % N), ["seed", "station"] + METHODS,
                  [np.repeat(seeds, m), np.tile(np.arange(1, m + 1), len(results))]
                  + [np.concatenate([r["ids"][k] for r in results]) for k in METHODS])

    # main-text figure: one run
    fig_res = None
    want = os.path.normpath(args.figure_run) if args.figure_run else None
    for r in allr:
        if (want and os.path.normpath(r["run"].folder) == want) or (not want and r["N"] == 100 and r["seed"] == 2026):
            fig_res = r
    fig_res = fig_res or allr[0]
    run = fig_res["run"]
    write_dat(os.path.join(args.out, "wb_trial_series.dat"), ["t"] + METHODS + ["disagreement", "charger"],
              [np.arange(run.T)] + [fig_res["series"][k] for k in METHODS] + [fig_res["dis"], fig_res["charger_err"]])
    log("figure run: %s (rmse coop %.3f local %.3f persistence %.3f)" % (
        run.folder, fig_res["rmse"]["coop"], fig_res["rmse"]["local"], fig_res["rmse"]["persistence"]))
    pieces = {"fig_webots": make_figure(fig_res, run, args.image), "table_webots": make_table(summaries)}
    if len(summaries) > 1:
        pieces["fig_webots_sweep"] = make_sweep_figure(summaries)
    for name, body in pieces.items():
        open(os.path.join(args.out, name + ".tex"), "w").write(body + "\n")
        if args.splice:
            hits = [p for p in args.splice if "BEGIN generated figure: " + name + " " in open(p).read()]
            if not hits:
                continue                 # not part of the paper; <name>.tex is still written to --out
            if len(hits) > 1:
                raise SystemExit("markers for %s found in several files: %s" % (name, hits))
            splice(hits[0], name, body)
    if args.splice:
        log("spliced into %s (where present): %s" % (", ".join(args.splice), ", ".join(pieces)))
    report.close()


if __name__ == "__main__":
    main()
