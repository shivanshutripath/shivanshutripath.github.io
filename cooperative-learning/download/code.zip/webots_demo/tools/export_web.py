#!/usr/bin/env python3
"""
export_web.py -- put a recorded Webots web animation on a web page.

    python3 tools/export_web.py ANIM_DIR DEST [--vendor VENDOR_DIR] [--fire-scale S]

ANIM_DIR  folder written by a run with RV_DEMO_ANIMATION=1 (see
          tools/record_animation.sh); it holds disaster_response.w3d (the 3D
          scene) and disaster_response.json (the animation).
DEST      folder of the web page that will show it (e.g. the project page's
          webots/ folder).  Writes DEST/disaster_response.w3d and .json.

The fire's point lights are scaled by --fire-scale (default 0.25): the web
renderer of Webots has no tone mapping, so the lights tuned for the desktop
renderer wash the ground out.  Nothing else in the scene is changed.

--vendor VENDOR_DIR also downloads the Webots web player (WebotsView, release
R2025a, Apache License 2.0, Cyberbotics Ltd.) from cyberbotics.com into
VENDOR_DIR and rewrites its few absolute URLs so that it loads only from
VENDOR_DIR.  The page then needs no third-party server at view time:

    <script type="module" src="VENDOR_DIR/wwi/R2025a/WebotsView.js"></script>

The crawler follows the static imports of WebotsView.js, the scripts and style
sheets it loads, the url()s of those style sheets, and a short list of files
loaded by the WebAssembly renderer.
"""
import argparse
import os
import re
import shutil
import sys
import time
import urllib.parse
import urllib.request

ROOT = "https://cyberbotics.com/"
WWI = ROOT + "wwi/R2025a/"
# files that are not reachable by reading the sources (loaded by the renderer)
EXTRA = [
    WWI + "wrenjs.wasm",
    WWI + "wrenjs.data",
    WWI + "images/loading/default_thumbnail.png",
    WWI + "images/post_processing/gtao_noise_texture.png",
    WWI + "images/post_processing/smaa_area_texture.png",
    WWI + "images/post_processing/smaa_search_texture.png",
    ROOT + "wwi/images/missing_texture.png",
    ROOT + "assets/images/webots.png",
]
# large fonts that only labels in those fonts would use
SKIP_FONTS = ("Code 2000", "Code 2001", "Code 2002", "Comic Sans MS", "Lucida Sans Unicode")

IMPORT_RE = re.compile(r"""(?:import|export)\s[^'"]*?from\s*['"]([^'"]+)['"]|import\s*\(\s*['"]([^'"]+)['"]\s*\)|import\s+['"]([^'"]+)['"]""")
ABS_RE = re.compile(r"https://cyberbotics\.com/(?:wwi/R2025a/[^'\"`\s)]+|wwi/images/[^'\"`\s)]+|assets/images/[^'\"`\s)]+)")
CSS_URL_RE = re.compile(r"""url\(\s*['"]?([^'")]+)['"]?\s*\)""")


def fetch(url, tries=3):
    last = None
    for k in range(tries):
        try:
            with urllib.request.urlopen(urllib.parse.quote(url, safe=":/"), timeout=90) as r:
                return r.read()
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(2 + 3 * k)
    raise RuntimeError("could not download %s: %s" % (url, last))


def local_path(vendor, url):
    assert url.startswith(ROOT), url
    return os.path.join(vendor, *url[len(ROOT):].split("/"))


def crawl(vendor):
    todo = [WWI + "WebotsView.js"] + EXTRA
    seen = set()
    while todo:
        url = todo.pop()
        if url in seen or not url.startswith(ROOT):
            continue
        if any(f in urllib.parse.unquote(url) for f in SKIP_FONTS):
            continue
        seen.add(url)
        data = fetch(url)
        path = local_path(vendor, url)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as f:
            f.write(data)
        if url.endswith(".js"):
            text = data.decode("utf-8", "replace")
            for m in IMPORT_RE.finditer(text):
                spec = next(g for g in m.groups() if g)
                if spec.startswith("."):
                    todo.append(urllib.parse.urljoin(url, spec))
            todo.extend(ABS_RE.findall(text))
            # relative image / style references inside the sources (toolbar icons ...)
            for spec in re.findall(r"""['"`(](\.\.?/[^'"`()\s]+\.(?:svg|png|css|woff2))['"`)]""", text):
                todo.append(urllib.parse.urljoin(url, spec))
        elif url.endswith(".css"):
            text = data.decode("utf-8", "replace")
            for spec in re.findall(r"""@import\s+['"]([^'"]+)['"]""", text):
                todo.append(urllib.parse.urljoin(url, spec))
            for spec in CSS_URL_RE.findall(text):
                if not spec.startswith("data:"):
                    todo.append(urllib.parse.urljoin(url, spec))
    return sorted(seen)


def rewrite(vendor):
    """Replace the absolute cyberbotics.com URLs of the sources by URLs relative
    to the module that contains them (import.meta.url)."""
    base = os.path.join(vendor, "wwi", "R2025a")
    changed = []
    for dirpath, _, files in os.walk(base):
        for name in files:
            if not name.endswith(".js") or "dependencies" in dirpath:
                continue
            path = os.path.join(dirpath, name)
            text = open(path, encoding="utf-8").read()
            if "https://cyberbotics.com/" not in text:
                continue
            here = os.path.relpath(base, dirpath).replace(os.sep, "/")
            prefix = "./" if here == "." else here + "/"
            new = text
            # WebotsView.js injects Module.locateFile as a classic <script> built from a
            # template literal: interpolate this module's URL when the string is built
            new = new.replace("return 'https://cyberbotics.com/wwi/R2025a/' + path;",
                              "return '${new URL('%s', import.meta.url).href}' + path;" % prefix)
            # inside the template literal of AnimationSlider.js
            new = new.replace('href="https://cyberbotics.com/wwi/R2025a/css/animation_slider.css"',
                              'href="${new URL(\'%scss/animation_slider.css\', import.meta.url).href}"' % prefix)
            # <img src="..."> inside a single-quoted string (Progress.js)
            new = new.replace('<img src="https://cyberbotics.com/assets/images/webots.png"></img>',
                              '<img src="\' + new URL(\'%s../../assets/images/webots.png\', import.meta.url).href + \'"></img>' % prefix)
            new = re.sub(r"'https://cyberbotics\.com/wwi/R2025a/([^']*)'",
                         lambda m: "new URL('%s%s', import.meta.url).href" % (prefix, m.group(1)), new)
            new = re.sub(r"'https://cyberbotics\.com/wwi/images/([^']*)'",
                         lambda m: "new URL('%s../images/%s', import.meta.url).href" % (prefix, m.group(1)), new)
            if new != text:
                open(path, "w", encoding="utf-8").write(new)
                changed.append(os.path.relpath(path, vendor))
    # every remaining absolute reference must be a plain link (not a resource)
    leftovers = []
    for dirpath, _, files in os.walk(base):
        for name in files:
            if name.endswith(".js") and "dependencies" not in dirpath:
                for line in open(os.path.join(dirpath, name), encoding="utf-8"):
                    if "https://cyberbotics.com/" in line and "href=\"https://cyberbotics.com\"" not in line \
                            and "cyberbotics.com/doc" not in line:
                        leftovers.append("%s: %s" % (name, line.strip()[:160]))
    return changed, leftovers


LICENSE_NOTE = """Webots web player (WebotsView), release R2025a
=============================================

These files are an unmodified copy of https://cyberbotics.com/wwi/R2025a/
(the player that Webots' HTML5 animation export loads), except that the few
absolute URLs that pointed back to cyberbotics.com now point into this folder,
so that the page loads nothing from a third-party server.  Made with
webots_demo/tools/export_web.py of the paper's code.

Webots is Copyright 1996-2025 Cyberbotics Ltd. and is distributed under the
Apache License, Version 2.0: https://www.apache.org/licenses/LICENSE-2.0
Source: https://github.com/cyberbotics/webots (resources/web/wwi).
"""


def lookat(pos, target):
    """Axis-angle orientation of a Webots viewpoint at pos looking at target
    (same convention as the supervisor: x forward, z up)."""
    import math
    def sub(a, b): return [a[k] - b[k] for k in range(3)]
    def cross(a, b): return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]
    def unit(a):
        n = math.sqrt(sum(v * v for v in a))
        return [v / n for v in a]
    x = unit(sub(target, pos))
    y = unit(cross([0.0, 0.0, 1.0], x))
    z = cross(x, y)
    R = [[x[0], y[0], z[0]], [x[1], y[1], z[1]], [x[2], y[2], z[2]]]
    angle = math.acos(max(-1.0, min(1.0, (R[0][0] + R[1][1] + R[2][2] - 1.0) / 2.0)))
    axis = [R[2][1] - R[1][2], R[0][2] - R[2][0], R[1][0] - R[0][1]]
    n = math.sqrt(sum(v * v for v in axis))
    if n < 1e-9:
        return [0.0, 0.0, 1.0, 0.0]
    return [axis[0] / n, axis[1] / n, axis[2] / n, angle]


def set_viewpoint(w3d_text, spec):
    """spec = 'px,py,pz,tx,ty,tz': the initial camera of the web view."""
    v = [float(s) for s in spec.split(",")]
    pos, tgt = v[:3], v[3:6]
    o = lookat(pos, tgt)
    def one(m):
        tag = m.group(0)
        tag = re.sub(r"position='[^']*'", "position='%.4g %.4g %.4g'" % tuple(pos), tag)
        tag = re.sub(r"orientation='[^']*'", "orientation='%.6f %.6f %.6f %.6f'" % tuple(o), tag)
        return tag
    return re.sub(r"<Viewpoint\b[^>]*>", one, w3d_text, count=1)


def fire_lights(w3d_text, scale):
    """Scale the intensity of the scene's PointLights (the fire)."""
    def one(m):
        tag = m.group(0)
        return re.sub(r"intensity='([0-9.eE+-]+)'",
                      lambda k: "intensity='%.4g'" % (float(k.group(1)) * scale), tag)
    return re.sub(r"<PointLight\b[^>]*>", one, w3d_text)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("anim_dir")
    ap.add_argument("dest")
    ap.add_argument("--vendor")
    ap.add_argument("--fire-scale", type=float, default=0.25)
    ap.add_argument("--viewpoint", default="0,-15.2,12.4,0,-0.9,0",
                    help="initial web camera 'px,py,pz,tx,ty,tz' in metres (default: centred three-quarter view)")
    a = ap.parse_args()

    src_w3d = os.path.join(a.anim_dir, "disaster_response.w3d")
    src_json = os.path.join(a.anim_dir, "disaster_response.json")
    for p in (src_w3d, src_json):
        if not os.path.isfile(p):
            sys.exit("missing %s (record it with tools/record_animation.sh)" % p)
    os.makedirs(a.dest, exist_ok=True)
    w3d = open(src_w3d, encoding="utf-8").read()
    w3d = fire_lights(w3d, a.fire_scale)
    if a.viewpoint:
        w3d = set_viewpoint(w3d, a.viewpoint)
    with open(os.path.join(a.dest, "disaster_response.w3d"), "w", encoding="utf-8") as f:
        f.write(w3d)
    shutil.copyfile(src_json, os.path.join(a.dest, "disaster_response.json"))
    print("scene and animation -> %s (fire lights x%g)" % (a.dest, a.fire_scale))

    if a.vendor:
        files = crawl(a.vendor)
        changed, leftovers = rewrite(a.vendor)
        with open(os.path.join(a.vendor, "README.md"), "w") as f:
            f.write(LICENSE_NOTE)
        size = sum(os.path.getsize(local_path(a.vendor, u)) for u in files)
        print("web player: %d files, %.1f MB -> %s" % (len(files), size / 1e6, a.vendor))
        print("rewritten: %s" % ", ".join(changed))
        for line in leftovers:
            print("WARNING absolute URL left:", line)


if __name__ == "__main__":
    main()
