#!/usr/bin/env python3
"""
Writes worlds/disaster_response.wbt from lib/rendezvous_common.py
(observation posts, service rates, colors, radio graph).  Run it again after
changing the configuration:

    python3 tools/make_world.py
"""
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "lib"))
import rendezvous_common as C  # noqa: E402

ARENA = 20.0
CONCRETE = "0.58 0.55 0.50"
CONCRETE_DARK = "0.42 0.39 0.36"
RUBBLE = "0.48 0.45 0.41"


def axis_angle_lookat(pos, target, up=(0, 0, 1)):
    """Viewpoint rotation (axis-angle) for a camera at pos looking at target.
    Webots (FLU) cameras look along their local +x axis, +y is left, +z is up."""
    x = np.array(target, float) - np.array(pos, float)
    x /= np.linalg.norm(x)
    y = np.cross(np.array(up, float), x)
    y /= np.linalg.norm(y)
    z = np.cross(x, y)
    R = np.column_stack([x, y, z])
    angle = math.acos(max(-1.0, min(1.0, (np.trace(R) - 1) / 2)))
    axis = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])
    axis /= np.linalg.norm(axis)
    return "%.6f %.6f %.6f %.6f" % (axis[0], axis[1], axis[2], angle)


def color(c):
    return "%.3f %.3f %.3f" % c


def grid_lines(size, step):
    pts, idx, n = [], [], 0
    half = size / 2
    k = int(round(size / step))
    for j in range(k + 1):
        v = -half + j * step
        pts += ["%g %g 0.003" % (v, -half), "%g %g 0.003" % (v, half)]
        idx += ["%d %d -1" % (n, n + 1)]
        n += 2
        pts += ["%g %g 0.003" % (-half, v), "%g %g 0.003" % (half, v)]
        idx += ["%d %d -1" % (n, n + 1)]
        n += 2
    return pts, idx


def box(w, x, y, z, sx, sy, sz, rgb):
    w("      Pose { translation %.3f %.3f %.3f children [ Shape { appearance PBRAppearance { baseColor %s roughness 1 metalness 0 } geometry Box { size %.3f %.3f %.3f } } ] }"
      % (x, y, z, rgb, sx, sy, sz))


def sphere(w, x, y, z, r, rgb, transparency=0.0):
    w("      Pose { translation %.3f %.3f %.3f children [ Shape { appearance PBRAppearance { baseColor %s roughness 1 metalness 0 transparency %.2f } geometry Sphere { radius %.3f subdivision 2 } } ] }"
      % (x, y, z, rgb, transparency, r))


def annulus(r_in, r_out, seg=32):
    """Flat ring in the xy-plane (an IndexedFaceSet, both faces drawn)."""
    pts, idx = [], []
    for k in range(seg):
        a = 2 * math.pi * k / seg
        pts.append("%.4f %.4f 0" % (r_out * math.cos(a), r_out * math.sin(a)))
        pts.append("%.4f %.4f 0" % (r_in * math.cos(a), r_in * math.sin(a)))
    for k in range(seg):
        o0, i0 = 2 * k, 2 * k + 1
        o1, i1 = 2 * ((k + 1) % seg), 2 * ((k + 1) % seg) + 1
        idx.append("%d %d %d %d -1" % (o0, o1, i1, i0))
    return ("IndexedFaceSet { coord Coordinate { point [ %s ] } coordIndex [ %s ] }"
            % (", ".join(pts), " ".join(idx)))


def pipe(w, x, y, z, length, radius, rgb):
    """Horizontal pipe along local x (Cylinder's axis is z in this Webots)."""
    w("      Pose { translation %.3f %.3f %.3f rotation 0 1 0 1.5708 children [ Shape { appearance PBRAppearance { baseColor %s roughness 0.45 metalness 0.35 } geometry Cylinder { radius %.3f height %.3f } } ] }"
      % (x, y, z, rgb, radius, length))


def ruin(w, i):
    """A damaged structure at observation post i.  Local +x points away from the plaza."""
    # footprints stay inside the colored ring (radius 0.85 m) so the ring stays visible
    if i == 0:  # collapsed wing: a standing stub and a slab that has fallen outward
        box(w, -0.10, 0.05, 0.32, 0.55, 0.40, 0.64, CONCRETE)
        w("      Pose { translation 0.38 0.02 0.10 rotation 0 1 0 1.15 children [ Shape { appearance PBRAppearance { baseColor %s roughness 1 metalness 0 } geometry Box { size 0.62 0.36 0.10 } } ] }" % CONCRETE_DARK)
        sphere(w, 0.48, 0.16, 0.07, 0.09, RUBBLE)
    elif i == 1:  # burning hall: the fire the truck is here for
        box(w, 0.0, 0.16, 0.42, 0.62, 0.16, 0.84, "0.42 0.28 0.22")
        box(w, 0.0, -0.16, 0.42, 0.62, 0.16, 0.84, "0.36 0.24 0.20")
        box(w, -0.24, 0.0, 0.18, 0.14, 0.22, 0.36, CONCRETE_DARK)
        box(w, 0.22, 0.0, 0.62, 0.18, 0.50, 0.12, "0.45 0.32 0.24")
        w("      Pose { translation 0.02 0.02 0.95 children [ Shape { appearance PBRAppearance { baseColor 1 0.42 0.05 emissiveColor 1 0.28 0.0 emissiveIntensity 4 roughness 1 } geometry Sphere { radius 0.16 subdivision 2 } } ] }")
        w("      Pose { translation 0.10 -0.06 1.12 children [ Shape { appearance PBRAppearance { baseColor 1 0.72 0.15 emissiveColor 1 0.55 0.05 emissiveIntensity 3 roughness 1 } geometry Sphere { radius 0.09 subdivision 2 } } ] }")
        sphere(w, 0.0, 0.0, 1.45, 0.28, "0.25 0.25 0.26", transparency=0.55)
    elif i == 2:  # damaged gas line
        box(w, -0.05, 0.0, 0.22, 0.48, 0.40, 0.44, CONCRETE)
        pipe(w, 0.28, 0.05, 0.08, 0.55, 0.035, "0.85 0.72 0.15")
        sphere(w, 0.42, -0.12, 0.06, 0.08, RUBBLE)
    elif i == 3:  # rubble pile
        box(w, 0.0, 0.0, 0.10, 0.70, 0.55, 0.18, CONCRETE_DARK)
        sphere(w, -0.12, 0.10, 0.22, 0.13, RUBBLE)
        sphere(w, 0.14, -0.08, 0.20, 0.12, CONCRETE)
        sphere(w, 0.05, 0.16, 0.30, 0.10, RUBBLE)
        sphere(w, 0.22, 0.12, 0.16, 0.08, CONCRETE_DARK)
    elif i == 4:  # water main
        box(w, -0.08, 0.0, 0.30, 0.50, 0.46, 0.60, CONCRETE)
        pipe(w, 0.22, -0.12, 0.07, 0.48, 0.04, "0.25 0.45 0.75")
        box(w, 0.05, 0.22, 0.62, 0.16, 0.14, 0.28, CONCRETE_DARK)
    else:  # blocked road: two barriers and a broken pier
        box(w, 0.05, 0.22, 0.14, 0.78, 0.10, 0.22, "0.75 0.55 0.15")
        box(w, -0.05, -0.18, 0.11, 0.70, 0.10, 0.16, "0.75 0.55 0.15")
        box(w, 0.10, 0.0, 0.38, 0.22, 0.22, 0.55, CONCRETE)
        sphere(w, -0.28, 0.05, 0.07, 0.08, RUBBLE)


def main():
    out = os.path.join(HERE, "..", "worlds", "disaster_response.wbt")
    L = []
    w = L.append
    w("#VRML_SIM R2025a utf8")
    w("# Generated by tools/make_world.py from lib/rendezvous_common.py -- edit the config and regenerate.")
    w('EXTERNPROTO "../protos/DemoGroundRobot.proto"')
    w('EXTERNPROTO "../protos/DemoQuadrotor.proto"')
    w('EXTERNPROTO "../protos/DemoChargingRobot.proto"')
    w("")
    w("")
    w("WorldInfo {")
    w("  info [")
    w('    "North Wharf warehouse fire. Six agencies fly one UAV each in a search line"')
    w('    "that circles the site. Each ground station sees only its own UAV. By radio"')
    w('    "they agree where the charging robot should be, and it drives there, because"')
    w('    "that place moves with the UAVs. Orange dots are its recent ground track."')
    w("  ]")
    w('  title "North Wharf warehouse fire"')
    w("  basicTimeStep %d" % C.BASIC_TIME_STEP)
    w("  contactProperties [")
    w('    ContactProperties { material1 "caster" coulombFriction [ 0 ] softCFM 0.001 }')
    w('    ContactProperties { coulombFriction [ 2.0 ] softCFM 0.0005 bounce 0 }')
    w("  ]")
    w("}")
    cam_pos = (0.0, -20.0, 14.6)          # = WIDE_POS of the supervisor, which then eases closer
    w("DEF VIEW Viewpoint {")
    w("  orientation %s" % axis_angle_lookat(cam_pos, (-3.2, 0.0, -0.1)))
    w("  position %g %g %g" % cam_pos)
    w("  near 0.15")
    w("  fieldOfView 1.05")
    w("}")
    w("Background { skyColor [ 0.55 0.68 0.78 ] }")
    # light haze toward the sky color: the far ground melts into the horizon, the field stays crisp
    w("Fog { color 0.62 0.72 0.80 visibilityRange 170 }")
    w("DirectionalLight { direction -0.4 -0.35 -1 intensity 1.15 ambientIntensity 0.55 castShadows TRUE }")
    w("DirectionalLight { direction 0.3 0.5 -1 intensity 0.35 color 1 0.86 0.62 }")

    # A grass field. The emergency is one place in the middle, shared by every UAV.
    w("Solid {")
    w('  name "floor"')
    w("  children [")
    w("    Shape {")
    w("      appearance PBRAppearance { baseColor 0.36 0.52 0.24 roughness 1 metalness 0 }")
    w("      geometry Plane { size %g %g }" % (ARENA, ARENA))
    w("    }")
    w("  ]")
    w("  boundingObject Plane { size %g %g }" % (ARENA, ARENA))
    w("  locked TRUE")
    w("}")
    w("Pose {  # the land around the field, out to the haze")
    w("  translation 0 0 -0.003")
    w("  children [ Shape { appearance PBRAppearance { baseColor 0.34 0.49 0.23 roughness 1 metalness 0 } geometry Plane { size 220 220 } castShadows FALSE } ]")
    w("}")
    grass = np.random.default_rng(7)
    for k in range(70):
        gx, gy = grass.uniform(-8.5, 8.5, size=2)
        if gx * gx + (gy - 0.3) * (gy - 0.3) < 6.5:
            continue
        shade = 0.30 + 0.16 * float(grass.random())
        w("Pose { translation %.2f %.2f 0.04 rotation 0 0 1 %.2f children [ Shape { appearance PBRAppearance { baseColor %.2f %.2f %.2f roughness 1 } geometry Box { size 0.08 0.08 %.2f } } ] }"
          % (gx, gy, float(grass.uniform(0, 3)), 0.15 + shade * 0.4, shade + 0.28, 0.12, 0.06 + 0.10 * float(grass.random())))
    hx, hy = 0.0, 0.35
    w("Pose {  # the operation area, scorched grass around the emergency")
    w("  translation %.3f %.3f 0.008" % (hx, hy))
    w("  children [ Shape { appearance PBRAppearance { baseColor 0.55 0.42 0.18 roughness 1 emissiveColor 0.25 0.08 0 emissiveIntensity 0.15 } geometry Cylinder { radius 2.4 height 0.01 } } ]")
    w("}")
    w("Pose {  # access track from the depot to the site")
    w("  translation 0 -5.1 0.01")
    w("  children [ Shape { appearance PBRAppearance { baseColor 0.42 0.36 0.24 roughness 1 metalness 0 } geometry Box { size 1.6 6.4 0.012 } } ]")
    w("}")
    w("Pose {  # depot of the charging robot")
    w("  translation %.3f %.3f 0.012" % C.CHARGER_START)
    w("  children [ Shape { appearance PBRAppearance { baseColor 0.55 0.48 0.28 roughness 0.9 metalness 0 } geometry Box { size 2.1 1.5 0.012 } } ]")
    w("}")

    # One emergency, sitting in the shared hover: the fire, the collapse, the cordon.
    w("Pose {")
    w("  translation %.3f %.3f 0" % (hx, hy))
    w("  children [")
    box(w, 0.15, 0.25, 0.45, 0.85, 0.55, 0.90, "0.32 0.20 0.16")
    box(w, -0.55, -0.15, 0.22, 0.70, 0.40, 0.28, "0.40 0.36 0.32")
    w("      Pose { translation -0.15 -0.45 0.12 rotation 0 1 0 1.1 children [ Shape { appearance PBRAppearance { baseColor 0.34 0.32 0.30 roughness 1 } geometry Box { size 0.7 0.36 0.10 } } ] }")
    box(w, 0.85, -0.35, 0.16, 0.55, 0.12, 0.22, "0.75 0.55 0.12")
    box(w, 0.85, -0.55, 0.16, 0.55, 0.12, 0.22, "0.75 0.55 0.12")
    sphere(w, 0.35, -0.2, 0.08, 0.10, "0.25 0.18 0.12")
    w("  ]")
    w("}")

    fx, fy = hx, hy
    wx, wy = hx - 0.7, hy - 0.2
    w("Pose { translation %.3f %.3f 0.012 children [ Shape { appearance PBRAppearance { baseColor 0.08 0.05 0.04 roughness 1 emissiveColor 0.35 0.08 0 emissiveIntensity 0.4 } geometry Cylinder { radius 1.45 height 0.012 } } ] }" % (fx, fy))
    w("PointLight { location %.3f %.3f 1.7 color 1 0.42 0.08 intensity 30 attenuation 0 0 0.12 radius 10 castShadows FALSE }" % (fx, fy))
    w("PointLight { location %.3f %.3f 1.1 color 1 0.28 0.04 intensity 8 attenuation 0 0 0.35 radius 4 castShadows FALSE }" % (wx, wy))
    flames = [
        ("FLAME_0", fx, fy, 1.15, 0.22, 6.0),
        ("FLAME_1", fx + 0.12, fy - 0.05, 1.55, 0.16, 5.0),
        ("FLAME_2", fx - 0.08, fy + 0.06, 1.90, 0.11, 4.0),
        ("FLAME_3", fx + 0.22, fy + 0.10, 1.25, 0.13, 4.5),
        ("FLAME_4", fx - 0.18, fy - 0.08, 1.08, 0.14, 4.5),
        ("FLAME_5", wx, wy, 0.85, 0.12, 3.5),
        ("FLAME_6", wx + 0.16, wy - 0.05, 1.05, 0.08, 3.0),
        ("FLAME_7", fx + 0.05, fy + 0.02, 2.15, 0.07, 3.0),
    ]
    for name, x, y, z, r, intense in flames:
        w("DEF %s Pose { translation %.3f %.3f %.3f children [ Shape { appearance PBRAppearance { baseColor 1 0.40 0.02 emissiveColor 1 0.32 0.0 emissiveIntensity %.1f roughness 1 } geometry Sphere { radius %.3f subdivision 2 } } ] }"
          % (name, x, y, z, intense, r))
    for k, z in enumerate((2.15, 2.55, 3.05, 3.60, 4.20, 4.90)):
        spread = 0.10 * k
        # light, thin haze: it reads as smoke without hiding the drones behind it
        w("DEF SMOKE_%d Pose { translation %.3f %.3f %.2f children [ Shape { appearance PBRAppearance { baseColor 0.36 0.34 0.33 transparency %.2f roughness 1 } geometry Sphere { radius %.2f subdivision 2 } castShadows FALSE } ] }"
          % (k, fx + spread, fy - 0.5 * spread, z, 0.80 + 0.025 * k, 0.26 + 0.07 * k))

    for i in range(C.M):
        sx, sy = (C.tasking(i, 0) * C.SCALE).tolist()
        w("DEF UAV_%d DemoQuadrotor {" % i)
        w("  translation %.4f %.4f %.3f" % (sx, sy, C.uav_altitude(i, 0)))
        w('  name "uav_%d"' % i)
        w("  color %s" % color(C.COLORS[i]))
        w("}")

    # agency stations stand outside the ruins, facing the plaza.  They run
    # Algorithm 1 and stay put; the charging robot does the driving.
    for i in range(C.M):
        sx, sy = C.station_xy(i).tolist()
        heading = math.atan2(-sy, -sx)
        w("DEF ROBOT_%d DemoGroundRobot {" % i)
        w("  translation %.4f %.4f 0.0" % (sx, sy))
        w("  rotation 0 0 1 %.5f" % heading)
        w('  name "robot_%d"' % i)
        w("  color %s" % color(C.COLORS[i]))
        w("  telemetryChannel %d" % (C.CH_TELEMETRY_BASE + i))
        w("}")

    # the charging robot: physics, wheels, its own controller (controllers/charging_robot)
    w("DEF CHARGER DemoChargingRobot {")
    w("  translation %.4f %.4f 0.0" % C.CHARGER_START)
    w("  rotation 0 0 1 1.5708")
    w('  name "charging_robot"')
    w("  dispatchChannel %d" % C.CH_DISPATCH)
    w("}")
    for k in range(C.PATH_BEADS):
        w("DEF PATH_%d Pose { translation 0 0 -4 children [ Shape { appearance PBRAppearance { baseColor 1 0.42 0.05 emissiveColor 1 0.32 0.0 emissiveIntensity 0.8 roughness 1 metalness 0 } geometry Sphere { radius 0.045 subdivision 1 } castShadows FALSE } ] }" % k)
    for i in range(C.M):
        col = color(C.COLORS[i])
        for k in range(C.UAV_PATH_BEADS):
            w("DEF UPATH_%d_%d Pose { translation 0 0 -4 children [ Shape { appearance PBRAppearance { baseColor %s emissiveColor %s emissiveIntensity 1.1 roughness 1 metalness 0 } geometry Sphere { radius 0.032 subdivision 1 } castShadows FALSE } ] }"
              % (i, k, col, col))

    # true best position (moved by the supervisor)
    w("DEF XSTAR Pose {")
    w("  translation 0 0 0")
    w("  children [")
    w("    Pose { translation 0 0 0.02 children [ Shape { appearance PBRAppearance { baseColor 1 0.80 0.15 emissiveColor 1 0.8 0.15 emissiveIntensity 0.55 roughness 0.6 metalness 0.2 } geometry Cylinder { radius 0.20 height 0.02 } } ] }")
    w("    Pose { translation 0 0 1.15 children [ Shape { appearance PBRAppearance { baseColor 1 0.85 0.3 emissiveColor 1 0.85 0.3 emissiveIntensity 0.55 transparency 0.45 roughness 1 metalness 0 } geometry Cylinder { radius 0.028 height 2.2 } } ] }")
    w("  ]")
    w("}")
    for i in range(C.M):
        w("DEF EST_%d Pose {" % i)
        w("  translation 0 0 -1")
        w("  children [")
        w("    Pose { translation 0 0 0.02 children [ Shape { appearance PBRAppearance { baseColor %s emissiveColor %s emissiveIntensity 0.4 roughness 0.8 metalness 0 } geometry Cylinder { radius 0.07 height 0.02 } } ] }" % (color(C.COLORS[i]), color(C.COLORS[i])))
        w("    Pose { translation 0 0 0.28 children [ Shape { appearance PBRAppearance { baseColor %s roughness 0.8 metalness 0 } geometry Cylinder { radius 0.008 height 0.52 } } ] }" % color(C.COLORS[i]))
        w("  ]")
        w("}")

    E = C.edges()
    pts = ["0 0 %g" % C.MAST_TOP_Z for _ in range(C.M)]
    idx = ["%d %d -1" % (a, b) for a, b in E]
    w("Shape {  # radio: each station linked to its two nearest neighbors")
    w("  appearance Appearance { material DEF NET_MAT Material { emissiveColor 0.97 0.97 0.97 diffuseColor 0 0 0 transparency 0.12 } }")
    w("  geometry IndexedLineSet { coord DEF NET_COORD Coordinate { point [ %s ] } coordIndex [ %s ] }" % (", ".join(pts), " ".join(idx)))
    w("}")
    pts = ["0 0 0" for _ in range(2 * C.M)]
    idx = ["%d %d -1" % (2 * i, 2 * i + 1) for i in range(C.M)]
    w("Shape {  # telemetry: station i reads UAV i, and only while t < N")
    w("  appearance Appearance { material DEF SENSE_MAT Material { emissiveColor 1 0.93 0.35 diffuseColor 0 0 0 transparency 0.15 } }")
    w("  geometry IndexedLineSet { coord DEF SENSE_COORD Coordinate { point [ %s ] } coordIndex [ %s ] }" % (", ".join(pts), " ".join(idx)))
    w("}")

    w("DEF SUPERVISOR Robot {")
    w('  name "supervisor"')
    w("  supervisor TRUE")
    w('  controller "rendezvous_supervisor"')
    w('  customData "snapshots"')
    w("  children [")
    w('    Emitter { name "emitter" channel %d bufferSize -1 }' % C.CH_TELEMETRY_BASE)
    w('    Receiver { name "status" channel %d bufferSize -1 }' % C.CH_STATUS)
    for name, ((pw, ph), _) in C.HUD_PANELS.items():
        w('    Display { name "%s" width %d height %d }' % (name, pw, ph))
    w("  ]")
    w("}")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w") as f:
        f.write("\n".join(L) + "\n")
    print("wrote", os.path.normpath(out))
    write_wbproj()


# Window layout Webots restores with the world.  Only the overlay lines are
# ours; the rest keeps whatever layout the .wbproj already holds.
DEFAULT_PERSPECTIVE = [
    "Webots Project File version R2025a",
    "perspectives: 000000ff00000000fd000000020000000100000087000002f4fc0200000001fb0000001400540065007800740045006400690074006f00720100000000000002f40000004500ffffff00000003000005a000000039fc0100000001fb0000001a0043006f006e0073006f006c00650041006c006c0041006c006c0100000000000005a00000008700ffffff00000517000002f400000001000000020000000100000008fc00000000",
    "simulationViewPerspectives: 000000ff0000000100000002000001140000036e0100000002010000000100",
    "sceneTreePerspectives: 000000ff00000001000000030000001e000002b7000000fa0100000002010000000200",
    "maximizedDockId: -1",
    "centralWidgetVisible: 1",
    "orthographicViewHeight: 1",
    "textFiles: -1",
    "consoles: Console:All:All",
]


def write_wbproj(visible=True, world_dir=None):
    """Anchor the HUD overlays to the corners of the 3D view (Webots clamps a
    position of 1 to the right / bottom edge).  Run again to put them back
    after moving them in the Webots window; --hide-hud writes them hidden
    (for clean stills of the scene)."""
    path = os.path.join(world_dir or os.path.join(HERE, "..", "worlds"), ".disaster_response.wbproj")
    lines = DEFAULT_PERSPECTIVE
    if os.path.exists(path):
        old = [l.rstrip("\n") for l in open(path)]
        if old and old[0].startswith("Webots Project File"):
            lines = old
    lines = [l for l in lines if l.strip() and not l.startswith("renderingDevicePerspectives:")]
    for name, (_, (x, y)) in C.HUD_PANELS.items():
        lines.append("renderingDevicePerspectives: supervisor:%s;%d;1;%g;%g" % (name, 1 if visible else 0, x, y))
    with open(path, "w") as f:
        f.write("\n".join(lines) + "\n")
    print("wrote", os.path.normpath(path))


if __name__ == "__main__":
    # --wbproj-only [--hide-hud] [--world-dir DIR]: rewrite only the window layout
    if "--wbproj-only" in sys.argv:
        wd = sys.argv[sys.argv.index("--world-dir") + 1] if "--world-dir" in sys.argv else None
        write_wbproj(visible="--hide-hud" not in sys.argv, world_dir=wd)
    else:
        main()
