#!/bin/sh
# Records the Webots web animation of the run shown on the project page
# (seed 2026, N = 100, 200 tracking steps: the run of output/runs/N100/seed_2026,
# with the recharge flights as scenery), then prepares it for the page:
#
#     sh webots_demo/tools/record_animation.sh [PAGE_DIR]
#
# Writes output/web_animation/disaster_response.{html,w3d,json} (the HTML file
# loads the player from cyberbotics.com) and, if PAGE_DIR is given,
# PAGE_DIR/webots/disaster_response.{w3d,json} and the self-hosted player
# PAGE_DIR/vendor/webots/ (tools/export_web.py).  The head-up display is off:
# the page draws its own panels from the logs in output/web_animation/logs/.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
DEMO="$(cd "$HERE/.." && pwd)"
WEBOTS="${WEBOTS:-/Applications/Webots-nightly.app/Contents/MacOS/webots}"
PY="${PYTHON:-/Users/shivanshutripathi/miniconda3/bin/python3}"
OUT="$DEMO/output/web_animation"

mkdir -p "$OUT"
cd "$DEMO" || exit 1
RV_DEMO_SEED=2026 RV_DEMO_N=100 RV_DEMO_TRACK=200 RV_DEMO_HUD=0 \
RV_DEMO_ANIMATION=1 RV_DEMO_AUTOQUIT=1 RV_DEMO_ANIMDIR="$OUT" RV_DEMO_OUT="$OUT/logs" \
  "$WEBOTS" --batch --mode=fast --minimize --no-rendering --stdout --stderr worlds/disaster_response.wbt
status=$?
ls -la "$OUT"
if [ $status -eq 0 ] && [ $# -ge 1 ]; then
  "$PY" "$HERE/export_web.py" "$OUT" "$1/webots" --vendor "$1/vendor/webots"
fi
exit $status
