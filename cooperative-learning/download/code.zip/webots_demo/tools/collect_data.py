#!/usr/bin/env python3
"""
collect_data.py
===============

Runs worlds/disaster_response.wbt headless once per seed and keeps one folder
of logs per run, for ``analyze_runs.py``.  Nothing of the algorithm is
simulated here: every number comes from the six station controllers inside
Webots; the supervisor only records what they report and what they received.

    python3 tools/collect_data.py --N 100 --track 200 --seeds 2026-2045
    python3 tools/collect_data.py --N 50  --track 200 --seeds 2026-2045

Each run folder (default ``output/runs/N<N>/seed_<seed>/``) holds

    run_config.json   the instance: m, N, k, tau, alpha, A, h, W, graph, seed, ...
    steps.csv         one row per algorithm step t: x*(t), every station's
                      iterate x_i(t), the true deviation theta_i(t), the known
                      route p_i(t), the telemetry y_i(t) it received (t < N),
                      its forecast (t >= N), and the charging station's position
    stations.csv      per station: A-hat (cooperative and local-only), spectral
                      radii, and the messages / reals / bytes it sent
    summary.json      headline metrics and the wall-clock time of the run
    webots.log        the Webots console

Runs that already have a summary.json are skipped (use --force to redo).
A run whose controllers have not started after --start-timeout seconds is
stopped and reported: on this Mac that happens when Webots' saved main-window
size is larger than the screen (see README.md, "If Webots hangs at start").
"""
import argparse
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
DEMO = os.path.normpath(os.path.join(HERE, ".."))
WORLD = os.path.join(DEMO, "worlds", "disaster_response.wbt")
WEBOTS = os.environ.get("WEBOTS", "/Applications/Webots-nightly.app/Contents/MacOS/webots")


def parse_seeds(text):
    seeds = []
    for part in text.split(","):
        if "-" in part:
            a, b = part.split("-")
            seeds.extend(range(int(a), int(b) + 1))
        elif part:
            seeds.append(int(part))
    return seeds


def run_one(seed, args, out):
    run_dir = os.path.join(out, "seed_%d" % seed)
    if os.path.exists(os.path.join(run_dir, "summary.json")) and not args.force:
        print("seed %d: already collected, skipped" % seed, flush=True)
        return True
    os.makedirs(run_dir, exist_ok=True)
    for name in ("summary.json", "steps.csv", "stations.csv", "run_config.json"):
        p = os.path.join(run_dir, name)
        if os.path.exists(p):
            os.remove(p)
    env = dict(os.environ,
               RV_DEMO_SEED=str(seed), RV_DEMO_N=str(args.N), RV_DEMO_TRACK=str(args.track),
               RV_DEMO_OUT=run_dir, RV_DEMO_BATCH="1", RV_DEMO_AUTOQUIT="1")
    cmd = [WEBOTS, "--batch", "--mode=fast", "--no-rendering", "--minimize", "--stdout", "--stderr", WORLD]
    log_path = os.path.join(run_dir, "webots.log")
    t0 = time.time()
    with open(log_path, "w") as log:
        proc = subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT, cwd=DEMO)
        started = False
        while proc.poll() is None:
            time.sleep(1.0)
            elapsed = time.time() - t0
            if not started:
                with open(log_path, errors="ignore") as f:
                    started = "Starting controller" in f.read()
                if not started and elapsed > args.start_timeout:
                    proc.kill()
                    proc.wait()
                    print("seed %d: Webots did not start its controllers within %.0f s; stopped.\n"
                          "  If this repeats, Webots' saved window is probably larger than the screen:\n"
                          "  defaults write com.cyberbotics.Webots-R2025a MainWindow.size -string \"@Size(1440 820)\""
                          % (seed, args.start_timeout), flush=True)
                    return False
            if elapsed > args.timeout:
                proc.kill()
                proc.wait()
                print("seed %d: timed out after %.0f s" % (seed, elapsed), flush=True)
                return False
    ok = os.path.exists(os.path.join(run_dir, "summary.json"))
    print("seed %d: %s in %.0f s -> %s" % (seed, "ok" if ok else "FAILED (see webots.log)",
                                           time.time() - t0, os.path.relpath(run_dir, DEMO)), flush=True)
    return ok


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seeds", default="2026-2045", help="e.g. 2026-2045 or 1,2,5")
    ap.add_argument("--N", type=int, default=100, help="data-collection length N")
    ap.add_argument("--track", type=int, default=200, help="tracking horizon after N")
    ap.add_argument("--out", default=None, help="default: output/runs/N<N>")
    ap.add_argument("--timeout", type=float, default=900.0, help="seconds per run")
    ap.add_argument("--start-timeout", type=float, default=60.0)
    ap.add_argument("--force", action="store_true", help="redo runs that already have a summary")
    args = ap.parse_args()
    if not os.path.exists(WEBOTS):
        sys.exit("Webots not found at %s (set WEBOTS=/path/to/webots)" % WEBOTS)
    # absolute: the supervisor runs in its own controller folder, where a relative path would land
    out = os.path.abspath(args.out or os.path.join(DEMO, "output", "runs", "N%d" % args.N))
    os.makedirs(out, exist_ok=True)
    seeds = parse_seeds(args.seeds)
    print("collecting %d runs, N = %d, tracking %d steps -> %s" % (len(seeds), args.N, args.track, out), flush=True)
    failed = [s for s in seeds if not run_one(s, args, out)]
    print("done: %d ok, %d failed%s" % (len(seeds) - len(failed), len(failed),
                                        (" (%s)" % ", ".join(map(str, failed))) if failed else ""), flush=True)
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
