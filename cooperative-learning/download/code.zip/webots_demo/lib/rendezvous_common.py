"""
rendezvous_common.py
====================

Shared configuration and the per-agent pieces of Algorithm 1 for the Webots
simulation of case study (A) (a mobile charging robot for disaster-response
UAVs) of

    "Cooperative Learning of Shared Latent Dynamics for Distributed Online
     Optimization".

The six agency stations are the agents: each receives the telemetry of its own
UAV only, and they exchange only 2x2 moment matrices and tracking variables.
The mission moves: the six UAVs fly a search line abreast whose centre circles
the incident site, each in its own lane, so the best charging position x*(t)
travels around the site.  A wheeled charging robot (physics, own controller),
which is not an agent, receives the stations' iterates by radio and drives to
their mean; UAVs land on its pad to recharge.  The supervisor owns the UAV
deviations and the scenery.

The reference implementation of the algorithm is
``paper_v4_package/code/experiments.py``; the functions below are the
single-agent versions of ``window_estimates``, ``iv_moments`` and
``identify`` from that file.

Demo setting (deviations from Table 1 of the paper are marked "DEMO"):

    m = 6 robots / UAVs, communication graph: two nearest neighbors of each station
    shared dynamics        A  = 0.99 Rot(0.15)      (period ~42 steps)
    process noise          Q  = 0.05^2 I
    initial deviation      P0 = 2.5^2 I             DEMO (paper: 4^2 I) -> tighter loops, clearer picture
    UAV position noise     sigma_b = 0.75 units      DEMO: paper gives R = 1.5^2 I on the gradient;
                                                     a position error e gives gradient error 2 h_i e,
                                                     so sigma_b = 1.5 / (2 h_i) ~ 0.75 for h_i = 1
    priorities h_i and slots bbar_i: explicit values  DEMO (paper draws them from U[0.5,1.5], U[3,8])
    window k = 2, step size alpha = 0.2, consensus rounds tau = 3, rho_max = 0.999   (paper)
    data collection N = 100 steps, tracking horizon 200 steps                       (paper, trial figure)

World units: 1 paper unit = SCALE metres.
"""
import json
import math
import os

import numpy as np

# ----------------------------------------------------------------------------
# problem instance
# ----------------------------------------------------------------------------
M = 6                                   # agency stations = UAVs
SCALE = 0.5                             # metres per paper unit in this diorama
                                        # (the paper reads one unit as 10 m; the diorama
                                        # is scaled down so the whole site fits in one view)

PRIORITIES = [1.0, 1.4, 0.6, 1.2, 0.8, 1.0]        # h_i, service rate (paper range [0.5, 1.5])
SLOT_RADII = [5.0, 7.0, 4.0, 6.5, 5.5, 7.5]        # ||bbar_i|| (paper range [3, 8])
SLOT_ANGLES = [2 * math.pi * i / M for i in range(M)]
SLOTS = np.array([[r * math.cos(a), r * math.sin(a)] for r, a in zip(SLOT_RADII, SLOT_ANGLES)])

# The mission: a search line abreast whose centre circles the site.  Each drone
# flies its own lane of the line plus its own small loop, and no other station
# is told that route.  The unknown part of each position is the shared wind.
RING_CENTER = (0.0, 0.7)                 # paper units: the burning warehouse
RING_RADIUS = 9.0                        # units (4.5 m in the diorama), clear of the fire and the stations
RING_PERIOD = 600                        # steps per lap: one lap in the 600 steps of the video
RING_PHASE0 = -math.pi / 2               # the line starts south of the site, by the access road
LANE_OFFSETS = [-4.5, -2.7, -0.9, 0.9, 2.7, 4.5]   # units along the line (radial), one lane per UAV
PATROL_RADIUS = [0.8, 0.9, 0.6, 0.85, 0.7, 0.95]   # units, the small loop each drone flies in its lane
PATROL_PERIOD = [64, 84, 56, 76, 70, 96]
PATROL_SIGN = [1, -1, 1, -1, 1, -1]

# One agency per UAV, in the order of the slots.  The scene is one incident:
# a solvent warehouse on North Wharf is burning and an office wing has fallen.
# UAV 2 (index 1) watches the burning hall; it has the highest service rate.
AGENCIES = ["police", "fire", "medical", "search & rescue", "utilities", "civil protection"]
SITES = ["collapsed office wing", "burning hall", "triage point", "fallen roof",
         "ruptured gas line", "blocked exit road"]
SERVICE_UAV = int(np.argmax(PRIORITIES))

# The paper's graph is the ring plus the long chords (1,4), (2,5), (3,6),
# so every station has degree 3, including the station across the site.
# This demo keeps only the nearest neighbors: the two stations beside it.

OMEGA, RHO = 0.15, 0.99
A_TRUE = RHO * np.array([[math.cos(OMEGA), -math.sin(OMEGA)], [math.sin(OMEGA), math.cos(OMEGA)]])
Q_STD = 0.05
P0_STD = 2.5
SENSOR_STD = 0.75                        # std of the UAV position measurement (paper units)

K_WINDOW = 2
ALPHA = 0.2
TAU = 3
RHO_MAX = 0.999

# RV_DEMO_N / RV_DEMO_TRACK shorten a run (smoke tests) or set the data
# collection of tools/collect_data.py.  The video leaves them unset: N = 100,
# then a long tracking window so each UAV's path and the moving charging
# station are visible.  The paper's runs (tools/collect_data.py) track for 200.
N_DATA = int(os.environ.get("RV_DEMO_N", "100"))
T_TRACK = int(os.environ.get("RV_DEMO_TRACK", "500"))
T_TOTAL = N_DATA + T_TRACK

# ----------------------------------------------------------------------------
# simulation timing and visuals
# ----------------------------------------------------------------------------
BASIC_TIME_STEP = 32                     # ms, must match WorldInfo.basicTimeStep
SUBSTEPS = 10                            # basic steps per algorithm step (0.32 s)
LANDING_SECONDS = 9.0

UAV_ALT_SENSING = 3.40                   # m, cruise height, clear of every ruin, for the whole run
UAV_ALT_STAGGER = 0.10                   # m, per-UAV altitude offset, avoids visual overlaps
# Landing pad on the charging robot, in the robot's frame (local +x forward, +z up),
# and the height of a landed UAV's body origin above the pad surface.
PAD_LOCAL = np.array([-0.06, 0.0, 0.405])
UAV_PAD_CLEARANCE = 0.06
STATION_RADIUS = 6.55                    # m, agency robots stand outside the ruins
CHARGER_START = (0.0, -7.4)              # m, the charging robot's depot, south of the site
PATH_BEADS = 150                         # dots of the charging robot's recent ground track (ring buffer)
PATH_SPACING = 0.20                      # m between dots
UAV_PATH_BEADS = 80                      # dots of one UAV's recent path (ring buffer, about one lap)
UAV_PATH_SPACING = 0.16                  # m between those dots
MAST_TOP_Z = 0.78                        # m, where the radio / telemetry lines attach

# Head-up display: Display overlays of the supervisor, (width, height) in pixels,
# and where tools/make_world.py places them in the 3D view, as fractions of its
# width and height (Webots stores overlay positions as fractions, so only
# left-anchored panels stay flush when the view is resized for a movie).
# One 300-pixel column on the left, stacked flush in a 674-pixel-high view
# (taller views, such as the 1280x720 movie, get small gaps instead of
# overlaps); the camera (rendezvous_supervisor.py) puts the scene to its right.
HUD_PANELS = {
    "hud_top": ((300, 156), (0.0, 0.0)),
    "hud_side": ((300, 238), (0.0, 0.2344)),
    "hud_chart": ((300, 156), (0.0, 0.5905)),
    "hud_legend": ((300, 112), (0.0, 1.0)),
}

COLORS = [                               # robot i and UAV i share a color
    (0.90, 0.20, 0.20),
    (0.20, 0.55, 0.95),
    (0.20, 0.75, 0.30),
    (0.95, 0.65, 0.10),
    (0.70, 0.30, 0.85),
    (0.10, 0.75, 0.80),
]

# communication channels
CH_NETWORK = 1          # station <-> station (gradient tracking, consensus)
CH_STATUS = 2           # station -> supervisor (display and logs only)
CH_DISPATCH = 3         # station -> charging robot: the station's current iterate x_i(t)
CH_TELEMETRY_BASE = 10  # supervisor -> station i on channel 10 + i (UAV i position, only t < N)

# charging robot (protos/DemoChargingRobot.proto, controllers/charging_robot)
ROBOT_WHEEL_RADIUS = 0.13                # m
ROBOT_AXLE = 0.74                        # m between the driven wheels
ROBOT_V_MAX = 0.75                       # m/s
ROBOT_W_MAX = 1.6                        # rad/s


# ----------------------------------------------------------------------------
# graph
# ----------------------------------------------------------------------------
def adjacency():
    """Undirected nearest-neighbor graph of the station positions.

    On this layout each station has two neighbors at the same shortest
    distance, the stations on either side. The station opposite is not linked.
    """
    p = np.stack([station_xy(i) for i in range(M)])
    d = np.linalg.norm(p[:, None, :] - p[None, :, :], axis=2)
    np.fill_diagonal(d, np.inf)
    nearest = float(d.min())
    adj = d <= nearest * 1.01
    np.fill_diagonal(adj, False)
    return adj


def edges():
    adj = adjacency()
    return [(i, j) for i in range(M) for j in range(i + 1, M) if adj[i, j]]


def neighbors(i):
    return [j for j in range(M) if adjacency()[i, j]]


def metropolis_row(i):
    """Row i of the Metropolis matrix; needs only the degrees of the neighbors."""
    adj = adjacency()
    deg = adj.sum(axis=1)
    w = {}
    for j in neighbors(i):
        w[j] = 1.0 / (1.0 + max(deg[i], deg[j]))
    w[i] = 1.0 - sum(w.values())
    return w


# ----------------------------------------------------------------------------
# single-agent pieces of Algorithm 1 (see experiments.py for the stacked versions)
# ----------------------------------------------------------------------------
def gradient(h, bbar, x, theta):
    """grad_x f_i(x, theta) = 2 h (x - bbar - theta)."""
    return 2.0 * h * (x - bbar - theta)


def window_estimates(h, bbar, y_pos, k):
    """Gauss--Markov window estimates (eq. (5)) of theta_i(t), t = 0..N-k.

    y_pos[t] is the measured UAV position at time t.  The gradient measurement
    of the paper is ytilde(t) = C theta(t) + noise with C = -2 h I; here
    ytilde(t) = -2 h (y_pos(t) - bbar).  With constant C and R = sigma^2 I the
    Gauss--Markov estimate reduces to the window mean, but we keep the general
    form (C^T R^-1 C)^-1 C^T R^-1 ybar so that the correspondence is explicit."""
    y = np.asarray(y_pos)
    N = len(y)
    C = -2.0 * h * np.eye(2)
    Cbar = np.vstack([C] * k)                       # k windows stacked
    G = Cbar.T @ Cbar                               # R = sigma^2 I cancels
    out = np.zeros((N - k + 1, 2))
    for t in range(N - k + 1):
        ybar = (-2.0 * h * (y[t:t + k] - bbar)).reshape(-1)
        out[t] = np.linalg.solve(G, Cbar.T @ ybar)
    return out


def iv_moments(th, k):
    """Local instrumental-variable moments (eq. (8)):
    M0 = 1/(N-2k) sum_{t=k}^{N-k-1} th(t+0) th(t-k)^T,  M1 = ... th(t+1) th(t-k)^T."""
    N = len(th) + k - 1
    ts = np.arange(k, N - k)
    Z = th[ts - k]
    M0 = th[ts].T @ Z / len(ts)
    M1 = th[ts + 1].T @ Z / len(ts)
    return M0, M1


def identify(M0, M1, rho_max=RHO_MAX):
    """A_hat = M1 M0^-1 with the spectral-radius safeguard of the paper."""
    A_hat = M1 @ np.linalg.inv(M0)
    rho = float(np.max(np.abs(np.linalg.eigvals(A_hat))))
    if rho > rho_max:
        A_hat = A_hat * (rho_max / rho)
    return A_hat, rho


def line_center(t):
    """Centre of the search line at step t and its radial / tangential unit vectors."""
    phi = RING_PHASE0 + 2.0 * math.pi * float(t) / RING_PERIOD
    radial = np.array([math.cos(phi), math.sin(phi)])
    tangent = np.array([-math.sin(phi), math.cos(phi)])
    return np.asarray(RING_CENTER) + RING_RADIUS * radial, radial, tangent


def tasking(i, t):
    """Known plan p_i(t) of drone i only, in paper units; station j never receives it.

    Drone i holds lane LANE_OFFSETS[i] of a search line abreast (the line points
    radially, its centre circles the site once every RING_PERIOD steps) and flies
    its own small loop in that lane.  Its actual position is p_i(t) + theta_i(t),
    where the deviation theta_i is the wind push that the stations must learn."""
    center, radial, tangent = line_center(t)
    ang = SLOT_ANGLES[i] + PATROL_SIGN[i] * 2.0 * math.pi * float(t) / PATROL_PERIOD[i]
    r = PATROL_RADIUS[i]
    return center + LANE_OFFSETS[i] * radial + r * (math.cos(ang) * tangent + 0.55 * math.sin(ang) * radial)


def vehicle_point(theta, t=0):
    """Best charging position x*(t) = sum_i h_i b_i(t) / sum_i h_i (paper units)."""
    h = np.asarray(PRIORITIES)[:, None]
    b = np.stack([tasking(i, t) for i in range(M)]) + np.asarray(theta)
    return (h * b).sum(axis=0) / h.sum()


def rendezvous_point(theta, t=0):
    """Alias of vehicle_point, kept so older calls keep working."""
    return vehicle_point(theta, t)


# ----------------------------------------------------------------------------
# geometry helpers
# ----------------------------------------------------------------------------
def station_xy(i):
    """Command post of agency i, outside the ruins, on the ray of its observation post."""
    a = SLOT_ANGLES[i]
    return np.array([STATION_RADIUS * math.cos(a), STATION_RADIUS * math.sin(a)])


def uav_altitude(i, t):
    """The UAVs stay at cruise height. Losing telemetry only cuts the radio link."""
    return UAV_ALT_SENSING + UAV_ALT_STAGGER * i


def wrap_angle(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


# ----------------------------------------------------------------------------
# messages (JSON strings over Webots Emitter/Receiver)
# ----------------------------------------------------------------------------
def pack(**kw):
    return json.dumps(kw, separators=(",", ":"))


def unpack(s):
    return json.loads(s)
