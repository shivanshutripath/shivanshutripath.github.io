"""
rendezvous_hud.py
=================

Head-up display of the Webots demo: four Display overlays of the supervisor,
stacked in one 300-pixel column on the left of the view; the camera puts the
scene to their right.

    hud_top     title, phase timeline and step counter, what happens now
    hud_side    the six stations: telemetry link, error of their estimate of A
                (together vs. alone), and what they have sent over the radio
    hud_chart   live tracking error, charging-station error, disagreement
    hud_legend  what the glyphs of the 3D scene mean

The overlays are placed by the .wbproj written by tools/make_world.py; in the
Webots window they can be dragged, resized, or closed like any device overlay.
Everything here is display only: nothing is read back by the algorithm.
"""
import math

# palette (dark glass panels; Okabe--Ito blue/orange for together/alone, as in the paper's figures)
BG = 0x0F172A
BG_ALPHA = 0.84
TEXT = 0xF8FAFC
TEXT2 = 0xCBD5E1
MUTED = 0x94A3B8
GRID = 0x334155
C_COLLECT = 0x38BDF8   # data collection (telemetry on)
C_IDENT = 0xFBBF24     # identification (consensus on the moments)
C_TRACK = 0xFB923C     # forecasting and tracking (telemetry lost)
C_DONE = 0x4ADE80
C_COOP = 0x56B4E9      # together (cooperative identification)
C_LOCAL = 0xE69F00     # alone (local identification)
C_STAR = 0xFACC15      # x*(t)
C_CHARGER = 0xF1F5F9
C_DIS = 0xC4B5FD
C_TELEMETRY = 0xFDE047

UI = "Tahoma"
MONO = "Lucida Console"
TITLE = "Verdana"
# average advance per character, in units of the font size, measured on Webots' renderer
CHAR_W = {UI: 0.58, MONO: 0.70, TITLE: 0.68}


def text_width(s, font=UI, size=13, caps=False):
    return int(len(s) * size * (CHAR_W.get(font, 0.62) + (0.17 if caps else 0.0)))


def hexcolor(rgb):
    r, g, b = (max(0, min(255, int(round(255 * v)))) for v in rgb)
    return (r << 16) | (g << 8) | b


class Panel:
    """A Display overlay with a dark translucent background."""

    def __init__(self, display):
        self.d = display
        self.w = display.getWidth()
        self.h = display.getHeight()

    def clear(self, x=0, y=0, w=None, h=None):
        d = self.d
        w = self.w - x if w is None else w
        h = self.h - y if h is None else h
        d.setOpacity(1.0)
        d.setAlpha(0.0)
        d.fillRectangle(x, y, w, h)
        d.setAlpha(BG_ALPHA)
        d.setColor(BG)
        d.fillRectangle(x, y, w, h)
        d.setAlpha(1.0)

    def text(self, s, x, y, color=TEXT, size=13, font=UI):
        d = self.d
        d.setAlpha(1.0)
        d.setOpacity(1.0)
        d.setFont(font, size, True)
        d.setColor(color)
        d.drawText(s, int(x), int(y))

    def rect(self, x, y, w, h, color, opacity=1.0):
        d = self.d
        d.setAlpha(1.0 if opacity >= 1.0 else BG_ALPHA)
        d.setOpacity(opacity)
        d.setColor(color)
        d.fillRectangle(int(x), int(y), max(1, int(w)), max(1, int(h)))
        d.setOpacity(1.0)
        d.setAlpha(1.0)

    def line(self, x1, y1, x2, y2, color, opacity=1.0):
        d = self.d
        d.setAlpha(1.0)
        d.setOpacity(opacity)
        d.setColor(color)
        d.drawLine(int(x1), int(y1), int(x2), int(y2))
        d.setOpacity(1.0)

    def thick(self, x1, y1, x2, y2, color, width=2):
        """Line of a few pixels (Display lines are one pixel wide)."""
        if abs(x2 - x1) >= abs(y2 - y1):
            for k in range(width):
                self.line(x1, y1 + k - width // 2, x2, y2 + k - width // 2, color)
        else:
            for k in range(width):
                self.line(x1 + k - width // 2, y1, x2 + k - width // 2, y2, color)

    def dot(self, cx, cy, r, color, filled=True):
        d = self.d
        d.setAlpha(1.0)
        d.setOpacity(1.0)
        d.setColor(color)
        if filled:
            d.fillOval(int(cx), int(cy), int(r), int(r))
        else:
            d.drawOval(int(cx), int(cy), int(r), int(r))


def clear_displays(sv, names=("hud_top", "hud_side", "hud_chart", "hud_legend")):
    """Make the HUD overlays fully transparent (used when the HUD is switched off)."""
    for n in names:
        d = sv.getDevice(n)
        if d is None:
            continue
        d.setOpacity(1.0)
        d.setAlpha(0.0)
        d.fillRectangle(0, 0, d.getWidth(), d.getHeight())


PHASE_COLOR = {"collect": C_COLLECT, "identify": C_IDENT, "track": C_TRACK, "done": C_DONE}
PHASE_NAME = {"collect": "COLLECT", "identify": "LEARN A", "track": "TRACK", "done": "DONE"}


class Hud:
    """All four panels.  ``C`` is rendezvous_common (instance, names, colors)."""

    def __init__(self, sv, C, T_total):
        self.C = C
        self.T = T_total
        self.N = C.N_DATA
        get = sv.getDevice
        self.top = Panel(get("hud_top"))
        self.side = Panel(get("hud_side"))
        self.chart = Panel(get("hud_chart"))
        self.legend = Panel(get("hud_legend"))
        self.colors = [hexcolor(c) for c in C.COLORS]
        self.prev = {}                     # last plotted sample per series
        self.side_key = None
        self.chart_N_marked = False
        self.draw_legend()
        self.draw_chart_frame()

    # ------------------------------------------------------------------ top
    def draw_top(self, t, sim_s, phase, lines):
        """lines: up to three short lines (<= 38 characters) saying what happens now."""
        p = self.top
        p.clear()
        col = PHASE_COLOR[phase]
        p.rect(0, 0, p.w, 4, col)
        p.text("Cooperative learning", 14, 8, TEXT, 14, TITLE)
        p.text("of shared latent dynamics · Webots", 14, 28, MUTED, 11)
        # timeline: [collect | forecast + track], marker at t = N, cursor at t
        x0, x1, yb, hb = 14, p.w - 14, 49, 11
        span = x1 - x0
        xn = x0 + span * self.N / float(self.T)
        p.rect(x0, yb, xn - x0, hb, C_COLLECT, 0.30)
        p.rect(xn, yb, x1 - xn, hb, C_TRACK, 0.30)
        tt = max(0, min(t, self.T))
        xc = x0 + span * tt / float(self.T)
        if xc > x0:
            p.rect(x0, yb, min(xc, xn) - x0, hb, C_COLLECT)
        if xc > xn:
            p.rect(xn, yb, xc - xn, hb, C_TRACK)
        p.rect(xn - 1, yb - 3, 3, hb + 6, C_IDENT)
        p.rect(xc - 1, yb - 4, 3, hb + 8, TEXT)
        xl = max(xn - 18, x0 + text_width("collect ", UI, 10))
        p.text("collect", x0, yb + hb + 3, C_COLLECT, 10)
        p.text("learn A", xl, yb + hb + 3, C_IDENT, 10)
        p.text("forecast + track", xl + text_width("learn A  ", UI, 10), yb + hb + 3, C_TRACK, 10)
        # phase chip and step counter
        chip = PHASE_NAME[phase]
        cw = 12 + text_width(chip, UI, 12, caps=True)
        p.rect(14, 80, cw, 20, col)
        p.text(chip, 20, 83, 0x0B1220, 12, UI)
        p.text("t = %d / %d" % (min(t, self.T), self.T), 14 + cw + 10, 83, TEXT, 12, MONO)
        p.text("%.0f s" % sim_s, p.w - 14 - text_width("%.0f s" % sim_s, MONO, 11), 84, MUTED, 11, MONO)
        for k, s in enumerate(lines[:3]):
            p.text(s, 14, 105 + 16 * k, TEXT if k < 2 else MUTED, 12 if k < 2 else 11)

    # ----------------------------------------------------------------- side
    def draw_side(self, rows, t, summary):
        """rows[i] = dict(live=bool, coop=float|None, local=float|None)."""
        key = (tuple((r["live"], r["coop"], r["local"]) for r in rows), summary.get("stage"),
               summary.get("reals"), summary.get("round"))
        if key == self.side_key:
            return
        self.side_key = key
        p, C = self.side, self.C
        p.clear()
        p.rect(0, 0, p.w, 4, C_COOP)
        p.text("STATIONS", 12, 8, TEXT, 13, TITLE)
        xi = 160
        bx0, bx1 = 180, p.w - 12
        p.text("link", xi - 9, 12, MUTED, 9)
        p.text("error in A (log)", bx0, 11, MUTED, 10)
        lo, hi = math.log10(0.003), math.log10(1.0)

        def bx(v):
            v = max(min(v, 1.0), 0.003)
            return bx0 + (bx1 - bx0) * (math.log10(v) - lo) / (hi - lo)

        y0, dy = 30, 20
        for tick, lab in ((0.01, "0.01"), (0.1, "0.1"), (1.0, "1")):
            xt = bx(tick)
            p.line(xt, y0 - 2, xt, y0 + 6 * dy - 3, GRID)
            p.text(lab, xt - text_width(lab, MONO, 9) // 2, y0 + 6 * dy - 1, MUTED, 9, MONO)
        for i, r in enumerate(rows):
            y = y0 + dy * i
            p.dot(16, y + 7, 6, self.colors[i])
            p.text("%d %s" % (i + 1, C.AGENCIES[i]), 27, y + 1, TEXT, 11)
            if r["live"]:
                p.dot(xi, y + 7, 5, C_TELEMETRY)
            else:
                p.dot(xi, y + 7, 5, MUTED, filled=False)
            if r["coop"] is not None:
                p.rect(bx0, y + 2, bx(r["coop"]) - bx0, 5, C_COOP)
                p.rect(bx0, y + 9, bx(r["local"]) - bx0, 5, C_LOCAL)
            else:
                p.rect(bx0, y + 7, bx1 - bx0, 2, GRID)
        yf = y0 + 6 * dy + 14
        p.line(12, yf, p.w - 12, yf, GRID)
        p.rect(12, yf + 8, 10, 5, C_COOP)
        p.text("together", 26, yf + 3, C_COOP, 11)
        p.rect(92, yf + 8, 10, 5, C_LOCAL)
        p.text("alone", 106, yf + 3, C_LOCAL, 11)
        p.dot(160, yf + 10, 4, C_TELEMETRY)
        p.text("telemetry", 168, yf + 3, C_TELEMETRY, 10)
        stage = summary.get("stage")
        if stage == "done":
            p.text("mean %.3f together, %.3f alone" % (summary["coop"], summary["local"]), 12, yf + 18, TEXT, 12)
            p.text("%.1f× smaller after %d rounds" % (summary["ratio"], C.TAU), 12, yf + 34, TEXT, 12)
        elif stage == "consensus":
            p.text("consensus round %d of %d" % (summary.get("round", 0), C.TAU), 12, yf + 18, C_IDENT, 12)
            p.text("on two 2×2 moment matrices", 12, yf + 34, TEXT2, 12)
        else:
            p.text("A is learned at t = N = %d" % self.N, 12, yf + 18, TEXT2, 12)
            p.text("from data that never leave", 12, yf + 34, MUTED, 12)
        p.text("sent %s reals each, no positions" % format(summary.get("reals", 0), ","),
               12, yf + 51, MUTED, 11)

    # ---------------------------------------------------------------- chart
    def _cx(self, t):
        return self.cx0 + (self.cx1 - self.cx0) * t / float(max(1, self.T))

    def _cy(self, v):
        v = max(min(v, 10.0), 0.01)
        return self.cy1 - (self.cy1 - self.cy0) * (math.log10(v) + 2.0) / 3.0

    def draw_chart_frame(self):
        p = self.chart
        p.clear()
        p.rect(0, 0, p.w, 4, C_STAR)
        p.text("ERROR TO x*(t)", 12, 8, TEXT, 12, TITLE)
        p.text("units, log scale", 12, 24, MUTED, 10)
        self.cx0, self.cx1 = 40, p.w - 22
        self.cy0, self.cy1 = 42, p.h - 21
        xn = self._cx(self.N)
        p.rect(self.cx0, self.cy0, xn - self.cx0, self.cy1 - self.cy0, C_COLLECT, 0.12)
        for v, lab in ((0.01, "0.01"), (0.1, "0.1"), (1.0, "1"), (10.0, "10")):
            y = self._cy(v)
            p.line(self.cx0, y, self.cx1, y, GRID)
            p.text(lab, self.cx0 - 5 - text_width(lab, MONO, 9), y - 5, MUTED, 9, MONO)
        step = 100 if self.T <= 400 else 200
        for tv in range(0, self.T + 1, step):
            x = self._cx(tv)
            p.line(x, self.cy1, x, self.cy1 + 3, MUTED)
            p.text("%d" % tv, x - text_width(str(tv), MONO, 9) // 2, self.cy1 + 5, MUTED, 9, MONO)
        p.line(self.cx0, self.cy1, self.cx1, self.cy1, MUTED)
        p.line(self.cx0, self.cy0, self.cx0, self.cy1, MUTED)
        lx = p.w - 118
        for k, (col, lab) in enumerate(((C_COOP, "stations, rms"), (C_CHARGER, "robot"), (C_DIS, "disagreement"))):
            y = 5 + 11 * k
            p.rect(lx, y + 4, 12, 3, col)
            p.text(lab, lx + 16, y - 1, TEXT2, 10)

    def chart_add(self, t, series):
        """series: name -> value at step t (None to skip)."""
        p = self.chart
        if t >= self.N and not self.chart_N_marked:
            xn = self._cx(self.N)
            for yy in range(int(self.cy0), int(self.cy1), 6):
                p.line(xn, yy, xn, yy + 3, C_IDENT)
            p.text("telemetry lost", xn + 4, self.cy0 + 1, C_IDENT, 10)
            self.chart_N_marked = True
        col = {"track": C_COOP, "charger": C_CHARGER, "dis": C_DIS}
        for name, v in series.items():
            if v is None or not math.isfinite(v):
                continue
            x, y = self._cx(t), self._cy(v)
            if name in self.prev:
                x0, y0 = self.prev[name]
                p.thick(x0, y0, x, y, col[name], 2 if name == "track" else 1)
            self.prev[name] = (x, y)

    # --------------------------------------------------------------- legend
    def draw_legend(self):
        p = self.legend
        p.clear()
        p.rect(0, 0, p.w, 4, MUTED)
        p.text("IN THE SCENE", 12, 6, TEXT, 12, TITLE)
        items = [
            ("star", "gold beam: best position x*(t)"),
            ("pin", "pin: station i's choice x_i(t)"),
            ("radio", "white line: radio between neighbors"),
            ("tele", "yellow line: telemetry, own UAV, t < N"),
            ("charger", "white robot: the charging robot"),
            ("dots", "dots: recent paths of UAVs and robot"),
        ]
        for k, (kind, lab) in enumerate(items):
            y = 24 + 14 * k
            gx = 20
            if kind == "star":
                p.rect(gx - 2, y, 4, 13, C_STAR)
            elif kind == "pin":
                p.rect(gx - 1, y + 1, 2, 9, self.colors[1])
                p.dot(gx, y + 11, 3, self.colors[1])
            elif kind == "radio":
                p.thick(gx - 9, y + 7, gx + 9, y + 7, 0xFFFFFF, 2)
            elif kind == "tele":
                p.thick(gx - 9, y + 11, gx + 9, y + 3, C_TELEMETRY, 2)
            elif kind == "charger":
                p.rect(gx - 9, y + 2, 18, 9, C_CHARGER)
                p.rect(gx - 5, y + 4, 8, 5, 0x334155)
                p.dot(gx - 5, y + 12, 2, 0x111111)
                p.dot(gx + 5, y + 12, 2, 0x111111)
            else:
                for dx in (-8, -3, 2, 7):
                    p.dot(gx + dx, y + 7, 2, self.colors[(dx + 8) % 6])
            p.text(lab, 36, y, TEXT2, 11)
