# Webots simulation of case study (A): a mobile charging robot for search drones

A 3D, distributed run of case study (A) of *Cooperative Learning of Shared
Latent Dynamics for Distributed Online Optimization*, used in Section 5.2 of
the paper, and for the video.

The incident is a fire in the North Wharf solvent warehouse. Six drones search
the site in a line abreast whose centre circles the warehouse once every 600
steps; each drone holds its own lane and flies its own small loop in it. Six
ground stations, one per drone, are the agents: station *i* knows only drone
*i*'s route and sees only drone *i*, and it talks only to the two stations
next to it. A wheeled **charging robot** carries a landing pad: a drone that
needs power lands on it. The stations agree on where it should be, *x\*(t)*
(the service-rate-weighted centroid of the drones), so the flight to it stays
short; since the drones move around the site, so does the robot.

Every station is a **separate controller process**. Stations talk only through
simulated radio emitters and receivers, and none of them ever sends a position:
only its tracking variables (2 reals per message, 2 messages per step) and, at
*t = N*, three rounds of two 2×2 moment matrices. Each station also radios its
current iterate to the charging robot, whose **own controller** drives it, with
wheel physics, to the mean of the iterates it receives. A supervisor process
plays the environment (the drones and their wind deviations) and records
everything needed to audit and replay a run; it never moves the robot.

![the interface at the end of a run](output/snapshot_07_back_on_watch.png)

## The interface

The scene fills the right of the view; four panels are stacked on the left.

| panel | what it shows |
|---|---|
| title and timeline | the phase of Algorithm 1 (COLLECT, LEARN A, TRACK, DONE), the step *t* out of *T*, the simulated time, and three lines on what is happening now |
| STATIONS | per station: whether its telemetry link is live, and the error ‖Â_i − A‖_F of its estimate with cooperation (blue) and alone (orange), on a log scale; below, the mean errors, the ratio, and how many reals each station has sent |
| ERROR TO x\*(t) | live, log scale: the stations' RMS error to *x\*(t)*, the error of the charging robot, and the disagreement; the band marks data collection and the dashed line *t = N* |
| IN THE SCENE | the legend of the 3D view |

In the scene: the **gold beam** is the true best position *x\*(t)*, which no
station sees; the **thin colored pins** are the stations' iterates *x_i(t)*;
**white lines** are radio links, **yellow lines** the telemetry of each
station's own drone (only while *t < N*); the **white robot** with the landing
pad is the charging robot; **colored dots** are the recent path of each drone
and **orange dots** the robot's recent ground track. The drones fly 3.4–3.9 m
up, so in the three-quarter view they appear above the ground point they
cover; their ground tracks lie around the robot.

The panels are ordinary Webots display overlays: drag, resize, or close them
in the window (Overlays menu to bring them back). `python3 tools/make_world.py
--wbproj-only` puts them back in their column. If you move the camera, the
supervisor stops directing it.

| time | phase | what you see |
|---|---|---|
| 0–32 s | COLLECT, *t < N = 100* | The search line starts south of the warehouse and turns east; each station reads only its own drone (yellow) and runs gradient tracking with its two neighbors; the charging robot leaves its depot, drives up the access track, and joins the line. |
| at *t = N* | LEARN A | The telemetry stops. Each station smooths its own readings, exchanges its moment matrices three times, and estimates *A*. The table fills in: blue bars (together) are about 5× shorter than orange (alone). |
| 32–192 s | TRACK | No station sees its drone. Each forecasts its own with its *Â_i*; the charging robot keeps driving after the mean of the iterates, once around the warehouse. Three drones land on the moving robot, ride along while they charge, and return to their lanes (scenery: the model and *x\*(t)* do not change). |
| end | DONE | Tracking RMSE and the identification gain of the run. |

The run is deterministic for a given seed (`RV_DEMO_SEED`, default 2026). For
seed 2026 with a 200-step horizon: ‖Â_i − A‖_F is 0.019 on average with
cooperation and 0.105 alone (5.6×), the tracking RMSE over *t ∈ [150, 300)*
is 0.29 units, and the charging robot drives about 24 m.

## Running it

macOS 27 cannot start the stable Webots R2025a package (it reports every TCP
port as in use, [cyberbotics/webots#6976](https://github.com/cyberbotics/webots/issues/6976));
use the nightly installed beside it.

```bash
open -a Webots-nightly "webots_demo/worlds/disaster_response.wbt"
# or, from webots_demo/, with the console in the terminal:
/Applications/Webots-nightly.app/Contents/MacOS/webots worlds/disaster_response.wbt
```

The controllers need Python 3 with numpy. Each controller folder has a
`runtime.ini` pointing Webots at `/Users/shivanshutripathi/miniconda3/bin/python3`
(the default `python3` on this Mac is an x86-64 build that does not run). Edit
that path if you use another interpreter. Nothing is downloaded at run time.

Environment variables (all optional): `RV_DEMO_SEED`, `RV_DEMO_N` (default
100), `RV_DEMO_TRACK` (tracking steps, default 500), `RV_DEMO_HUD=0` (no
panels), `RV_DEMO_CAMERA="px,py,pz,tx,ty,tz"` (a fixed camera),
`RV_DEMO_OUT` (log folder, default `output/last_run/`), `RV_DEMO_SNAPSHOTS=1`,
`RV_DEMO_MOVIE=1`, `RV_DEMO_AUTOQUIT=1`, and `RV_DEMO_BATCH=1` (data
collection: no panels, no scenery flights, quit when the logs are written).

### Recording the video

```bash
sh webots_demo/tools/record_movie.sh
```

writes `output/disaster_response.mp4` (1280×720, played at 2×, 1 min 40 s) and
`output/snapshot_01` … `snapshot_07`. Webots enlarges its window for a
1280×720 recording and saves that size; on this Mac a later start with
`--minimize` then hangs (95 % CPU, no output). The script restores the saved
size. **If Webots hangs at start**, quit it and run

```bash
defaults write com.cyberbotics.Webots-R2025a MainWindow.size -string "@Size(1440 842)"
```

The nightly ships an Intel `ffmpeg`, which this Mac cannot run, so movie
export was pointed at the Homebrew ffmpeg: `Webots-nightly.app/Contents/util/ffmpeg`
is a wrapper, and the original binary is still there as `ffmpeg.x86_64`.

## Data collection for the paper

```bash
cd webots_demo
for N in 30 50 100 150 200; do python3 tools/collect_data.py --N $N --track 200 --seeds 2026-2045; done
python3 tools/analyze_runs.py output/runs
python3 tools/check_initial_deviation.py        # Section 5.2: why the errors are twice Figure 2's
```

`collect_data.py` runs the world headless once per seed (about 4 s for a run
of 300 steps) and keeps one folder per run in `output/runs/N<N>/seed_<seed>/`:

| file | contents |
|---|---|
| `run_config.json` | the instance: *m, N, k, τ, α, A*, *h_i*, the graph and its Metropolis matrix *W*, σ, the routes, the noise levels, the seed |
| `steps.csv` | one row per step *t*: *x\*(t)*, and per station its iterate *x_i(t)*, the true deviation θ_i(t), its known route *p_i(t)*, the telemetry it received (*t < N*), and its forecast (*t ≥ N*); the charging robot's position |
| `stations.csv` | per station: Â_i (cooperative) and the local-only estimate, spectral radii, errors, and the messages, reals and bytes it sent |
| `summary.json` | headline metrics and the wall-clock time |

`analyze_runs.py` then

1. re-identifies *A* from the recorded telemetry with `window_estimates`,
   `iv_moments` and `identify` of `paper_v4_package/code/experiments.py` and
   compares the result with the stations' own estimates (largest difference
   over the 100 runs: 5.6e-16);
2. replays the gradient-tracking recursion with the stations' estimates and
   compares it with the logged iterates (largest difference: 7.1e-15), so the
   Webots runs are exact executions of Algorithm 1;
3. replays local identification (τ = 0), exact averaging, the oracle with
   known *A*, and persistence on the same telemetry;
4. writes `output/analysis/` (the numbers quoted in the paper in
   `webots_summary.txt`, per-run `.dat` files, and `table_webots.tex` and
   `fig_webots_sweep.tex`, a table and a sweep figure of all runs that are
   not part of the paper); with `--splice <file.tex>` it replaces any of
   these pieces between its `BEGIN/END generated figure` markers in that file.

Results of the 100 runs (medians; RMSE in paper units of 10 m, over
*t ∈ [N+50, N+200)* as in the paper):

| *N* | RMSE persistence | local | cooperative | oracle *A* | ‖Â−A‖ local | cooperative | exact avg. | ratio |
|---|---|---|---|---|---|---|---|---|
| 30 | 1.547 | 0.631 | 0.385 | 0.357 | 0.0420 | 0.0143 | 0.0125 | 2.9 |
| 50 | 1.115 | 0.527 | 0.394 | 0.339 | 0.0327 | 0.0106 | 0.0100 | 3.1 |
| 100 | 0.825 | 0.446 | 0.376 | 0.369 | 0.0303 | 0.0110 | 0.0097 | 2.7 |
| 150 | 0.631 | 0.402 | 0.337 | 0.336 | 0.0325 | 0.0114 | 0.0108 | 2.8 |
| 200 | 0.451 | 0.374 | 0.316 | 0.308 | 0.0323 | 0.0123 | 0.0108 | 2.6 |

The charging robot itself stays within 0.26–0.34 units (RMS) of *x\*(t)*.
The identification columns are the same as with fixed patrol posts: the
routes are known and subtracted, and for a given seed the wind deviations and
the noise are the same.

## Scale, and what differs from Table 1

All constants are in `lib/rendezvous_common.py`. After changing posts, service
rates, colors, the graph, or the HUD panels, regenerate the world:

```bash
python3 tools/make_world.py
```

The diorama draws one paper unit as 0.5 m, so the whole site fits in one view.
In the paper one unit is 10 m. One algorithm step is ten simulator steps of
32 ms (0.32 s).

| quantity | simulation | paper, Table 1 |
|---|---|---|
| agents, dimension | 6 stations, *n = p = 2* | same |
| graph | ring of nearest neighbors, degree 2, Metropolis, σ = 2/3 | ring + chords (1,4), (2,5), (3,6), degree 3, σ = 0.50 |
| *A* | 0.99 Rot(0.15), period about 42 steps | same |
| process noise | *Q* = 0.05² *I* | same |
| initial deviation | *P0* = 2.5² *I* | 4² *I* |
| telemetry error | 0.75 units (so *R_i* = (1.5 *h_i*)² *I* on the gradient) | *R* = 1.5² *I* on the gradient |
| known part of the cost | *h_i*‖*x* − *p_i(t)*‖², with *p_i(t)* drone *i*'s lane of a search line whose centre circles the site (radius 9 units, 600 steps per lap; lanes −4.5 … 4.5) plus a small loop | *h_i*‖*x* − *b̄_i*‖², fixed observation locations |
| charging station | a wheeled robot (physics) that drives to the mean of the iterates radioed to it | a point *x* |
| service rates *h_i* | 1.0, 1.4, 0.6, 1.2, 0.8, 1.0 | drawn from U[0.5, 1.5] |
| *k, α, τ, ρ_max* | 2, 0.2, 3, 0.999 | same |

The agencies, in order, are police, fire, medical, search and rescue,
utilities, and civil protection.

## Files

```
webots_demo/
  worlds/disaster_response.wbt          generated world (tools/make_world.py)
  worlds/.disaster_response.wbproj      window layout, including where the HUD panels sit
  protos/DemoGroundRobot.proto          one station
  protos/DemoQuadrotor.proto            a drone, placed by the supervisor
  protos/DemoChargingRobot.proto        the charging robot: wheels, casters, landing pad, radio
  lib/rendezvous_common.py              the instance, the mission routes, the per-station algorithm
  lib/rendezvous_hud.py                 the four HUD panels (display only)
  controllers/rendezvous_robot/         Algorithm 1 on one station
  controllers/charging_robot/           drives the charging robot to the mean of the iterates
  controllers/rendezvous_supervisor/    environment, clock, recharge flights, HUD, logs
  tools/make_world.py                   writes the world and the panel layout
  tools/collect_data.py                 headless runs, one folder of logs per seed
  tools/analyze_runs.py                 checks, replayed baselines, numbers of Section 5.2, table/figures of all runs (not in the paper)
  tools/check_initial_deviation.py      synthetic check quoted in Section 5.2 of the paper
  tools/record_movie.sh                 the video and the stills
  output/                               video, stills, last_run/, runs/, analysis/
```

`protos/DemoChargingVehicle.proto` and `controllers/charging_vehicle/` are
from an earlier version with a ground vehicle; the world no longer uses them.
The previous version with an overhead charger over fixed patrol posts, its
paper text, and its 100 runs are in `output/previous_version/`.

The code calls this case study `rendezvous`, as in
`paper_v4_package/code/experiments.py`.

| in the paper | in the station controller |
|---|---|
| gradient at the iterate, *t < N* | `gradient_signal`: 2 *h_i* (*x_i* − *y_i*) from the station's own telemetry |
| windowed reconstruction | `rendezvous_common.window_estimates` |
| instrumental-variable moments | `rendezvous_common.iv_moments` |
| τ rounds of average consensus | `identification`, then the `consensus` phase of `advance` |
| Â_i = M₁ M₀⁻¹, safeguard ρ ≤ 0.999 | `rendezvous_common.identify` |
| forecast | `theta_hat` |
| gradient tracking | `advance` |

Every algorithm step starts with a tick from the supervisor on channel 10 + *i*.
Stations broadcast on channel 1 and keep only their neighbors' messages.
Status messages on channel 2 are for the display and the logs, not for the algorithm.
