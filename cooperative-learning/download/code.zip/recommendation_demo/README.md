# Case study (B) as a product recommendation platform: a full simulation

A concrete, end-to-end run of case study (B) of *Cooperative Learning of
Shared Latent Dynamics for Distributed Online Optimization* (Section 5.1,
"Decentralized federated recommendation"): an online marketplace with eight
regional data centers, 32 named products, 4,000 shoppers, and the session logs
from which each server measures its region's interests. The model, the
measurements the servers compute from their data, and Algorithm 1 are the
paper's: the simulation reproduces `experiments.run_trial` (the trial of the
paper's Figure 3(b)), its Monte Carlo reproduces the paper's N-sweep, and a
second implementation runs every server as its own OS process. On top of the
paper's model it shows what the boosts do to the products each shopper sees.

## The marketplace

The platform serves its shoppers from eight regional data centers. Data-residency
rules keep each region's data in its own data center and there is no central
server; each server talks only to its two or three neighbors on the backbone of
the paper's Figure 3(a), the ring 1–2–…–8–1 with the chords (1,5) and (3,7)
(Metropolis weights, contraction factor σ = 0.683).

| server | region | data center | λ_i | ū_i: outdoor, home, tech | neighbors |
|---:|---|---|---:|---|---|
| 1 | NAM North America | Chicago | 0.655 | 2.21, 2.45, 2.94 | EU, SEA, LA |
| 2 | EU Europe | Frankfurt | 0.405 | 2.70, 2.78, 2.35 | NAM, MEA |
| 3 | MEA Middle East & Africa | Johannesburg | 0.485 | 2.23, 2.41, 1.02 | EU, SA, OC |
| 4 | SA South Asia | Mumbai | 0.459 | 2.43, 1.55, 1.30 | MEA, SEA |
| 5 | SEA Southeast Asia | Singapore | 0.667 | 1.52, 2.35, 1.59 | NAM, SA, EA |
| 6 | EA East Asia | Tokyo | 0.673 | 2.42, 2.11, 2.04 | SEA, OC |
| 7 | OC Oceania | Sydney | 0.447 | 1.39, 2.10, 1.69 | MEA, EA, LA |
| 8 | LA Latin America | Sao Paulo | 0.480 | 1.10, 2.82, 1.40 | NAM, OC |

λ_i (the ridge weight, `varpi` in experiments.py) and the known average
interests ū_i are the paper's instance (seed 2026). The region names, data
centers, genre names, products and shoppers are the concrete layer of this demo.
North America's code is `NAM` rather than `NA`, which pandas and R read as a
missing value.

**Genres.** The three boosted genres are the paper's ℓ = 1, 2, 3, and the
shared dynamics A = blkdiag(0.98 Rot(0.25), 0.95), unknown to the servers, give
them their meaning. One step is one day.

| genre | products (8 each, `output/data/catalog.csv`) | drift θ_i,ℓ(t) |
|---|---|---|
| Outdoor & Sports | trail running shoes, backpacking tent, water bottle, yoga mat, … | a damped cycle of 2π/0.25 ≈ 25 days, shared with Home & Kitchen |
| Home & Kitchen | cast-iron skillet, air fryer, pour-over coffee set, chef's knife, … | the same cycle, a quarter period (about 6 days) behind Outdoor & Sports |
| Trending Tech | wireless earbuds, LED light strip, mini projector, … | a hype that fades: the excess interest shrinks by 5% a day |
| Everyday Essentials | detergent pods, paper towels, toothpaste, … | never boosted |

**Feeds.** The ranking model is shared. Shopper s of region i scores product j as

    score_s,j(x) = b_j + a_s,g(j) + e_s,j + x_g(j)     (boosted genres)
    score_s,j    = b_j + e_s,j                          (essentials)

with the product's base score b_j, the shopper's genre affinity
a_s = 0.5 (ū_i − mean(ū_i)) + 0.4 z, a fixed personal taste e_s,j ~ N(0, 0.3²),
and the three common boosts x, the logit shifts the servers must agree on. The
first screen is the top 8 products. The affinities follow the region's known
averages, so first screens differ by region: under the ideal boosts on day 150,
Home & Kitchen fills 67% of the slots in Latin America and Outdoor & Sports 51%
in South Asia. Without boosts, essentials fill 69% of all slots.

## What each server receives

While data flow (days 0–99, N = 100), server i receives, once a day and only
from its own region:

* **its exploration sessions**: 100 sessions served without boosts (x = 0).
  Each logs a net engagement score per genre (positive minus negative
  interactions with the genre's products, normalized), drawn from the paper's
  region-level model, N(u_i(t), 3² I) around the region's true interest
  u_i(t) = ū_i + θ_i(t), and labelled with a shopper of the region drawn at
  random. The server averages the day's scores, û_i(t), and computes the
  paper's measurement ỹ_i(t) = y_i(0, t) − ∇f_i^0(0) = C_i(0)(û_i(t) − ū_i)
  = C_i(0)θ_i(t) + w_m,i(t), with C_i(0) = −I/2 and the measurement noise
  w_m,i(t) ~ N(0, 0.15² I) (the paper's w_{m,i}(t); its w_i(t) is the process
  noise of θ_i). `rcdemo/simulate.py` draws the scores conditionally on their
  mean, which it sets with the paper's own draw w_m,i(t): for Gaussian samples
  the mean and the deviations from it are independent, so the logs have the
  model's distribution, and the measurements equal the paper's to 1.6e-15;
* **the gradient report of its training job** at the boosts it serves,
  ∇f_i(x_i(t), θ_i(t)) + noise, which drives gradient tracking during data
  collection (the paper's oracle at the iterate).

From day 100 on it receives nothing: it forecasts its region's interests with
its estimate of A and keeps tuning the boosts by gradient tracking on the
forecast gradients until day 299. Across the backbone the servers exchange only
x_i − αs_i and s_i + γ_i(t+1) − γ_i(t) (3 reals each, every day) and, on day 99,
three rounds of their 3×3 moment matrices (M0, M1).

## Running it

```bash
cd "recommendation_demo"
python3 run_demo.py                 # the showcase trial: data, metrics, examples, check (~11 s)
python3 run_distributed.py          # the same trial, one OS process per regional server (~2 s)
python3 run_montecarlo.py --jobs 6  # 50 trials x N = 30, 50, 100, 150, 200 (~6 min)
python3 make_figures.py             # output/figures/*.png and *.pdf, from the CSVs
python3 make_dashboard_data.py      # the page-ready tables in output/dashboard/
python3 make_website_data.py --out ~/website/cooperative-learning/data/recommendation.js   # the project page's section
python3 -m pytest -q tests          # the test suite (130 tests, ~2 min)
```

Use `/Users/shivanshutripathi/miniconda3/bin/python3` (the `python3` on this
Mac's PATH is a stub). The simulation needs only numpy; the figures need
matplotlib, and the tests pytest and scipy. Every script takes `--out`.
`run_demo.py` also takes `--N`, `--trial`, `--seed` and `--no-sessions` (the
paper's measurement model instead of session logs). `make_figures.py` reads the
run in `--src` (default `output/`), so plotting another run needs
`--src <that run's folder>`. `make_dashboard_data.py` re-simulates the trial of
`--N`/`--trial` and tabulates the Monte Carlo summary in `--mc`.
`run_montecarlo.py --quick` (5 trials per N) writes to
`output/montecarlo_quick/`, never over the paper's sweep. The paper's code in
`../paper_v4_package/code` is imported, never modified.

## Results of the showcase trial (N = 100, trial 0)

This is trial 0 of the paper's N-sweep at N = 100, the trial of Figure 3(b);
the metrics use the paper's window, days 150–299.

**Learning A (day 100).** ‖Â_i − A‖_F per server:

| | NAM | EU | MEA | SA | SEA | EA | OC | LA | mean |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| local (alone) | 0.094 | 0.199 | 0.473 | 0.047* | 0.075 | 0.046 | 0.809* | 0.077 | 0.227 |
| cooperative, τ = 3 | 0.024 | 0.026 | 0.025 | 0.029 | 0.031 | 0.037 | 0.030 | 0.025 | 0.028 |
| exact averaging | 0.027 | 0.027 | 0.027 | 0.027 | 0.027 | 0.027 | 0.027 | 0.027 | 0.027 |

\* raw estimate not Schur stable (spectral radius 1.004 and 1.057), rescaled to
0.999 by the safeguard. Cooperation lowers the mean error 8.0× (√m = 2.83).
South Asia shows why stability matters more than the Frobenius error: its
local estimate is close to A (0.047), but at spectral radius 0.999 instead of
0.98 its forecast of the Outdoor/Home cycle stops decaying, and its interest
forecast RMSE is 0.231, against 0.069 with cooperation.

**After the data stop.** Metrics per method (`output/kpis.csv`):

| method | boost RMSE | forecast RMSE | ideal first screen | genre-mix error |
|---|---:|---:|---:|---:|
| oracle Kalman filter (in experiments.py, not discussed in the paper) | 0.0167 | 0.083 | 94.1% | 0.31 pp |
| oracle A | 0.0179 | 0.087 | 93.6% | 0.34 pp |
| centralized predictor | 0.0167 | 0.088 | 94.0% | 0.32 pp |
| exact averaging | 0.0183 | 0.087 | 93.5% | 0.34 pp |
| **cooperative, τ = 3** | **0.0184** | **0.088** | **93.4%** | **0.35 pp** |
| cooperative, τ = 1 | 0.0187 | 0.088 | 93.3% | 0.35 pp |
| pooled least squares | 0.0163 | 0.086 | 94.3% | 0.30 pp |
| local, τ = 0 | 0.0253 | 0.119 | 90.6% | 0.50 pp |
| persistence (A = I) | 0.0608 | 0.342 | 83.3% | 0.89 pp |
| frozen boosts (last day with data; demo reference) | 0.0826 | – | 81.5% | 0.96 pp |
| no boosts (demo reference) | 1.7539 | – | 0.1% | 27.74 pp |

*Boost RMSE* is the paper's tracking RMSE, per vector of the 3 boosts.
*Forecast RMSE* is per genre. *Ideal first screen* is the share of shopper-days
on which a shopper's top 8 holds the same 8 products as under the ideal boosts
x*(t), in any order; requiring the same order rank by rank, the shares are 73.9%
(cooperative), 65.1% (local), 47.5% (persistence) and 46.3% (frozen).
*Genre-mix error* is the mean absolute error of the genre shares of the feed
slots. `kpis.csv` also has the overlap with the ideal top 8 and the excess team
cost, which is second order in the boost error (59 parts per million for the
cooperative boosts, 112 for the local ones).

Pooled least squares, which the paper shows only for identification, tracks as
well as cooperative IV in case (B): in this trial it is slightly better, and
over the Monte Carlo trials its median boost RMSE equals the cooperative one
(0.0141 for both at N = 150 and 200), although its identification error is 2
to 4 times larger for N ≥ 100.

**Example first screens.** The typical shopper of a region (affinities closest
to the region's average) sees, on day 150 under the cooperative boosts:

* LA-0176 (Latin America): Air fryer 5 L, Cast-iron skillet, Glass storage jars,
  Pour-over coffee set, Enameled Dutch oven, Linen throw blanket, Chef's knife,
  Smart LED light strip;
* SA-0037 (South Asia): Yoga mat, Trail running shoes, Cycling helmet, Glass
  storage jars, Air fryer 5 L, Laundry detergent pods, Dish soap refill,
  Insulated water bottle.

These are also their ideal first screens: the boost errors are small, so most
shoppers see the ideal feed under any of the learning methods. Over days
150–299, 73% of all shoppers never see a non-ideal first screen under either
the cooperative or the local boosts. The difference shows on shoppers whose
8th and 9th products are close. EU-0408, the European shopper whose first
screen local learning got wrong, and cooperative learning right, on the most
days (the extreme case among Europe's 500 shoppers), sees on day 150 the ideal
first screen with the cooperative boosts (Air fryer, Glass storage jars,
Cast-iron skillet, Backpacking tent, Water bottle, Pour-over coffee set, Paper
towels, Chef's knife), while the local boosts replace the Chef's knife by Trail
running shoes. Its first screen differed from the ideal one on 20 days with
cooperative boosts and on 79 with local ones, but also on only 20 with frozen
boosts: which shoppers a boost error affects depends on its direction, not only
on its size. Over all shoppers, of the 877 whose counts differ, 839 (96%) do
better with the cooperative boosts (39,423 against 56,620 non-ideal
shopper-days), and the opposite exists too: NAM-0476 misses on 112 days with
cooperative boosts and on 38 with local ones (`output/dashboard/shoppers.csv`
has both example shoppers of every region).

## Monte Carlo: the paper's 50 trials per N

`run_montecarlo.py` reruns the 250 trials of the paper's N-sweep (generator
`rng([2026, 3, N, trial])`, τ = 3 and 1) and adds the product-level metrics.
Medians over the 50 trials:

| N | 30 | 50 | 100 | 150 | 200 |
|---|---:|---:|---:|---:|---:|
| ideal first screen, cooperative | 93.6% | 94.0% | 94.9% | 94.9% | 95.0% |
| ideal first screen, local | 89.7% | 90.6% | 93.2% | 92.6% | 91.9% |
| ideal first screen, persistence | 61.2% | 76.8% | 86.3% | 86.5% | 88.6% |
| ideal first screen, frozen boosts (demo reference) | 60.4% | 78.6% | 84.9% | 85.7% | 85.6% |
| forecast RMSE, cooperative | 0.102 | 0.095 | 0.091 | 0.092 | 0.091 |
| forecast RMSE, local | 0.203 | 0.154 | 0.122 | 0.138 | 0.134 |
| boost RMSE, cooperative | 0.0190 | 0.0173 | 0.0143 | 0.0141 | 0.0141 |
| boost RMSE, local | 0.0300 | 0.0259 | 0.0188 | 0.0216 | 0.0216 |
| boost RMSE, pooled least squares | 0.0203 | 0.0170 | 0.0149 | 0.0141 | 0.0141 |

The tracking RMSE of the 8 methods, the identification error of the 5
estimators and the instability statistics in the paper's data files
(`../paper_v4_package/code/data`) agree with this run to their 6 printed digits
(largest relative difference 3.2e-6; `output/montecarlo/mc_check.txt`). Frozen
boosts, no boosts, the tracking RMSE of pooled least squares and the
product-level metrics have no counterpart there. `mc_table.md` has every metric
with its interquartile range.

## One process per server

`run_distributed.py` runs the showcase trial as nine OS processes: eight
servers and the platform, which owns the truth and the shoppers. Each server
knows only its own constants (λ_i, ū_i, C_i, R, k, α, τ, its row of W) and
receives only its own region's sessions and gradient reports; servers exchange
messages only over the ten backbone links, through one pipe each. The run is
the in-process trial bit for bit (every difference is 0,
`output/distributed/comparison.txt`). The backbone carried 12,020 messages,
36,960 reals in all: per link and direction, 6 reals a day for gradient
tracking and 2p²τ = 54 for identification. Each server's own session logs hold
30,000 net scores, and none of them left its process.

## Checks

* `output/verification.txt`: the showcase trial against `experiments.run_trial`
  on the same generator. With the measurements computed from the session logs,
  every method agrees to 1.7e-16 except the centralized predictor (4.7e-11,
  the tolerance of the minimizer's Newton iterations); with `--no-sessions`
  the trial is bit-identical.
* `output/montecarlo/mc_check.txt`: PASS against the paper's N-sweep.
* `output/distributed/comparison.txt`: SAME TRIAL.
* `tests/` (130 tests): exactness against experiments.py, the statistics of the
  session logs, the instance, the feeds and the metrics, and end-to-end runs of
  every script, including make_figures.py and make_dashboard_data.py on a
  shorter horizon and run_demo.py with another seed.

## Output files

| file | content |
|---|---|
| `output/data/regions.csv`, `backbone.csv` | the regions, servers and links |
| `output/data/catalog.csv` | the 32 products: genre, price, base score |
| `output/data/shoppers.csv`, `shopper_scores.csv` | the 4,000 shoppers: affinities, exploration feed (illustrative), base scores |
| `output/data/sessions_explore.csv` | all 80,000 exploration sessions of days 0–99 |
| `output/data/daily_reports.csv` | per server and day t < N: û_i(t), ỹ_i(t), the boosts served, the gradient report |
| `output/data/interests.csv`, `optimum.csv` | true interests, each region's own optimum, the ideal boosts x*(t) |
| `output/data/window_estimates.csv`, `identification.csv` | Layers 1 and 2: reconstructions, estimates of A |
| `output/data/forecasts.csv`, `boosts.csv` | Layer 3: the forecasts θ̂_i(t) and every server's boosts every day, per method |
| `output/data/feed_daily.csv`, `example_feeds.csv` | feed agreement and genre shares per day; example first screens |
| `output/kpis.csv`, `kpis_by_region.csv`, `summary.txt` | the metrics and a readable summary |
| `output/distributed/` | the process-per-server run: comparison, messages per link, per-server counts |
| `output/montecarlo/` | per-trial metrics, medians and IQRs, the check against the paper |
| `output/figures/` | the figures, with `captions.txt` |
| `output/dashboard/` | page-ready tables for a results dashboard |
| (project page) `data/recommendation.js` | the "Recommendation systems" section of the project page, written by `make_website_data.py` from `output/` (run `make_dashboard_data.py` first) |

## What the product layer assumes

* Products never enter the servers' costs or data, and shoppers enter the data
  only as the ids that label the session logs: a session's scores depend
  neither on the shopper it is labelled with nor on the exploration feed in
  `shoppers.csv`, which is illustrative. The engagement model is the paper's
  genre-level one; products and shoppers only decide what the first screen
  shows under given boosts. Shopper scores are static, so a region's drift
  reaches its shoppers' feeds only through the common boosts.
* The boosts are common to all regions, as in the paper ("the ranking model is
  shared"); server i serves its region with its own iterate x_i(t), which stays
  within 0.0032 of the network average over days 150–299 (RMS 0.0009), so almost
  all of the tracking error is the common error of that average.
* A boost error of a few hundredths of a logit changes a shopper's first screen
  only if two products sit that close around the 8th place. The absolute shares
  of ideal first screens, and the few-point gap between methods (93.4% versus
  90.6%), depend on the illustrative score model: with every shopper's base
  scores halved they are 89.6% versus 85.0%, with them doubled 97.0% versus
  95.5%. The comparison that holds across these variants is relative:
  cooperation cuts the non-ideal shopper-days by 30–32% (6.6% versus 9.4% of
  shopper-days in the showcase), in line with its 27% lower tracking RMSE.
* Net interest can be negative early in the trial, when the drift θ_i(0)
  (standard deviation 1.5) is large: 0.44% of region-genre-days, all before day
  16. It means more negative than positive interactions.
* One step is one day.
