#!/usr/bin/env python3
"""
run_distributed.py -- the showcase trial of case study (B) as a distributed
system: one OS process per regional server (as the Webots demo of case study
(A) runs one process per station), this process as the platform (the shoppers
and their interests) and the recorder, messages only along the backbone.

    python3 run_distributed.py                         # N = 100, trial 0, tau = 3
    python3 run_distributed.py --N 30 --trial 2 --out /tmp/dist

It then runs the same trial in one process (simulate.run_trial_logged with
SessionLog, as run_demo.py does) and compares the two.  Writes to <out>/
(default output/distributed/):
  comparison.txt      distributed vs in-process: max |difference| of every quantity
  messages.csv        per backbone link and direction: messages and reals by type
  servers.csv         per server: traffic with its peers and with the platform
  steps.csv           backbone traffic per step of the recursion, by type
  boosts.csv          the boosts x_i(t) computed by the server processes
  identification.csv  A_hat_i, rho_raw_i and ||A_hat_i - A||_F of every server process
  summary.txt         the summary printed at the end
  run_config.json
Exit code 1 if the two runs differ by more than 1e-9, the sessions differ, the
message logs of the two ends of a channel disagree, or the traffic is not the
one the backbone's degrees, T, N and tau imply.  Only numpy is required.
"""
import argparse
import csv
import json
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from rcdemo import distributed as dist                                    # noqa: E402
from rcdemo.paper import CASE_ID, SEED, ref                               # noqa: E402
from rcdemo.simulate import SessionLog, paper_trial_rng, run_trial_logged  # noqa: E402
from rcdemo.world import BOOSTED, CHORDS, GENRE_KEYS, make_world          # noqa: E402

GK = GENRE_KEYS[:BOOSTED]


def write_csv(path, header, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f)
        wr.writerow(header)
        for row in rows:
            wr.writerow([("%.10g" % v) if isinstance(v, (float, np.floating)) else v for v in row])


def fmt_diff(v, m):
    if isinstance(v, (bool, np.bool_)):
        return "yes" if v else "NO"
    if isinstance(v, (int, np.integer)):
        return "%d of %d" % (v, m)
    return "0" if v == 0 else "%.3g" % v


def commas(v):
    return "{:,}".format(int(v))


def only(values, what):
    """The single value of a set of observations (raises if they differ)."""
    vals = set(values)
    if len(vals) != 1:
        raise AssertionError("%s is not uniform: %s" % (what, sorted(vals)))
    return vals.pop()


def accounting_checks(run, links, servers, mismatches):
    """Integrity of the message logs: {check: passed}."""
    return {
        "backbone logs agree at both ends of every link": all(r["received_as_sent"] for r in links),
        "platform counts agree at both ends of every channel": all(r["platform_counts_agree"] for r in servers),
        "only Algorithm 1 types on the backbone": set(dist.backbone_types_seen(run)) <= set(dist.BACKBONE_TYPES),
        "traffic as implied by the degrees, T, N and tau": not mismatches,
    }


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--N", type=int, default=100, help="days of data collection (default 100)")
    ap.add_argument("--trial", type=int, default=0, help="trial index of the paper's N-sweep (default 0)")
    ap.add_argument("--tau", type=int, default=3, help="consensus rounds (default 3)")
    ap.add_argument("--seed", type=int, default=SEED)
    ap.add_argument("--timeout", type=float, default=300.0, help="seconds without progress before giving up")
    ap.add_argument("--out", default=os.path.join(HERE, "output", "distributed"))
    args = ap.parse_args(argv)
    N, tr, tau = args.N, args.trial, args.tau
    os.makedirs(args.out, exist_ok=True)

    world = make_world(seed=args.seed)
    cs, m, n, p = world.cs, world.m, world.cs.n, world.cs.p
    codes = [r["code"] for r in world.regions]

    # ------------------------------------------------------------ the distributed run
    t0 = time.perf_counter()
    run = dist.run_distributed(world, N, tr, tau=tau, seed=args.seed, timeout=args.timeout)
    t_dist = time.perf_counter() - t0
    T, k = run.T, run.k
    print("distributed run: %d server processes, N=%d, trial %d, tau=%d, T=%d  %.2fs"
          % (m, N, tr, tau, T, t_dist), flush=True)

    # ------------------------------------------------------------ the same trial in one process
    taus = (3, 1) if tau in (3, 1) else (3, 1, tau)
    t0 = time.perf_counter()
    log = SessionLog(world, np.random.default_rng([args.seed, CASE_ID, dist.SESSION_STREAM, N, tr]))
    trial = run_trial_logged(cs, N, paper_trial_rng(N, tr, args.seed), taus=taus, measure=log)
    t_ref = time.perf_counter() - t0
    print("in-process run (run_trial_logged, all methods)  %.2fs" % t_ref, flush=True)

    # ------------------------------------------------------------ comparison and accounting
    key = "coop%d" % tau
    diffs = dist.compare(run, trial, log)
    bad = dist.failures(diffs, m)
    links = dist.link_traffic(run)
    servers = dist.server_traffic(run)
    mismatches = dist.traffic_mismatches(run)
    checks = accounting_checks(run, links, servers, mismatches)
    bad += [name for name, passed in checks.items() if not passed]
    ok = not bad

    streams = "trial stream rng([%d, %d, %d, %d]), session stream rng([%d, %d, %d, %d, %d])" % (
        args.seed, CASE_ID, N, tr, args.seed, CASE_ID, dist.SESSION_STREAM, N, tr)
    C = ["Distributed run vs in-process run of the same trial",
         "  distributed: %d server processes (multiprocessing, '%s'); this process as the platform;"
         % (m, dist.START_METHOD),
         "               messages only along the %d backbone links" % len(world.edges),
         "  in-process:  simulate.run_trial_logged(cs, N, paper_trial_rng(N, trial), taus=%s, measure=SessionLog)"
         % (taus,),
         "  N = %d, trial %d, tau = %d, T = %d; %s" % (N, tr, tau, T, streams),
         "",
         "max |difference| (in-process method '%s'; sessions: identical or not):" % key]
    for name, v in diffs.items():
        C.append("  %-40s %s" % (name, fmt_diff(v, m)))
    C.append("message accounting:")
    for name, passed in checks.items():
        C.append("  %-52s %s" % (name, "yes" if passed else "NO"))
    C += ["    " + s for s in mismatches[:20]]
    C.append("result: %s (tolerance %.0e)" % ("SAME TRIAL" if ok else "MISMATCH: " + "; ".join(bad), dist.TOL))
    with open(os.path.join(args.out, "comparison.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(C) + "\n")

    # ------------------------------------------------------------ data files
    chords0 = {(a - 1, b - 1) for a, b in CHORDS}
    kinds = list(dist.BACKBONE_TYPES)
    write_csv(os.path.join(args.out, "messages.csv"),
              ["link", "kind", "from_server", "to_server", "from", "to", "weight"]
              + [h for kd in kinds for h in (kd + "_messages", kd + "_reals")] + ["messages", "reals", "received_as_sent"],
              [[r["link"], "chord" if tuple(sorted((r["src"], r["dst"]))) in chords0 else "ring",
                r["src"] + 1, r["dst"] + 1, codes[r["src"]], codes[r["dst"]], cs.W[r["src"], r["dst"]]]
               + [r[kd + suffix] for kd in kinds for suffix in ("_msgs", "_reals")]
               + [r["msgs"], r["reals"], "yes" if r["received_as_sent"] else "NO"] for r in links])
    write_csv(os.path.join(args.out, "servers.csv"),
              ["server", "code", "region", "data_center", "degree", "neighbors", "messages_sent", "reals_sent",
               "messages_received", "reals_received", "deploy_messages", "deploy_reals", "session_messages",
               "session_rows", "session_scores", "report_messages", "report_reals", "platform_counts_agree",
               "cpu_s", "data_s", "identification_s", "tracking_s"],
              [[r["i"] + 1, codes[r["i"]], world.regions[r["i"]]["name"], world.regions[r["i"]]["hub"], r["degree"],
                " ".join(codes[j] for j in r["neighbors"]), r["msgs_sent"], r["reals_sent"], r["msgs_received"],
                r["reals_received"], r["deploy_msgs"], r["deploy_reals"], r["session_msgs"], r["session_rows"],
                r["session_scores"], r["report_msgs"], r["report_reals"], "yes" if r["platform_counts_agree"] else "NO",
                r["cpu"], r["time_data"], r["time_identification"], r["time_tracking"]] for r in servers])
    st = dist.step_traffic(run)
    write_csv(os.path.join(args.out, "steps.csv"),
              ["step", "phase"] + [h for kd in kinds for h in (kd + "_messages", kd + "_reals")] + ["messages", "reals"],
              [[t, dist.phase_of(t, N)] + [v for kd in kinds for v in st.get((t, kd), [0, 0])]
               + [sum(st.get((t, kd), [0, 0])[0] for kd in kinds), sum(st.get((t, kd), [0, 0])[1] for kd in kinds)]
               for t in range(T - 1)])
    X = run.X
    write_csv(os.path.join(args.out, "boosts.csv"), ["day", "region"] + ["x_%s" % g for g in GK],
              [[t, codes[i]] + list(X[t, i]) for t in range(T) for i in range(m)])
    A_hat = run.stack("A_hat")
    rho = np.array([r["rho_raw"] for r in run.records])
    err = np.linalg.norm(A_hat - cs.A, axis=(1, 2))
    write_csv(os.path.join(args.out, "identification.csv"),
              ["region"] + ["a%d%d" % (a + 1, b + 1) for a in range(p) for b in range(p)]
              + ["rho_raw", "error_F", "stable_raw"],
              [[codes[i]] + list(A_hat[i].ravel()) + [rho[i], err[i], "no" if rho[i] >= 1 else "yes"]
               for i in range(m)])

    # ------------------------------------------------------------ communication facts (observed)
    pls = dist.per_link_step(run)
    gt_dir_step = only(pls.values(), "gradient-tracking reals per link, direction and step")
    gt_track = only([v for (i, j, t), v in pls.items() if t >= N], "tracking reals per link and step")
    id_msgs = only([r["moments_msgs"] for r in links], "identification messages per link and direction")
    id_reals = only([r["moments_reals"] for r in links], "identification reals per link and direction")
    per_dir_msgs = only([r["msgs"] for r in links], "messages per link and direction")
    per_dir_reals = only([r["reals"] for r in links], "reals per link and direction")
    tot_msgs, tot_reals = sum(r["msgs"] for r in links), sum(r["reals"] for r in links)
    by_degree = {}
    for r in servers:
        by_degree.setdefault(r["degree"], set()).add((r["msgs_sent"], r["reals_sent"], r["msgs_received"],
                                                      r["reals_received"]))
    pf = only([(r["deploy_msgs"], r["deploy_reals"], r["session_msgs"], r["session_rows"], r["session_scores"],
                r["report_msgs"], r["report_reals"]) for r in servers], "platform traffic per server")
    nsteps = T - 1
    ring = sum(1 for e in world.edges if e not in chords0)

    # ------------------------------------------------------------ summary
    L = ["Case study (B), distributed: one OS process per regional server",
         "=" * 78,
         "N = %d days of data collection, trial %d, tau = %d, days 0..%d.  %d server processes"
         % (N, tr, tau, T - 1, m),
         "(multiprocessing, '%s'); this process is the platform and the recorder." % dist.START_METHOD,
         "Run time: distributed %.2f s (process start-up through day 0 %.2f s, days 1..%d %.2f s,"
         % (t_dist, run.timing["startup"], N - 1, run.timing["data"]),
         "identification, tracking and the records %.2f s); the same trial in one process"
         % run.timing["tracking"],
         "(run_trial_logged, all %d methods) %.2f s." % (len(trial.boosts), t_ref),
         "",
         "Who knows what",
         "  server i   lambda_i, ubar_i, f_i^0 and C_i, R, k = %d, alpha = %g, tau = %d, rho_max = %g, its row"
         % (k, cs.alpha, tau, dist.RHO_MAX),
         "             of W (itself and its %s neighbors), N and T; then its own region's data" %
         " or ".join(str(d) for d in sorted(by_degree)),
         "  platform   theta_i(t) of every region and day (the truth), the shoppers, all noise",
         "",
         "Channels and message types",
         "  backbone: %d links (%d ring + %d chords %s), one duplex pipe each" % (
             len(world.edges), ring, len(world.edges) - ring,
             ", ".join("%s-%s" % (codes[a - 1], codes[b - 1]) for a, b in CHORDS))]
    sizes = dist.backbone_sizes(n, p)
    for kd, what in dist.BACKBONE_TYPES.items():
        L.append("    %-9s %2d reals  %s" % (kd, sizes[kd], what))
    L.append("  platform <-> server i (days t < %d only, region i's data only)" % N)
    for kd, what in dist.PLATFORM_TYPES.items():
        L.append("    %-9s %s" % (kd, what))
    L.append("  recorder: every server's record, once at the end (not part of the algorithm)")
    L.append("")
    L.append("Communication (counted at both ends of every channel; the two logs agree: %s)"
             % ("yes" if all(checks.values()) else "NO"))
    L.append("  types seen on the backbone: %s; no session, measurement, interest or forecast"
             % ", ".join(dist.backbone_types_seen(run)))
    L.append("  crossed a backbone link")
    L.append("  gradient tracking, every step t = 0..%d: per link and direction 2 messages, %d reals"
             % (T - 2, gt_dir_step))
    L.append("    (during tracking, t >= %d: %d reals per link and direction, %d per link, %d per step on the"
             % (N, gt_track, 2 * gt_track, 2 * len(world.edges) * gt_track))
    L.append("    backbone)")
    L.append("  identification (step %d): per link and direction %d message%s, %d reals = 2 p^2 tau = %d"
             % (N - 1, id_msgs, "" if id_msgs == 1 else "s", id_reals, 2 * p * p * tau))
    L.append("  per link and direction in total: %s messages, %s reals" % (commas(per_dir_msgs), commas(per_dir_reals)))
    L.append("  backbone in total: %s messages, %s reals in %d steps" % (commas(tot_msgs), commas(tot_reals), nsteps))
    for d in sorted(by_degree):
        ms, rs, mr, rr = only(by_degree[d], "traffic of the servers of degree %d" % d)
        L.append("  a server with %d neighbors sent %s messages (%s reals) and received %s (%s reals)"
                 % (d, commas(ms), commas(rs), commas(mr), commas(rr)))
    L.append("  platform <-> each server: %d deployments in (%s reals), %d session logs out (%s rows: shopper"
             % (pf[0], commas(pf[1]), pf[2], commas(pf[3])))
    L.append("    id + %d net scores = %s scores) and %d gradient reports out (%s reals)"
             % (n, commas(pf[4]), pf[5], commas(pf[6])))
    L.append("  for scale: one server's session logs hold %s net scores and stay on it; the whole backbone"
             % commas(pf[4]))
    L.append("    carried %s reals" % commas(tot_reals))
    L.append("")
    L.append("Agreement with the in-process trial (same generators), max |difference|:")
    for name, v in diffs.items():
        L.append("  %-40s %s" % (name, fmt_diff(v, m)))
    L.append("  result: %s (tolerance %.0e)" % ("SAME TRIAL" if ok else "MISMATCH: " + "; ".join(bad), dist.TOL))
    L.append("")
    L.append("What the server processes computed (cooperative, tau = %d)" % tau)
    L.append("  ||A_hat_i - A||_F: %s  (mean %.4f)" % (" ".join("%.3f" % v for v in err), err.mean()))
    L.append("  raw estimate not Schur stable at %d of %d servers" % (int(np.sum(rho >= 1)), m))
    L.append("  boost RMSE over days %d..%d (against x*(t)): %.5f" % (
        trial.window[0], trial.window[-1], dist.boost_rmse(X, trial.xstar, N)))
    t_show = min(N + 50, T - 1)
    L.append("  boosts on day %d (%s): ideal x* %s" % (t_show, ", ".join(GK), " ".join("%.3f" % v for v in trial.xstar[t_show])))
    for i in range(m):
        L.append("    %-3s %s" % (codes[i], " ".join("%.3f" % v for v in X[t_show, i])))
    with open(os.path.join(args.out, "summary.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")

    cfg = dict(N=N, trial=tr, tau=tau, seed=args.seed, case_id=CASE_ID, T=T, k=k, sessions_per_day=run.S,
               trial_stream=[args.seed, CASE_ID, N, tr],
               session_stream=[args.seed, CASE_ID, dist.SESSION_STREAM, N, tr],
               processes=m, start_method=dist.START_METHOD, edges=[[a + 1, b + 1] for a, b in world.edges],
               reference=dict(function="simulate.run_trial_logged", taus=list(taus), method=key),
               timing=dict(distributed_s=t_dist, in_process_s=t_ref, **{k_ + "_s": v for k_, v in run.timing.items()}),
               comparison={name: (v if isinstance(v, (bool, int)) else float(v)) for name, v in diffs.items()},
               accounting=checks, tolerance=dist.TOL, same_trial=ok,
               backbone=dict(messages=tot_msgs, reals=tot_reals, per_link_direction_messages=per_dir_msgs,
                             per_link_direction_reals=per_dir_reals, identification_reals_per_link_direction=id_reals),
               experiments_projection=bool(ref.PROJECTION))
    with open(os.path.join(args.out, "run_config.json"), "w") as f:
        json.dump(cfg, f, indent=1)

    print("\n".join(L))
    print("\nwritten to %s" % args.out)
    if not ok:
        print("\n*** MISMATCH between the distributed and the in-process run: %s ***" % "; ".join(bad),
              file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
