#!/usr/bin/env python3
"""
run_demo.py -- the full simulation of one trial of case study (B), with data.

    python3 run_demo.py                     # the trial of the paper's Figure 3(b): N = 100, trial 0
    python3 run_demo.py --N 50 --trial 4 --out output_N50

Writes to <out>/ (default output/):
  data/regions.csv            the eight regions: server, data center, lambda_i, ubar_i, neighbors
  data/backbone.csv           the backbone links and their Metropolis weights
  data/catalog.csv            the 32 products (3 boosted genres + essentials)
  data/shoppers.csv           the 4,000 shoppers: genre affinities, favorite genre, exploration feed
  data/shopper_scores.csv     base-model score of every shopper for every product
  data/sessions_explore.csv   every exploration session of the data-collection phase (80,000 rows)
  data/daily_reports.csv      what each server computed and received on each day t < N
  data/interests.csv          true interests u_i(t) = ubar_i + theta_i(t) and each region's own optimum
  data/optimum.csv            the ideal boosts x*(t) and the network-wide interests
  data/window_estimates.csv   the servers' reconstructions theta_tilde_i(t) (Layer 1)
  data/identification.csv     every server's estimate of A, per method (Layer 2)
  data/forecasts.csv          forecasts of the interests, t >= N, per method
  data/boosts.csv             boosts x_i(t) of every server, every day, per method (Layer 3)
  data/feed_daily.csv         feed agreement and genre shares per day, region, method
  data/example_feeds.csv      the feed of one shopper per region on selected days, per method
  kpis.csv, kpis_by_region.csv, summary.txt, verification.txt, run_config.json

Only numpy is required.  The trial is the paper's: experiments.run_trial with
the same generator gives the same trial (verification.txt).
"""
import argparse
import csv
import json
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from rcdemo.feeds import FeedEvaluator, feed_of                                  # noqa: E402
from rcdemo.kpi import KPI_KEYS, LABEL, METHODS, region_kpis, solo_optimum, trial_kpis  # noqa: E402
from rcdemo.paper import CASE_ID, SEED, ref                                     # noqa: E402
from rcdemo.simulate import (RMSE_FROM, SESSIONS_PER_DAY, SessionLog,           # noqa: E402
                             paper_trial_rng, run_trial_logged)
from rcdemo.world import (BOOSTED, CHORDS, FEED_SIZE, GENRE_DYNAMICS, GENRE_KEYS,  # noqa: E402
                          GENRES, make_world)

EXAMPLE_DAYS = [0, 25, 50, 99, 100, 150, 200, 299]
EXAMPLE_METHODS = ["ideal", "coop3", "local", "persistence", "frozen", "noboost"]
SESSION_STREAM = 9002          # rng([seed, 3, 9002, N, trial]) draws the sessions (own stream)
GK = GENRE_KEYS[:BOOSTED]


def fmt(v, nd=6):
    if isinstance(v, (float, np.floating)):
        if np.isnan(v):
            return ""
        return ("%%.%dg" % nd) % v
    return str(v)


def write_csv(path, header, rows, nd=6):
    with open(path, "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f)
        wr.writerow(header)
        for row in rows:
            wr.writerow([fmt(v, nd) for v in row])


def typical_shopper(world, i):
    """The shopper of region i whose affinity is closest to the region's average."""
    idx = world.by_region[i]
    a = world.users["affinity"][idx]
    return int(idx[np.argmin(np.sum((a - a.mean(axis=0)) ** 2, axis=1))])


def verify(world, trial, N, tr):
    """Compare with experiments.run_trial on the same instance and generator
    (rng([seed, 3, N, trial]) with the world's seed)."""
    res = ref.run_trial(world.cs, N, paper_trial_rng(N, tr, world.seed), taus=trial.taus, extra=True,
                        want_series=True)
    S = res["series"]
    others = [k for k in res["rmse"] if k != "centralized"]
    d = dict(
        rmse=max(abs(res["rmse"][k] - trial.rmse[k]) for k in others),
        # the centralized predictor stops its Newton iterations at ||grad|| < 1e-10, so the
        # 1e-15 differences of the measurements computed from the session logs move it by ~1e-11
        rmse_centralized=abs(res["rmse"]["centralized"] - trial.rmse["centralized"]),
        id=max(float(np.max(np.abs(res["id"][k] - trial.id[k]))) for k in res["id"]),
        theta=float(np.max(np.abs(S["Theta"] - trial.Theta))),
        xstar=float(np.max(np.abs(S["xstar"] - trial.xstar))),
        window=float(np.max(np.abs(S["th"] - trial.th))),
        iterates_data=float(np.max(np.abs(np.array(S["traj_data"]) - trial.X_data))),
        iterates_coop=float(np.max(np.abs(np.array(S["traj_coop"]) - trial.boosts["coop%d" % trial.taus[0]][N:]))),
        iterates_local=float(np.max(np.abs(np.array(S["traj_local"]) - trial.boosts["local"][N:]))),
        measurements=float(np.max(np.abs(trial.Y_used - trial.Y))),
    )
    return d, res


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--N", type=int, default=100, help="days of data collection (paper: 30..200)")
    ap.add_argument("--trial", type=int, default=0, help="trial index of the paper's N-sweep (default 0)")
    ap.add_argument("--seed", type=int, default=SEED,
                    help="seed of the instance and of the trial generator rng([seed, 3, N, trial]) (paper: 2026)")
    ap.add_argument("--out", default=os.path.join(HERE, "output"))
    ap.add_argument("--no-sessions", action="store_true",
                    help="use the paper's measurement model directly instead of computing it from session logs")
    args = ap.parse_args()
    t_start = time.time()
    out, ddir = args.out, os.path.join(args.out, "data")
    os.makedirs(ddir, exist_ok=True)
    N, tr = args.N, args.trial

    world = make_world(seed=args.seed)
    cs, m, n = world.cs, world.m, world.cs.n
    reg = world.regions
    codes = [r["code"] for r in reg]

    # ------------------------------------------------------------------ world
    write_csv(os.path.join(ddir, "regions.csv"),
              ["server", "code", "region", "data_center", "lat", "lon", "lambda", "W_self"]
              + ["ubar_%s" % g for g in GK] + ["neighbors", "shoppers"],
              [[r["index"] + 1, r["code"], r["name"], r["hub"], r["lat"], r["lon"], r["lam"], cs.W[i, i]]
               + list(r["ubar"]) + [" ".join(codes[j] for j in r["neighbors"]), len(world.by_region[i])]
               for i, r in enumerate(reg)])
    chords0 = {(a - 1, b - 1) for a, b in CHORDS}
    write_csv(os.path.join(ddir, "backbone.csv"), ["link", "from", "to", "kind", "weight"],
              [[k + 1, codes[i], codes[j], "chord" if (i, j) in chords0 else "ring", cs.W[i, j]]
               for k, (i, j) in enumerate(world.edges)])
    P = world.products
    write_csv(os.path.join(ddir, "catalog.csv"), ["product", "name", "genre", "boosted", "price_usd", "base_score"],
              [[P["pid"][j], P["name"][j], GENRES[P["genre"][j]], "yes" if P["genre"][j] < BOOSTED else "no",
                P["price"][j], P["base"][j]] for j in range(len(P["pid"]))])
    Uu = world.users
    fav = np.argmax(Uu["affinity"], axis=1)
    write_csv(os.path.join(ddir, "shoppers.csv"),
              ["shopper", "region"] + ["affinity_%s" % g for g in GK] + ["favorite_genre", "exploration_feed"],
              [[Uu["uid"][s], codes[Uu["region"][s]]] + list(Uu["affinity"][s]) + [GENRES[fav[s]],
               " ".join(P["pid"][world.explore_feed[s]])] for s in range(len(Uu["uid"]))], nd=4)
    write_csv(os.path.join(ddir, "shopper_scores.csv"), ["shopper"] + list(P["pid"]),
              [[Uu["uid"][s]] + list(Uu["base_scores"][s]) for s in range(len(Uu["uid"]))], nd=4)

    # ------------------------------------------------------------------ the trial
    log = None if args.no_sessions else SessionLog(
        world, np.random.default_rng([args.seed, CASE_ID, SESSION_STREAM, N, tr]))
    rng = np.random.default_rng([args.seed, CASE_ID, N, tr])
    trial = run_trial_logged(cs, N, rng, taus=(3, 1), measure=log)
    T, k = trial.T, trial.k
    print("trial simulated (N=%d, trial %d, T=%d)  %.1fs" % (N, tr, T, time.time() - t_start), flush=True)

    # ------------------------------------------------------------------ data
    if log is not None:
        rows = []
        for t in range(N):
            for i in range(m):
                for s in range(log.S):
                    rows.append([t, codes[i], "%s-%03d-%03d" % (codes[i], t, s + 1), Uu["uid"][log.users[t, i, s]]]
                                + list(log.scores[t, i, s]))
        write_csv(os.path.join(ddir, "sessions_explore.csv"),
                  ["day", "region", "session", "shopper"] + ["net_%s" % g for g in GK], rows, nd=4)
        u_hat = log.u_hat
    else:
        u_hat = np.full((N, m, n), np.nan)
    write_csv(os.path.join(ddir, "daily_reports.csv"),
              ["day", "region", "sessions"] + ["uhat_%s" % g for g in GK] + ["ytilde_%s" % g for g in GK]
              + ["boost_%s" % g for g in GK] + ["grad_%s" % g for g in GK],
              [[t, codes[i], log.S if log else 0] + list(u_hat[t, i]) + list(trial.Y_used[i, t])
               + list(trial.X_data[t, i]) + list(trial.G_data[t, i]) for t in range(N) for i in range(m)])
    solo = solo_optimum(cs, trial.u)
    write_csv(os.path.join(ddir, "interests.csv"),
              ["day", "region"] + ["theta_%s" % g for g in GK] + ["u_%s" % g for g in GK]
              + ["solo_boost_%s" % g for g in GK],
              [[t, codes[i]] + list(trial.Theta[t, i]) + list(trial.u[t, i]) + list(solo[t, i])
               for t in range(T) for i in range(m)])
    write_csv(os.path.join(ddir, "optimum.csv"),
              ["day"] + ["xstar_%s" % g for g in GK] + ["U_%s" % g for g in GK],
              [[t] + list(trial.xstar[t]) + list(trial.u[t].sum(axis=0)) for t in range(T)])
    write_csv(os.path.join(ddir, "window_estimates.csv"), ["day", "region"] + ["theta_tilde_%s" % g for g in GK],
              [[t, codes[i]] + list(trial.th[i, t]) for t in range(trial.th.shape[1]) for i in range(m)])
    id_rows = []
    for key in ["local", "coop1", "coop3", "exact", "pooledLS"]:
        Ah, rho = trial.estimates[key]
        for i in range(m):
            id_rows.append([key, codes[i]] + list(Ah[i].ravel()) + [trial.id[key][i], rho[i], "no" if rho[i] >= 1 else "yes"])
    for i in range(m):
        id_rows.append(["true", codes[i]] + list(cs.A.ravel()) + [0.0, ref.spectral_radius(cs.A), "yes"])
    write_csv(os.path.join(ddir, "identification.csv"),
              ["method", "region"] + ["a%d%d" % (a + 1, b + 1) for a in range(3) for b in range(3)]
              + ["error_F", "rho_raw", "stable_raw"], id_rows)
    fc_rows = []
    for key in [mm for mm in METHODS if mm in trial.forecasts]:
        for t in range(N, T):
            for i in range(m):
                th_hat = trial.forecasts[key][t - N, i]
                fc_rows.append([t, key, codes[i]] + list(th_hat) + list(cs.ubar[i] + th_hat))
    write_csv(os.path.join(ddir, "forecasts.csv"),
              ["day", "method", "region"] + ["theta_hat_%s" % g for g in GK] + ["u_hat_%s" % g for g in GK], fc_rows)
    b_rows = []
    for key in [mm for mm in METHODS if mm in trial.boosts]:
        for t in range(T):
            for i in range(m):
                b_rows.append([t, key, codes[i]] + list(trial.boosts[key][t, i]))
    write_csv(os.path.join(ddir, "boosts.csv"), ["day", "method", "region"] + ["x_%s" % g for g in GK], b_rows)

    # ------------------------------------------------------------------ feeds and metrics
    feval = FeedEvaluator(world, trial.xstar, np.arange(T))
    kpis, daily = trial_kpis(world, trial, feval)
    print("metrics computed  %.1fs" % (time.time() - t_start), flush=True)
    fd_rows = []
    for key in kpis:
        d = daily[key]
        for t in range(T):
            for i in range(m):
                fd_rows.append([t, key, codes[i], d["agree"][t, i], d["overlap"][t, i]] + list(d["share"][t, i])
                               + list(feval.share_ideal[t, i]))
    write_csv(os.path.join(ddir, "feed_daily.csv"),
              ["day", "method", "region", "agree", "overlap"] + ["share_%s" % g for g in GENRE_KEYS]
              + ["ideal_share_%s" % g for g in GENRE_KEYS], fd_rows, nd=5)
    ex_rows = []
    examples = {}
    for i in range(m):
        s = typical_shopper(world, i)
        examples[codes[i]] = Uu["uid"][s]
        for t in EXAMPLE_DAYS:
            if t >= T:
                continue
            for key in EXAMPLE_METHODS:
                x = trial.xstar[t] if key == "ideal" else trial.boosts[key][t, i]
                feed = feed_of(world, s, x)
                sc = Uu["base_scores"][s] + np.concatenate([x, [0.0]])[P["genre"]]
                for rnk, j in enumerate(feed):
                    ex_rows.append([codes[i], Uu["uid"][s], t, key, rnk + 1, P["pid"][j], P["name"][j],
                                    GENRES[P["genre"][j]], sc[j]] + list(x))
    write_csv(os.path.join(ddir, "example_feeds.csv"),
              ["region", "shopper", "day", "method", "rank", "product", "name", "genre", "score"]
              + ["x_%s" % g for g in GK], ex_rows, nd=4)
    write_csv(os.path.join(out, "kpis.csv"), ["method", "label"] + KPI_KEYS,
              [[mm, LABEL[mm]] + [kpis[mm][kk] for kk in KPI_KEYS] for mm in kpis])
    rk = region_kpis(world, trial, daily)
    write_csv(os.path.join(out, "kpis_by_region.csv"), list(rk[0].keys()), [list(r.values()) for r in rk])

    # ------------------------------------------------------------------ verification
    vd, _ = verify(world, trial, N, tr)
    tol = 1e-8
    ok = all(v <= tol for kk, v in vd.items() if kk != "measurements")
    with open(os.path.join(out, "verification.txt"), "w") as f:
        f.write("Comparison with experiments.run_trial(cs, N=%d, rng([%d, %d, %d, %d]), taus=(3, 1), extra=True)\n"
                % (N, args.seed, CASE_ID, N, tr))
        f.write("(max absolute differences; the servers' measurements %s)\n" %
                ("are computed from the session logs" if log else "are the paper's"))
        for kk, v in vd.items():
            f.write("  %-16s %.3g\n" % (kk, v))
        f.write("result: %s (tolerance %.0e)\n" % ("SAME TRIAL" if ok else "MISMATCH", tol))
    print("verification: %s" % ("same trial as experiments.run_trial" if ok else "MISMATCH"), flush=True)

    # ------------------------------------------------------------------ summary
    win = trial.window
    L = []
    L.append("Case study (B) as a product recommendation platform -- full simulation of one trial")
    L.append("=" * 84)
    L.append("seed %d, N = %d days of data collection, trial %d, tracking until day %d, window for the"
             % (args.seed, N, tr, T - 1))
    L.append("metrics: days %d..%d (the paper's [N+50, N+200)).  Measurements: %s." % (
        win[0], win[-1], "computed from %d exploration sessions per region and day" % SESSIONS_PER_DAY if log
        else "the paper's model"))
    L.append("")
    L.append("Regions (server, data center, boost-penalty weight lambda_i, known average interests ubar_i):")
    for i, r in enumerate(reg):
        L.append("  %d %-3s %-22s %-13s lambda=%.3f  ubar = %s   neighbors: %s" % (
            i + 1, r["code"], r["name"], r["hub"], r["lam"], " ".join("%.2f" % v for v in r["ubar"]),
            ", ".join(codes[j] for j in r["neighbors"])))
    L.append("  backbone: ring + chords %s, contraction factor sigma = %.3f" % (
        ", ".join("%s-%s" % (codes[a - 1], codes[b - 1]) for a, b in CHORDS), ref.contraction(cs.W)))
    L.append("")
    L.append("Genres and the shared dynamics A = blkdiag(0.98 Rot(0.25), 0.95):")
    for g in range(len(GENRES)):
        L.append("  %-20s %s" % (GENRES[g], GENRE_DYNAMICS[g]))
    L.append("")
    u0, uN = trial.u[0], trial.u[N - 1]
    L.append("Interests: day 0 range %.2f..%.2f, day %d range %.2f..%.2f, day %d range %.2f..%.2f;"
             % (u0.min(), u0.max(), N - 1, uN.min(), uN.max(), T - 1, trial.u[T - 1].min(), trial.u[T - 1].max()))
    L.append("  fraction of (day, region, genre) with negative net interest: %.2f%% (all before day %d)" % (
        100 * np.mean(trial.u < 0), int(np.max(np.nonzero((trial.u < 0).any(axis=(1, 2)))[0]) + 1)
        if (trial.u < 0).any() else 0))
    L.append("Ideal boosts x*(t): day 0 %s, day %d %s, range over the window %s..%s" % (
        np.round(trial.xstar[0], 3), N, np.round(trial.xstar[N], 3),
        np.round(trial.xstar[win].min(axis=0), 3), np.round(trial.xstar[win].max(axis=0), 3)))
    L.append("Each region alone would boost (day %d): " % N + "; ".join(
        "%s %s" % (codes[i], " ".join("%.2f" % v for v in solo[N, i])) for i in range(m)))
    L.append("")
    L.append("Identification at day %d (Layer 2), ||A_hat_i - A||_F per server:" % N)
    for key in ["local", "coop1", "coop3", "exact", "pooledLS"]:
        L.append("  %-22s %s   mean %.4f, raw estimate not Schur stable at %d of %d servers" % (
            LABEL[key], " ".join("%.3f" % v for v in trial.id[key]), np.mean(trial.id[key]),
            int(round(trial.unstable[key] * m)), m))
    L.append("  gain of cooperation (mean local / mean cooperative): %.1fx (sqrt(m) = %.2f)" % (
        np.mean(trial.id["local"]) / np.mean(trial.id["coop3"]), np.sqrt(m)))
    L.append("")
    L.append("Metrics over the window (see rcdemo/kpi.py):")
    L.append("  %-24s %9s %9s %8s %8s %9s %10s" % ("method", "boostRMSE", "forecast", "agree%", "overlap%",
                                                    "expo(pp)", "excess ppm"))
    for mm in kpis:
        r = kpis[mm]
        L.append("  %-24s %9.4f %9s %8.1f %8.1f %9.2f %10.1f" % (
            LABEL[mm], r["rmse"], "" if np.isnan(r["forecast"]) else "%.4f" % r["forecast"], r["agree"],
            r["overlap"], r["exposure"], r["excess"]))
    L.append("")
    L.append("Feed of a typical shopper per region (ideal boosts vs cooperative vs local), day %d:" % (N + 50))
    for i in range(m):
        s = typical_shopper(world, i)
        L.append("  %s %s (affinity %s):" % (codes[i], Uu["uid"][s], " ".join("%+.2f" % v for v in Uu["affinity"][s])))
        for key in ["ideal", "coop3", "local"]:
            x = trial.xstar[N + 50] if key == "ideal" else trial.boosts[key][N + 50, i]
            L.append("     %-20s %s" % (LABEL[key][:20], " | ".join(P["name"][j] for j in feed_of(world, s, x))))
    L.append("")
    L.append("Verification against experiments.run_trial: " + ", ".join("%s %.1e" % kv for kv in vd.items()))
    L.append("Elapsed %.0fs" % (time.time() - t_start))
    with open(os.path.join(out, "summary.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    cfg = dict(seed=args.seed, case_id=CASE_ID, N=N, trial=tr, T=T, k=k, taus=list(trial.taus),
               rmse_window=[int(win[0]), int(win[-1])], sessions_per_day=SESSIONS_PER_DAY if log else 0,
               session_sigma=list(map(float, log.sigma)) if log else None,
               session_stream=[args.seed, CASE_ID, SESSION_STREAM, N, tr] if log else None,
               trial_stream=[args.seed, CASE_ID, N, tr], feed_size=FEED_SIZE,
               example_shoppers=examples, example_days=EXAMPLE_DAYS, params=world.params,
               verification=vd, same_trial=ok)
    with open(os.path.join(out, "run_config.json"), "w") as f:
        json.dump(cfg, f, indent=1)
    print("\n".join(L))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
