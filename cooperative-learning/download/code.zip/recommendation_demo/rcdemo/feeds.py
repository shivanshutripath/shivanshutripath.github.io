"""
Feeds: the top-8 products of every shopper under given boosts, and what a
boost trajectory does to them compared with the ideal boosts x*(t).

Shopper s of region i is served by server i, so under a method the feed of s
on day t is ranked with server i's boosts x_i(t); the ideal feed is ranked with
the minimizer x*(t) of the team cost (the boosts the servers would agree on if
they knew every region's current interests).
"""
import numpy as np

from .world import FEED_SIZE, GENRES, boost_vector


def topk_mask(scores, K=FEED_SIZE):
    """Boolean mask of the K largest scores along the last axis."""
    idx = np.argpartition(-scores, K - 1, axis=-1)[..., :K]
    mask = np.zeros(scores.shape, dtype=bool)
    np.put_along_axis(mask, idx, True, axis=-1)
    return mask


def ordered_feed(scores, K=FEED_SIZE):
    """Indices of the K largest scores, best first, along the last axis."""
    idx = np.argpartition(-scores, K - 1, axis=-1)[..., :K]
    s = np.take_along_axis(scores, idx, axis=-1)
    return np.take_along_axis(idx, np.argsort(-s, axis=-1, kind="stable"), axis=-1)


def region_scores(world, i, X):
    """Scores of region i's shoppers under boosts X (D, n): shape (D, U_i, P)."""
    B = world.users["base_scores"][world.by_region[i]]
    return B[None, :, :] + boost_vector(world, X)[:, None, :]


def feed_of(world, user, x, K=FEED_SIZE):
    """Ordered feed (product indices) of one shopper under boosts x (n,)."""
    return ordered_feed(world.users["base_scores"][user] + boost_vector(world, x), K)


class FeedEvaluator:
    """Compares the feeds under a boost trajectory with the ideal feeds, on the
    days ``days``, for every shopper.  The ideal feeds are computed once."""

    def __init__(self, world, xstar, days):
        self.world = world
        self.days = np.asarray(days)
        g = world.products["genre"]
        self.onehot = (g[:, None] == np.arange(len(GENRES))[None, :]).astype(float)   # (P, 4)
        self.ideal = [topk_mask(region_scores(world, i, xstar[self.days])) for i in range(world.m)]
        self.share_ideal = np.stack([self._share(mk) for mk in self.ideal], axis=1)    # (D, m, 4)

    def _share(self, mask):
        """Share of the feed slots per genre, averaged over the shoppers: (D, 4)."""
        return (mask.astype(float) @ self.onehot).mean(axis=1) / FEED_SIZE

    def evaluate(self, boosts):
        """boosts (T, m, n).  Returns per-day, per-region arrays:
        agree (D, m)  fraction of shoppers whose top-8 set equals the ideal one,
        overlap (D, m) mean |top-8 and ideal top-8| / 8,
        share (D, m, 4) genre shares of the feed slots (ideal: self.share_ideal)."""
        D, m = len(self.days), self.world.m
        agree, overlap, share = np.zeros((D, m)), np.zeros((D, m)), np.zeros((D, m, len(GENRES)))
        for i in range(m):
            mk = topk_mask(region_scores(self.world, i, boosts[self.days, i]))
            same = mk == self.ideal[i]
            agree[:, i] = same.all(axis=2).mean(axis=1)
            overlap[:, i] = (mk & self.ideal[i]).sum(axis=2).mean(axis=1) / FEED_SIZE
            share[:, i] = self._share(mk)
        return dict(agree=agree, overlap=overlap, share=share)
