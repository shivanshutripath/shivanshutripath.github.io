"""
One trial of case study (B), with everything recorded.

``run_trial_logged`` is ``experiments.run_trial(cs, N, rng, taus, extra=True)``
statement by statement: the same random draws in the same order and the same
arithmetic, so that for the same generator it produces the same trial.  It
also keeps what run_trial discards: the noise of every measurement and
gradient, the gradients the servers received during data collection, the
forecasts and the boosts of every method, and two operational references that
are not in the paper ("frozen": keep the boosts of day N-1; "noboost": x = 0).
tests/test_exact.py checks it against run_trial.

Session logs.  The paper's server i receives, once per step during data
collection, a noisy gradient of f_i at the unboosted configuration x = 0,

    y_i(0, t) = grad f_i^0(0) + C_i(0) theta_i(t) + w_m,i(t) = C_i(0) u_i(t) + w_m,i(t),

with C_i(0) = -diag(sigma(0)) = -I/2 and the measurement noise
w_m,i(t) ~ N(0, 0.15^2 I) (the paper's w_{m,i}(t); its w_i(t) is the process
noise of theta_i, standard deviation 0.02).  In the demo
this measurement is computed from data: an exploration slice of S unboosted
sessions per day, each logging a net engagement score per genre (positive minus
negative interactions with the genre's products, normalized).  The server
averages the scores, u_hat = mean_s e_s, and its measurement is
ytilde_i(t) = C_i(0) (u_hat - ubar_i).  If e_s ~ N(u_i(t), sigma^2 I) i.i.d.
with sigma = 0.15 sqrt(S) / |C_ll(0)| (= 3 for S = 100), ytilde_i(t) has
exactly the paper's distribution.  ``SessionLog`` draws the S scores
conditionally on their mean, which it sets to u_i(t) + C_i(0)^{-1} w_m,i(t) with
the paper's own draw w_m,i(t): for Gaussian samples the mean and the deviations
from it are independent, so the scores are i.i.d. N(u_i(t), sigma^2 I) in
distribution, and the trial is the paper's trial.
"""
from dataclasses import dataclass

import numpy as np

from .paper import ref

HORIZON = 200                 # tracking steps after N: T = N + 200, as in the paper
RMSE_FROM = 50                # the paper's RMSE window is [N + 50, N + 200)
SESSIONS_PER_DAY = 100        # exploration sessions per region and day

# every method whose boosts the demo records (paper methods first)
PAPER_METHODS = ["persistence", "local", "coop1", "coop3", "exact", "pooledLS",
                 "centralized", "oracleA", "oracleKF"]
EXTRA_METHODS = ["frozen", "noboost"]


@dataclass
class Trial:
    N: int
    k: int
    T: int
    taus: tuple
    Theta: np.ndarray          # (T, m, p) drifts theta_i(t)
    u: np.ndarray              # (T, m, p) interests u_i(t) = ubar_i + theta_i(t)
    xstar: np.ndarray          # (T, n) minimizer of the team cost
    Y: np.ndarray              # (m, N, n) measurements of the paper's model
    Y_used: np.ndarray         # (m, N, n) measurements the servers used (Y, or computed from logs)
    Cs: np.ndarray             # (m, N, n, p) C_{i,t}
    Wy: np.ndarray             # (N, m, n) measurement noise w_m,i(t)
    Wg: np.ndarray             # (N, m, n) noise of the gradients at the iterates
    G_data: np.ndarray         # (N, m, n) gradients received at the iterates, t < N
    X_data: np.ndarray         # (N, m, n) iterates x_i(t), t < N
    th: np.ndarray             # (m, N-k+1, p) window estimates theta_tilde_i(t)
    anchors: np.ndarray        # (m, p) theta_tilde_i(N-k)
    moments: dict              # "iv": (M0, M1), "ls": (L0, L1), local (before consensus)
    estimates: dict            # key -> (A_hat (m, p, p), rho_raw (m,))
    forecasts: dict            # key -> (T-N, m, p) theta_hat_i(t), t = N..T-1
    boosts: dict               # key -> (T, m, n) x_i(t), t = 0..T-1 (data phase shared; noboost is 0 throughout)
    rmse: dict                 # key -> tracking RMSE over [N+50, T) (the paper's metric)
    id: dict                   # key -> (m,) ||A_hat_i - A||_F
    unstable: dict             # key -> fraction of servers whose raw estimate is not Schur stable
    recon: float               # RMS reconstruction error of the window estimates

    @property
    def window(self):
        return np.arange(self.N + RMSE_FROM, self.T)


def run_trial_logged(cs, N, rng, taus=(3, 1), k=None, measure=None):
    """experiments.run_trial(cs, N, rng, taus, extra=True), recording everything.

    measure(Theta_data, Y, Wy, Cs) -> measurements, optional: replaces the
    measurements Y of the paper's model by those the servers compute from
    their data (``SessionLog``); it must not touch ``rng``."""
    m, n, p, T = cs.m, cs.n, cs.p, N + HORIZON
    k = cs.k if k is None else k
    A, Q, R = cs.A, cs.Q, cs.R
    Lq, Lr, Lp = np.linalg.cholesky(Q), np.linalg.cholesky(R), np.linalg.cholesky(cs.P0)

    # latent parameters theta_i(t), t = 0..T-1, and the minimizers x*(t)
    Theta = np.zeros((T, m, p))
    Theta[0] = rng.standard_normal((m, p)) @ Lp.T
    for t in range(1, T):
        Theta[t] = Theta[t - 1] @ A.T + rng.standard_normal((m, p)) @ Lq.T
    xstar = np.zeros((T, n))
    x_prev = None
    for t in range(T):
        xstar[t] = cs.minimizer(Theta[t], x_prev)
        x_prev = xstar[t]

    # ---- data collection: gradient tracking driven by the gradients at the iterates
    Y = np.zeros((m, N, n))
    Cs = np.zeros((m, N, n, p))
    X = np.zeros((m, n))
    Wy = np.zeros((N, m, n))
    Wg = np.zeros((N, m, n))
    G_data = np.zeros((N, m, n))

    def oracle_signal(t, Xcur):
        G = np.zeros((m, n))
        for i in range(m):
            w = Lr @ rng.standard_normal(n)
            Wg[t, i] = w
            G[i] = cs.grad(i, Xcur[i], Theta[t, i]) + w
        G_data[t] = G
        return G

    def record_exploration(t, Xcur, Gcur):
        for i in range(m):
            xe = cs.explore(i, t, Xcur[i])
            Cs[i, t] = cs.C(i, xe)
            if cs.single_query():
                Y[i, t] = Gcur[i] - cs.grad_f0(i, Xcur[i])
            else:
                w = Lr @ rng.standard_normal(n)
                Wy[t, i] = w
                Y[i, t] = Cs[i, t] @ Theta[t, i] + w

    G = oracle_signal(0, X)
    S = G.copy()
    record_exploration(0, X, G)
    X_data = [X.copy()]
    for t in range(0, N - 1):
        X_new = cs.W @ (X - cs.alpha * S)
        G_new = oracle_signal(t + 1, X_new)
        record_exploration(t + 1, X_new, G_new)
        S = cs.W @ (S + G_new - G)
        X, G = X_new, G_new
        X_data.append(X.copy())
    X_N1, S_N1, G_N1 = X, S, G
    X_data = np.array(X_data)

    Y_used = Y if measure is None else measure(Theta[:N], Y, Wy, Cs)

    # ---- identification (Layer 2) ----
    if 2 * k >= N - 1:
        raise ValueError("N too small for window length k")
    th = ref.window_estimates(cs, Y_used, Cs, N, k)
    M0, M1 = ref.iv_moments(th, N, k)
    anchors = th[:, N - k]
    recon = float(np.sqrt(np.mean(np.sum((th - Theta[:N - k + 1].transpose(1, 0, 2)) ** 2, axis=2))))

    estimates = {"local": ref.identify(M0, M1, cs.W, 0)}
    for tau in taus:
        estimates["coop%d" % tau] = ref.identify(M0, M1, cs.W, tau)
    estimates["exact"] = ref.identify(M0, M1, cs.W, None)
    L0, L1 = ref.ls_moments(th, N, k)
    estimates["pooledLS"] = ref.identify(L0, L1, cs.W, None)

    # ---- tracking (Layer 3) for every forecaster ----
    forecasters = {key: ref.Forecaster(cs, list(Ah), anchors, N - k) for key, (Ah, _) in estimates.items()}
    forecasters["persistence"] = ref.Forecaster(cs, [np.eye(p)] * m, anchors, N - k)
    forecasters["oracleA"] = ref.Forecaster(cs, [A] * m, anchors, N - k)
    forecasters["oracleKF"] = ref.Forecaster(cs, [A] * m, ref.kalman_forecast_state(cs, Y_used, Cs, N), N - 1)

    boosts, forecasts = {}, {}
    for key, fc in forecasters.items():
        rec = np.zeros((T - N, m, p))

        def forecast_signal(t, Xcur, fc=fc, rec=rec):
            Th = fc.at(t)
            rec[t - N] = Th
            return np.array([cs.grad(i, Xcur[i], Th[i]) for i in range(m)])

        # at t = N the signal switches to the forecast gradient; the tracker is
        # updated with gamma(N) - gamma(N-1), as in Algorithm 1 and run_trial
        X = cs.W @ (X_N1 - cs.alpha * S_N1)
        G_N = forecast_signal(N, X)
        S = cs.W @ (S_N1 + G_N - G_N1)
        traj, _, _, _ = ref.gradient_tracking_phase(cs, X, S, G_N, N, T - 1, forecast_signal)
        boosts[key] = np.concatenate([X_data, np.array(traj)])
        forecasts[key] = rec

    # centralized predictor: exact minimizer of F_hat(., t) from the cooperative forecasts
    key0 = "coop%d" % taus[0]
    fc = ref.Forecaster(cs, list(estimates[key0][0]), anchors, N - k)
    xh, xh_prev = [], None
    for t in range(N, T):
        xh_prev = cs.minimizer(fc.at(t), xh_prev)
        xh.append(np.repeat(xh_prev[None, :], m, axis=0))
    boosts["centralized"] = np.concatenate([X_data, np.array(xh)])
    forecasts["centralized"] = forecasts[key0]

    # operational references (not in the paper)
    boosts["frozen"] = np.concatenate([X_data, np.repeat(X_N1[None], T - N, axis=0)])
    boosts["noboost"] = np.zeros((T, m, n))

    def rmse_of(traj):  # as experiments.run_trial: traj[t - N] = X(t)
        err = np.array([np.mean(np.sum((traj[t - N] - xstar[t]) ** 2, axis=1)) for t in range(N + RMSE_FROM, T)])
        return float(np.sqrt(np.mean(err)))

    rmse = {key: rmse_of(b[N:]) for key, b in boosts.items()}
    ids = {key: np.linalg.norm(Ah - A, axis=(1, 2)) for key, (Ah, _) in estimates.items()}
    unstable = {key: float(np.mean(rho >= 1.0)) for key, (_, rho) in estimates.items()}

    return Trial(N=N, k=k, T=T, taus=tuple(taus), Theta=Theta, u=cs.ubar[None] + Theta, xstar=xstar,
                 Y=Y, Y_used=Y_used, Cs=Cs, Wy=Wy, Wg=Wg, G_data=G_data, X_data=X_data, th=th,
                 anchors=anchors, moments={"iv": (M0, M1), "ls": (L0, L1)}, estimates=estimates,
                 forecasts=forecasts, boosts=boosts, rmse=rmse, id=ids, unstable=unstable, recon=recon)


def paper_trial_rng(N, trial, seed=None):
    """The generator experiments.py uses for trial ``trial`` of the N-sweep."""
    from .paper import CASE_ID, SEED
    return np.random.default_rng([SEED if seed is None else seed, CASE_ID, N, trial])


# ----------------------------------------------------------------------------
# session logs of the exploration slice
# ----------------------------------------------------------------------------
def session_sigma(cs, S=SESSIONS_PER_DAY):
    """Per-session standard deviation of the net engagement scores, per genre,
    for which the mean of S scores, mapped by C_i(0), has the paper's noise."""
    c0 = np.abs(np.diag(cs.C(0, np.zeros(cs.n))))
    for i in range(cs.m):
        if not np.allclose(np.abs(np.diag(cs.C(i, np.zeros(cs.n)))), c0):
            raise ValueError("C_i(0) differs across servers")
    if not np.allclose(cs.R, np.diag(np.diag(cs.R))):
        raise ValueError("R must be diagonal")
    return np.sqrt(np.diag(cs.R)) * np.sqrt(S) / c0


class SessionLog:
    """measure() hook for run_trial_logged: draws the exploration sessions and
    returns the measurements the servers compute from them.

    After the call, ``self.users`` (N, m, S) holds the shopper of every
    session (global shopper index), ``self.scores`` (N, m, S, n) the net
    engagement scores, ``self.u_hat`` (N, m, n) the daily averages, and
    ``self.y`` (m, N, n) the measurements ytilde_i(t)."""

    def __init__(self, world, rng, S=SESSIONS_PER_DAY):
        self.world, self.rng, self.S = world, rng, S
        self.sigma = session_sigma(world.cs, S)

    def __call__(self, Theta_data, Y, Wy, Cs):
        cs, S, rng = self.world.cs, self.S, self.rng
        N, m, n = Wy.shape
        self.users = np.zeros((N, m, S), dtype=int)
        self.scores = np.zeros((N, m, S, n))
        self.u_hat = np.zeros((N, m, n))
        y = np.zeros((m, N, n))
        for t in range(N):
            for i in range(m):
                C = Cs[i, t]
                u = cs.ubar[i] + Theta_data[t, i]
                target = u + np.linalg.solve(C, Wy[t, i])          # u_i(t) + C^{-1} w_m,i(t)
                eta = self.sigma * rng.standard_normal((S, n))
                scores = target + (eta - eta.mean(axis=0))
                self.users[t, i] = rng.choice(self.world.by_region[i], size=S, replace=False)
                self.scores[t, i] = scores
                # what server i computes from its own logs
                u_hat = scores.mean(axis=0)
                self.u_hat[t, i] = u_hat
                y[i, t] = C @ (u_hat - cs.ubar[i])
        self.y = y
        return y
