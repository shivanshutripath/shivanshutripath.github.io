"""
The concrete instance of case study (B): regions, backbone, catalog, shoppers.

The numbers that the paper's model uses are those of the paper's instance
(seed 2026): the boost-penalty weights lambda_i (``varpi`` in experiments.py),
the known average interests ubar_{i,l}, the backbone (ring 1-2-...-8-1 with the
chords (1,5) and (3,7)) and its Metropolis weights.  The names of the regions,
the genres and the products, the prices, and the shoppers are the concrete
layer of this demo: they make the feeds readable, and they never enter the
cost f_i or Algorithm 1.  Shopper ids reach the servers only as labels of the
session logs; no session score depends on a shopper or a product.

Feeds.  The platform ranks products with a shared base model; for shopper s
and product j its score is

    score_{s,j}(x) = b_j + a_{s,g(j)} + e_{s,j} + x_{g(j)}   (boosted genres)
    score_{s,j}    = b_j + e_{s,j}                            (essentials)

where b_j is the product's base score, a_s the shopper's genre affinity, e_{s,j}
a fixed personal taste term, and x the three genre boosts that the servers must
agree on (the logit shifts of the genres in every feed, Section 5.1 of the
paper).  The feed is the top-8 products by score.
The affinities are centered on half of the deviation of the region's known
average interests from their mean over the genres,
a_s = 0.5 (ubar_i - mean(ubar_i)) + 0.4 z, so the feeds differ by region; the
boosts are common to all regions.
"""
from dataclasses import dataclass, field

import numpy as np

from .paper import CASE, CASE_ID, SEED, ref

# ----------------------------------------------------------------------------
# regions, in the order of the paper's servers 1..8
# ----------------------------------------------------------------------------
REGIONS = [
    # code, region,                 data center,    lat,     lon
    ("NAM", "North America",        "Chicago",       41.88,  -87.63),
    ("EU",  "Europe",               "Frankfurt",     50.11,    8.68),
    ("MEA", "Middle East & Africa", "Johannesburg", -26.20,   28.05),
    ("SA",  "South Asia",           "Mumbai",        19.08,   72.88),
    ("SEA", "Southeast Asia",       "Singapore",      1.35,  103.82),
    ("EA",  "East Asia",            "Tokyo",         35.68,  139.69),
    ("OC",  "Oceania",              "Sydney",       -33.87,  151.21),
    ("LA",  "Latin America",        "Sao Paulo",    -23.55,  -46.63),
]
CHORDS = [(1, 5), (3, 7)]          # 1-based, as in experiments.Recommendation

# ----------------------------------------------------------------------------
# genres and catalog
# ----------------------------------------------------------------------------
# genre l = 1, 2, 3 of the paper (array index 0, 1, 2); index 3 = not boosted
GENRES = ["Outdoor & Sports", "Home & Kitchen", "Trending Tech", "Everyday Essentials"]
GENRE_KEYS = ["outdoor", "home", "tech", "essentials"]
BOOSTED = 3                         # the first three genres carry a boost

# What the shared dynamics A = blkdiag(0.98 Rot(0.25), 0.95) mean for them:
GENRE_DYNAMICS = [
    "a damped cycle of about 25 days, shared with Home & Kitchen, which peaks about 6 days later",
    "the same damped 25-day cycle, a quarter cycle (about 6 days) behind Outdoor & Sports",
    "a hype that fades: its excess interest decays by 5% a day",
    "not boosted; the base model alone ranks it",
]

# product id, name, genre index, price (USD), base score b_j of the shared ranker
CATALOG = [
    ("P01", "Trail running shoes",          0, 119.0,  0.45),
    ("P02", "2-person backpacking tent",    0, 189.0,  0.10),
    ("P03", "Insulated water bottle",       0,  32.0,  0.55),
    ("P04", "Yoga mat",                     0,  45.0,  0.30),
    ("P05", "Cycling helmet",               0,  79.0, -0.05),
    ("P06", "Hiking daypack 25 L",          0,  69.0,  0.20),
    ("P07", "Rechargeable headlamp",        0,  29.0, -0.20),
    ("P08", "Adjustable dumbbells",         0, 249.0, -0.35),
    ("P09", "Cast-iron skillet",            1,  39.0,  0.40),
    ("P10", "Air fryer 5 L",                1,  99.0,  0.60),
    ("P11", "Pour-over coffee set",         1,  49.0,  0.15),
    ("P12", "Chef's knife",                 1,  79.0,  0.05),
    ("P13", "Linen throw blanket",          1,  59.0, -0.10),
    ("P14", "Glass storage jars, set of 6", 1,  34.0,  0.25),
    ("P15", "Enameled Dutch oven",          1, 129.0, -0.25),
    ("P16", "Bamboo cutting board",         1,  25.0, -0.40),
    ("P17", "Wireless earbuds",             2,  89.0,  0.50),
    ("P18", "Smart LED light strip",        2,  35.0,  0.20),
    ("P19", "Mini projector",               2, 159.0,  0.05),
    ("P20", "Instant print camera",         2,  99.0,  0.30),
    ("P21", "Fitness smartwatch",           2, 199.0,  0.35),
    ("P22", "Power bank 20,000 mAh",        2,  45.0, -0.05),
    ("P23", "Mechanical keyboard",          2, 119.0, -0.20),
    ("P24", "Retro handheld console",       2,  69.0, -0.30),
    ("P25", "Laundry detergent pods",       3,  19.0,  1.30),
    ("P26", "Paper towels, 12 rolls",       3,  24.0,  1.15),
    ("P27", "Toothpaste, 4-pack",           3,  12.0,  1.00),
    ("P28", "Dish soap refill",             3,   9.0,  0.90),
    ("P29", "AA batteries, 24-pack",        3,  18.0,  1.05),
    ("P30", "Trash bags, 100",              3,  16.0,  0.80),
    ("P31", "Ground coffee 1 kg",           3,  21.0,  1.20),
    ("P32", "Hand soap refill",             3,  11.0,  0.85),
]

FEED_SIZE = 8                       # products on the first screen of a feed
EXPLORE_PER_GENRE = 3               # exploration slice: 3 unboosted slots per genre

# shoppers: affinity a_s = TILT * (ubar_i - mean(ubar_i)) + PERSONAL_SD * z,
# taste e_{s,j} = TASTE_SD * z'
USERS_PER_REGION = 500
TILT = 0.5
PERSONAL_SD = 0.4
TASTE_SD = 0.3


@dataclass
class World:
    cs: object                      # experiments.Recommendation (the paper's instance)
    regions: list                   # dicts: code, name, hub, lat, lon, lam, ubar, neighbors
    edges: list                     # backbone links (i, j), 0-based, i < j
    products: dict                  # arrays: pid, name, genre, price, base
    users: dict                     # arrays: uid, region, affinity (U,3), taste (U,P), base_scores (U,P)
    by_region: list                 # by_region[i] = indices of the shoppers of region i
    explore_feed: np.ndarray        # (U, 4*EXPLORE_PER_GENRE) product indices of the exploration feed
    seed: int = SEED
    params: dict = field(default_factory=dict)

    @property
    def m(self):
        return self.cs.m

    def region_label(self, i):
        r = self.regions[i]
        return "%d %s (%s)" % (i + 1, r["name"], r["hub"])


def make_world(seed=SEED, users_per_region=USERS_PER_REGION):
    """The paper's instance of case study (B) with its concrete layer."""
    cs = ref.make_case(CASE, np.random.default_rng([seed, CASE_ID]))
    m = cs.m
    assert m == len(REGIONS)

    # backbone: the graph whose Metropolis weights are cs.W
    adj = ref.ring_graph(m, chords=CHORDS)
    if not np.allclose(ref.metropolis(adj), cs.W):
        raise RuntimeError("backbone does not match the paper's instance")
    edges = [(i, j) for i in range(m) for j in range(i + 1, m) if adj[i, j]]

    regions = []
    for i, (code, name, hub, lat, lon) in enumerate(REGIONS):
        nb = [j for j in range(m) if adj[i, j]]
        regions.append(dict(index=i, code=code, name=name, hub=hub, lat=lat, lon=lon,
                            lam=float(cs.varpi[i]), ubar=cs.ubar[i].copy(), neighbors=nb))

    products = dict(
        pid=np.array([c[0] for c in CATALOG]),
        name=np.array([c[1] for c in CATALOG], dtype=object),
        genre=np.array([c[2] for c in CATALOG], dtype=int),
        price=np.array([c[3] for c in CATALOG]),
        base=np.array([c[4] for c in CATALOG]),
    )
    P = len(CATALOG)

    # shoppers (fixed part of the shared base model; drawn once, own stream)
    rng = np.random.default_rng([seed, CASE_ID, 9001])
    U = users_per_region * m
    region = np.repeat(np.arange(m), users_per_region)
    tilt = TILT * (cs.ubar - cs.ubar.mean(axis=1, keepdims=True))          # (m, 3)
    affinity = tilt[region] + PERSONAL_SD * rng.standard_normal((U, BOOSTED))
    taste = TASTE_SD * rng.standard_normal((U, P))
    boosted = products["genre"] < BOOSTED
    base_scores = products["base"][None, :] + taste
    base_scores[:, boosted] += affinity[:, products["genre"][boosted]]
    uid = np.array(["%s-%04d" % (REGIONS[r][0], k + 1) for r in range(m) for k in range(users_per_region)])
    by_region = [np.flatnonzero(region == i) for i in range(m)]

    # exploration feed (boosts x = 0): the shopper's top-3 products of every genre
    explore = np.zeros((U, len(GENRES) * EXPLORE_PER_GENRE), dtype=int)
    for g in range(len(GENRES)):
        cols = np.flatnonzero(products["genre"] == g)
        order = np.argsort(-base_scores[:, cols], axis=1)[:, :EXPLORE_PER_GENRE]
        explore[:, g * EXPLORE_PER_GENRE:(g + 1) * EXPLORE_PER_GENRE] = cols[order]

    users = dict(uid=uid, region=region, affinity=affinity, taste=taste, base_scores=base_scores)
    params = dict(users_per_region=users_per_region, tilt=TILT, personal_sd=PERSONAL_SD,
                  taste_sd=TASTE_SD, feed_size=FEED_SIZE, explore_per_genre=EXPLORE_PER_GENRE)
    return World(cs=cs, regions=regions, edges=edges, products=products, users=users,
                  by_region=by_region, explore_feed=explore, seed=seed, params=params)


def boost_vector(world, x):
    """Per-product logit shift for boosts x (..., 3): x_{g(j)} for boosted products, 0 otherwise."""
    x = np.asarray(x, float)
    g = world.products["genre"]
    pad = np.concatenate([x, np.zeros(x.shape[:-1] + (1,))], axis=-1)    # (..., 4)
    return pad[..., g]                                                    # (..., P)
