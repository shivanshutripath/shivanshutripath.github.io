"""
Access to the paper's reference implementation.

Everything numerical in this demo that the paper also computes (the instance,
the latent interests, the minimizer, Algorithm 1 and its baselines) is taken
from ``paper_v4_package/code/experiments.py``, the code behind the paper's
figures, so that the concrete simulation is case study (B) and nothing else.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DEMO = os.path.dirname(HERE)                       # .../recommendation_demo
ROOT = os.path.dirname(DEMO)                       # the project folder
REF_CODE = os.path.join(ROOT, "paper_v4_package", "code")
REF_DATA = os.path.join(REF_CODE, "data")          # the run reported in the paper
if REF_CODE not in sys.path:
    sys.path.insert(0, REF_CODE)

import experiments as ref  # noqa: E402  (the paper's reference implementation)

CASE = "recommendation"
CASE_ID = ref.CASE_ID[CASE]                        # = 3, part of every seed of case study (B)
SEED = 2026                                        # the seed of the paper's run
