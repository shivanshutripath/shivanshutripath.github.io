"""
The showcase trial of case study (B) as a distributed system: one OS process
per regional server.

The paper's servers share no memory: server i holds its own constants and
data and talks only to its backbone neighbors.  ``run_distributed`` runs the
trial that way, as the Webots demo of case study (A) runs one controller
process per station.

* m server processes (multiprocessing, start method 'spawn').  Server i starts
  from a ``ServerConfig``: lambda_i, ubar_i, the model f_i^0 and C_i (the
  paper's formulas), R, k = 3, alpha = 0.25, tau, rho_max = 0.999, its row of
  W, N and the horizon T.  Nothing else: no interest, no A, no other region's
  constant or data.  It runs Algorithm 1 of the paper (``Server.run``).
* The calling process plays the environment, the platform and its shoppers
  (``Platform``).  It owns the truth: it draws theta_i(t) of every region for
  all T days, the noise and the exploration sessions with the generators and
  in the order of simulate.run_trial_logged and simulate.SessionLog.  On every
  day t < N it sends server i region i's sessions of that day (shopper ids and
  net scores, S x 3) and the noisy gradient of f_i at the boosts x_i(t) that
  server i deployed; nothing else, and nothing from day N on.
* One duplex Pipe per backbone link (``Link``).  A message is (type, step,
  round, reals); ``Link`` passes only the three types of Algorithm 1, checks
  their sizes and logs every message at both ends.  An exchange sends to every
  neighbor first and then receives from every neighbor, so it cannot deadlock.
* At the end every server sends its record (iterates, estimates, message
  logs) to the calling process, the experimenter's recorder.  The record is
  not part of the algorithm.

Algorithm 1 at server i (``Server.run``):

    day t < N    deploy x_i(t); receive region i's sessions of day t and the
                 report gamma_i(t) = grad f_i(x_i(t), theta_i(t)) + noise;
                 measurement ytilde_i(t) = C_i(0) (mean of the scores - ubar_i)
    step t       exchange x_i(t) - alpha s_i(t):  x_i(t+1) = sum_j W_ij (x_j - alpha s_j)
                 gamma_i(t+1) = report of day t+1 (t+1 < N), or the forecast
                 gradient grad f_i(x_i(t+1), theta_hat_i(t+1)) (t+1 >= N)
                 exchange s_i(t) + gamma_i(t+1) - gamma_i(t):  s_i(t+1) = sum_j W_ij (...)
    step N-1     between the two exchanges (Algorithm 1, "t+1 = N"): window
                 estimates (eq. (5)), IV moments (eq. (8)), tau rounds of
                 consensus on (M0, M1) with the neighbors, A_hat_i = M1 M0^{-1}
                 with the spectral-radius safeguard, and the forecaster
                 theta_hat_i(t) = A_hat_i^(t-(N-k)) theta_tilde_i(N-k)

for t = 0..T-2, with s_i(0) = gamma_i(0).  This is the recursion of
experiments.run_trial, the switch at t = N included (x_i(N) and the
identification do not depend on each other, so their order is immaterial).
The single-agent steps are the paper's own functions (window_estimates,
iv_moments, identify, Forecaster, Recommendation.grad) called on a one-agent
model (``LocalModel``).  Weighted sums run over j in increasing order, the
order of the matrix products W @ X of experiments.py; on the machine of the
showcase run the distributed run reproduces the in-process run bit for bit
(run_distributed.py and tests/test_distributed.py check it).
"""
import hashlib
import inspect
import multiprocessing as mp
import time
import traceback
from collections import Counter
from dataclasses import dataclass
from multiprocessing.connection import wait as mp_wait

import numpy as np

from .paper import CASE_ID, SEED, ref
from .simulate import HORIZON, RMSE_FROM, SESSIONS_PER_DAY, SessionLog, paper_trial_rng

START_METHOD = "spawn"         # the macOS default; also used on Linux, for the same behavior
SESSION_STREAM = 9002          # rng([seed, 3, 9002, N, trial]) draws the sessions, as in run_demo.py
RHO_MAX = inspect.signature(ref.identify).parameters["rho_max"].default   # 0.999, as run_trial
TOL = 1e-9                     # agreement required with the in-process run (max absolute difference)

# What may cross a backbone link: the variables of Algorithm 1, nothing else.
BACKBONE_TYPES = {
    "gt_x": "x_i(t) - alpha s_i(t)               gradient tracking, 1st exchange of step t",
    "gt_s": "s_i(t) + gamma_i(t+1) - gamma_i(t)  gradient tracking, 2nd exchange of step t",
    "moments": "(M0, M1) after r-1 rounds          identification, step N-1, round r = 1..tau",
}
# What crosses the channel between the platform and server i (days t < N only).
PLATFORM_TYPES = {
    "deploy": "server i -> platform: the boosts x_i(t) it serves on day t",
    "sessions": "platform -> server i: region i's exploration sessions of day t (shopper id, net scores)",
    "report": "platform -> server i: noisy gradient of f_i at x_i(t)",
}


def backbone_sizes(n, p):
    """Number of reals of each backbone message type."""
    return {"gt_x": n, "gt_s": n, "moments": 2 * p * p}


def phase_of(step, N):
    """Phase of step t of the recursion: data collection, the switch, tracking."""
    return "data" if step < N - 1 else ("switch" if step == N - 1 else "tracking")


# ----------------------------------------------------------------------------
# what a server knows
# ----------------------------------------------------------------------------
@dataclass
class ServerConfig:
    """Everything server i knows when its process starts."""
    i: int                  # index, 0-based (the paper's server i+1)
    code: str               # region code
    lam: float              # lambda_i, boost-penalty weight
    ubar: np.ndarray        # (n,) ubar_i, known average interests of its users
    R: np.ndarray           # (n, n) covariance of the measurement noise
    weights: dict           # {j: W_ij} for j in N_i and j = i: its row of W
    k: int                  # window length
    alpha: float            # step size of gradient tracking
    tau: int                # consensus rounds
    rho_max: float          # spectral-radius safeguard
    N: int                  # days of data collection
    T: int                  # horizon: days 0..T-1
    box_lo: np.ndarray      # (p,) its box B_i, used only if experiments.PROJECTION is set
    box_hi: np.ndarray
    projection: bool

    @property
    def neighbors(self):
        return sorted(j for j in self.weights if j != self.i)


def server_configs(world, N, tau=3):
    """The ServerConfig of every server of the world (paper instance)."""
    cs = world.cs
    out = []
    for i, r in enumerate(world.regions):
        w = {j: float(cs.W[i, j]) for j in sorted(r["neighbors"] + [i])}
        out.append(ServerConfig(i=i, code=r["code"], lam=float(cs.varpi[i]), ubar=cs.ubar[i].copy(),
                                R=cs.R.copy(), weights=w, k=cs.k, alpha=cs.alpha, tau=tau, rho_max=RHO_MAX,
                                N=N, T=N + HORIZON, box_lo=cs.box_lo[i].copy(), box_hi=cs.box_hi[i].copy(),
                                projection=bool(ref.PROJECTION)))
    return out


class LocalModel:
    """Server i's model of its cost: experiments.Recommendation reduced to one
    agent (index 0) with server i's constants, so that the paper's functions
    (window_estimates, iv_moments, identify, Forecaster) run on it unchanged."""

    grad_f0 = ref.Recommendation.grad_f0       # lambda_i x - ubar_i sigma(-x)
    C = ref.Recommendation.C                   # C_i(x) = -diag(sigma(-x))
    explore = ref.Recommendation.explore       # exploration point x^e = 0
    grad = ref.CaseStudy.grad                  # grad f_i(x, theta) = grad f_i^0(x) + C_i(x) theta

    def __init__(self, cfg):
        self.m, self.n, self.p = 1, len(cfg.ubar), len(cfg.ubar)
        self.varpi = np.array([cfg.lam])
        self.ubar = np.asarray(cfg.ubar, dtype=float)[None, :]
        self.R = np.asarray(cfg.R, dtype=float)
        self.box_lo, self.box_hi = cfg.box_lo[None, :], cfg.box_hi[None, :]
        self.projection = cfg.projection

    def project(self, i, theta):
        """experiments.CaseStudy.project, with the flag of the configuration."""
        if not self.projection:
            return theta
        return np.minimum(np.maximum(theta, self.box_lo[i]), self.box_hi[i])


# ----------------------------------------------------------------------------
# channels
# ----------------------------------------------------------------------------
class Link:
    """Server i's end of its backbone link to server j (a duplex Pipe).  Only
    the types of BACKBONE_TYPES pass, with their sizes, and every message is
    logged as (type, step, round, reals) at both ends."""

    def __init__(self, peer, conn, sizes):
        self.peer, self.conn, self.sizes = peer, conn, sizes
        self.sent, self.received = [], []

    def _check(self, kind, values):
        if kind not in self.sizes:
            raise ValueError("message type %r may not cross a backbone link" % (kind,))
        if not isinstance(values, np.ndarray) or values.dtype != np.float64 or values.shape != (self.sizes[kind],):
            raise ValueError("a %s message holds %d reals" % (kind, self.sizes[kind]))

    def send(self, kind, step, rnd, values):
        values = np.ascontiguousarray(values, dtype=np.float64).ravel()
        self._check(kind, values)
        self.conn.send((kind, step, rnd, values))
        self.sent.append((kind, step, rnd, values.size))

    def recv(self, kind, step, rnd):
        msg = self.conn.recv()
        if tuple(msg[:3]) != (kind, step, rnd):
            raise RuntimeError("link to server %d: expected %s, received %s" % (self.peer + 1, (kind, step, rnd), msg[:3]))
        self._check(kind, msg[3])
        self.received.append((kind, step, rnd, msg[3].size))
        return msg[3]


class PlatformPort:
    """Server i's end of its channel to the platform, with counters per type
    (messages, reals, session rows)."""

    def __init__(self, conn):
        self.conn = conn
        self.count = {kind: Counter() for kind in PLATFORM_TYPES}

    def _expect(self, kind, t):
        msg = self.conn.recv()
        if tuple(msg[:2]) != (kind, t):
            raise RuntimeError("platform channel: expected %s of day %d, received %s" % (kind, t, msg[:2]))
        return msg[2:]

    def deploy(self, t, x):
        self.conn.send(("deploy", t, np.array(x, dtype=float)))
        self.count["deploy"].update(msgs=1, reals=x.size)

    def receive_day(self, t):
        users, scores = self._expect("sessions", t)
        (report,) = self._expect("report", t)
        self.count["sessions"].update(msgs=1, rows=len(users), reals=scores.size, ids=users.size)
        self.count["report"].update(msgs=1, reals=report.size)
        return users, scores, report


def session_digest(users, scores):
    """SHA-256 of a region's session logs, day by day (users (N, S), scores (N, S, n))."""
    h = hashlib.sha256()
    for u, s in zip(users, scores):
        h.update(np.ascontiguousarray(u, dtype=np.int64).tobytes())
        h.update(np.ascontiguousarray(s, dtype=np.float64).tobytes())
    return h.hexdigest()


# ----------------------------------------------------------------------------
# the server process
# ----------------------------------------------------------------------------
class Server:
    """Algorithm 1 at server i, inside its own process."""

    def __init__(self, cfg, platform_conn, peer_conns):
        self.cfg = cfg
        self.model = mdl = LocalModel(cfg)
        n, p, N, T = mdl.n, mdl.p, cfg.N, cfg.T
        sizes = backbone_sizes(n, p)
        self.links = {j: Link(j, peer_conns[j], sizes) for j in cfg.neighbors}
        self.port = PlatformPort(platform_conn)
        self.order = sorted(cfg.weights)                       # N_i and i, increasing index
        self.w = np.array([cfg.weights[j] for j in self.order])
        self.X = np.zeros((T, n))                              # x_i(t), t = 0..T-1
        self.Y = np.zeros((N, n))                              # ytilde_i(t), t < N (never sent)
        self.Cs = np.zeros((N, n, p))                          # C_{i,t}
        self.reports = np.zeros((N, n))                        # gradient reports received
        self.forecasts = np.zeros((T - N, p))                  # theta_hat_i(t), t = N..T-1
        self.digest = hashlib.sha256()                         # of the sessions received
        self.fc = None
        self.timing = {}

    def mix(self, kind, step, rnd, value):
        """One exchange: send value to every neighbor, receive theirs, return
        sum_{j in N_i and i} W_ij value_j (summed in increasing j)."""
        flat = np.ascontiguousarray(value, dtype=np.float64).ravel()
        for link in self.links.values():
            link.send(kind, step, rnd, flat)
        got = {self.cfg.i: flat}
        for j, link in self.links.items():
            got[j] = link.recv(kind, step, rnd)
        return (self.w @ np.stack([got[j] for j in self.order])).reshape(np.shape(value))

    def observe(self, t, x):
        """Day t < N: deploy x_i(t), receive the day's sessions and gradient report,
        compute the measurement ytilde_i(t) = C_i(0) (mean score - ubar_i)."""
        mdl = self.model
        self.port.deploy(t, x)
        users, scores, report = self.port.receive_day(t)
        self.digest.update(np.ascontiguousarray(users, dtype=np.int64).tobytes())
        self.digest.update(np.ascontiguousarray(scores, dtype=np.float64).tobytes())
        C = mdl.C(0, mdl.explore(0, t, x))                      # C_i(0) = -I/2
        self.Cs[t] = C
        self.Y[t] = C @ (scores.mean(axis=0) - mdl.ubar[0])
        self.reports[t] = report
        return report

    def identify(self, step):
        """Layer 1 and 2 of Algorithm 1 at the end of data collection."""
        cfg, mdl = self.cfg, self.model
        N, k = cfg.N, cfg.k
        th = ref.window_estimates(mdl, self.Y[None], self.Cs[None], N, k)[0]     # (N-k+1, p)
        M0, M1 = (M[0] for M in ref.iv_moments(th[None], N, k))
        M = np.stack([M0, M1])
        for r in range(1, cfg.tau + 1):
            M = self.mix("moments", step, r, M)
        A_hat, rho = ref.identify(M[0][None], M[1][None], np.eye(1), 0, cfg.rho_max)   # tau = 0: no mixing
        self.fc = ref.Forecaster(mdl, [A_hat[0]], th[N - k][None], N - k)
        self.th, self.M_local, self.M_cons = th, np.stack([M0, M1]), M
        self.A_hat, self.rho_raw = A_hat[0], float(rho[0])

    def run(self):
        cfg, mdl = self.cfg, self.model
        N, T = cfg.N, cfg.T
        t0 = time.perf_counter()
        x = np.zeros(mdl.n)                                    # x_i(0) = 0
        gamma = self.observe(0, x)                             # gamma_i(0): report of day 0
        s = gamma.copy()                                       # s_i(0) = gamma_i(0)
        self.X[0] = x
        for t in range(T - 1):
            x_new = self.mix("gt_x", t, 0, x - cfg.alpha * s)
            if t + 1 < N:
                gamma_new = self.observe(t + 1, x_new)         # oracle gradient
            else:
                if t + 1 == N:
                    t1 = time.perf_counter()
                    self.timing["data"] = t1 - t0
                    self.identify(t)
                    self.timing["identification"] = time.perf_counter() - t1
                    t0 = time.perf_counter()
                th_hat = self.fc.at(t + 1)[0]
                self.forecasts[t + 1 - N] = th_hat
                gamma_new = mdl.grad(0, x_new, th_hat)         # forecast gradient
            s = self.mix("gt_s", t, 0, s + gamma_new - gamma)
            x, gamma = x_new, gamma_new
            self.X[t + 1] = x
        self.timing["tracking"] = time.perf_counter() - t0
        return self.record()

    def record(self):
        """What the experimenter's recorder receives at the end (not part of the algorithm)."""
        return dict(i=self.cfg.i, code=self.cfg.code, x=self.X, y=self.Y, reports=self.reports,
                    theta_tilde=self.th, M_local=self.M_local, M_consensus=self.M_cons,
                    A_hat=self.A_hat, rho_raw=self.rho_raw, forecasts=self.forecasts,
                    session_digest=self.digest.hexdigest(),
                    links={j: dict(sent=l.sent, received=l.received) for j, l in self.links.items()},
                    platform={kind: dict(c) for kind, c in self.port.count.items()},
                    timing=dict(self.timing), cpu=time.process_time())


def server_main(cfg, platform_conn, recorder_conn, peer_conns):
    """Entry point of the process of server cfg.i (module level, for 'spawn')."""
    try:
        record = Server(cfg, platform_conn, peer_conns).run()
        recorder_conn.send(("record", cfg.i, record))
    except BaseException:
        try:
            recorder_conn.send(("error", cfg.i, traceback.format_exc()))
        except Exception:
            pass
        raise
    finally:
        for c in [platform_conn, recorder_conn, *peer_conns.values()]:
            c.close()


# ----------------------------------------------------------------------------
# the environment
# ----------------------------------------------------------------------------
class Platform:
    """The platform and its shoppers: the truth of the trial.

    theta_i(t) for every region and day is drawn first, then, day by day, the
    noise of the gradient reports (servers 0..m-1) and the measurement noise
    w_m,i(t) of the exploration slices (0..m-1), from the trial's generator exactly as experiments.run_trial
    draws them (they do not depend on the boosts).  The sessions are drawn by
    simulate.SessionLog itself, one day at a time, from its own generator (its
    draws run t outer, i inner, so this gives the numbers of one call for all
    days).  ``serve`` returns what server i receives for day t: region i's
    sessions and the gradient of f_i at the boosts it deployed, plus noise."""

    def __init__(self, world, N, rng, session_rng, S=SESSIONS_PER_DAY):
        cs = world.cs
        if cs.single_query():
            raise ValueError("case study (B) queries the exploration point separately")
        m, n, p, T = cs.m, cs.n, cs.p, N + HORIZON
        self.world, self.cs, self.N, self.T, self.S, self.rng = world, cs, N, T, S, rng
        self.Lr = np.linalg.cholesky(cs.R)
        Lq, Lp = np.linalg.cholesky(cs.Q), np.linalg.cholesky(cs.P0)
        Theta = np.zeros((T, m, p))
        Theta[0] = rng.standard_normal((m, p)) @ Lp.T
        for t in range(1, T):
            Theta[t] = Theta[t - 1] @ cs.A.T + rng.standard_normal((m, p)) @ Lq.T
        self.Theta = Theta
        self.log = SessionLog(world, session_rng, S)
        self.users = np.zeros((N, m, S), dtype=int)
        self.scores = np.zeros((N, m, S, n))
        self.Wg = np.zeros((N, m, n))          # noise of the gradient reports
        self.Wy = np.zeros((N, m, n))          # measurement noise w_m,i(t) of the exploration slice
        self.X = np.full((N, m, n), np.nan)    # boosts deployed, t < N
        self.G = np.zeros((N, m, n))           # gradient reports sent
        self.sent = [{kind: Counter() for kind in PLATFORM_TYPES} for _ in range(m)]   # per server
        self.day = -1

    def open_day(self, t):
        cs, rng, m, n = self.cs, self.rng, self.cs.m, self.cs.n
        if t != self.day + 1:
            raise ValueError("days must be opened in order")
        for i in range(m):
            self.Wg[t, i] = self.Lr @ rng.standard_normal(n)
        for i in range(m):
            self.Wy[t, i] = self.Lr @ rng.standard_normal(n)
        # exploration slice at x = 0 (Recommendation.explore ignores the iterate)
        Cs = np.array([cs.C(i, cs.explore(i, t, np.zeros(n))) for i in range(m)])[:, None]   # (m, 1, n, p)
        self.log(self.Theta[t:t + 1], None, self.Wy[t:t + 1], Cs)
        self.users[t], self.scores[t] = self.log.users[0], self.log.scores[0]
        self.day = t

    def serve(self, i, t, x):
        """Server i deployed x on day t: returns (shopper ids, net scores, gradient report)."""
        if t != self.day:
            raise ValueError("day %d is not open" % t)
        self.X[t, i] = x
        self.G[t, i] = self.cs.grad(i, x, self.Theta[t, i]) + self.Wg[t, i]
        c = self.sent[i]
        c["deploy"].update(msgs=1, reals=x.size)                       # received from server i
        c["sessions"].update(msgs=1, rows=self.S, reals=self.scores[t, i].size, ids=self.S)
        c["report"].update(msgs=1, reals=self.G[t, i].size)
        return self.users[t, i], self.scores[t, i], self.G[t, i]


# ----------------------------------------------------------------------------
# the run
# ----------------------------------------------------------------------------
@dataclass
class DistributedRun:
    N: int
    T: int
    k: int
    tau: int
    trial: int
    seed: int
    S: int
    m: int
    n: int
    p: int
    edges: list               # backbone links (i, j), 0-based
    configs: list             # ServerConfig of every server
    records: list             # what every server sent to the recorder
    platform: Platform        # the environment, with everything it drew and sent
    timing: dict              # wall-clock seconds: startup (through day 0), data (days 1..N-1),
                              # tracking (identification, tracking, the records and the exits), total

    @property
    def X(self):
        """(T, m, n) boosts x_i(t) recorded by the servers."""
        return np.stack([r["x"] for r in self.records], axis=1)

    def stack(self, key):
        return np.stack([r[key] for r in self.records])


class RunFailed(RuntimeError):
    pass


KNOCK_ON = ("EOFError", "BrokenPipeError", "ConnectionResetError")   # a neighbor (or the platform) died


def _collect_errors(recorders, reported, grace=2.0):
    """Adds the error reports still in the recorder channels to ``reported``
    ({i: traceback}), waiting at most ``grace`` seconds in all.  Returns the
    servers whose channel is closed (their process has ended)."""
    closed, deadline = set(), time.time() + grace
    for i, c in enumerate(recorders):
        try:
            while c.poll(max(0.0, deadline - time.time())):
                kind, j, payload = c.recv()
                if kind == "error":
                    reported[j] = payload.rstrip()
        except (EOFError, OSError):
            closed.add(i)
    return closed


def failure_report(label, reported, exitcodes):
    """The servers' part of a RunFailed message, root causes first: servers
    that ended without an error report (killed, crashed, or failed before
    server_main started; a traceback, if any, is on stderr), then errors of
    their own, then knock-on errors (EOFError or a broken pipe: a neighbor
    died).  label[i] names server i, reported maps i to its traceback, and
    exitcodes[i] is its exit code (None: still running; -s: signal s)."""
    silent = ["%s %s without an error report" % (label[i], "was killed by signal %d" % -c if c < 0
                                                  else "exited with code %d" % c)
              for i, c in enumerate(exitcodes) if c not in (None, 0) and i not in reported]
    order = sorted(reported, key=lambda i: ((reported[i].splitlines() or [""])[-1].startswith(KNOCK_ON), i))
    return silent + ["%s:\n%s" % (label[i], reported[i]) for i in order]


def run_distributed(world, N, trial=0, tau=3, seed=SEED, S=SESSIONS_PER_DAY, timeout=300.0):
    """Runs trial ``trial`` of case study (B) with one process per server.

    The calling process is the platform and the recorder.  The trial's
    generator is paper_trial_rng(N, trial, seed), the sessions' generator
    rng([seed, 3, 9002, N, trial]), as in run_demo.py.  Returns a
    DistributedRun; raises RunFailed if a server fails or ``timeout``
    seconds pass without progress."""
    cs, m = world.cs, world.m
    if not isinstance(cs, ref.Recommendation):
        raise TypeError("run_distributed simulates case study (B)")
    if 2 * cs.k >= N - 1:
        raise ValueError("N too small for window length k")
    ctx = mp.get_context(START_METHOD)
    platform = Platform(world, N, paper_trial_rng(N, trial, seed),
                        np.random.default_rng([seed, CASE_ID, SESSION_STREAM, N, trial]), S)
    cfgs = server_configs(world, N, tau)

    # one duplex pipe per backbone link, one per server to the platform, one to the recorder
    peer = {i: {} for i in range(m)}
    for (a, b) in world.edges:
        peer[a][b], peer[b][a] = ctx.Pipe(duplex=True)
    plat = [ctx.Pipe(duplex=True) for _ in range(m)]          # (platform end, server end)
    rec = [ctx.Pipe(duplex=False) for _ in range(m)]          # (recorder end, server end)
    procs = [ctx.Process(target=server_main, name="server-%d-%s" % (i + 1, cfgs[i].code), daemon=True,
                         args=(cfgs[i], plat[i][1], rec[i][1], peer[i])) for i in range(m)]
    label = ["server %d (%s)" % (c.i + 1, c.code) for c in cfgs]       # the paper's numbering, in messages
    t0 = time.perf_counter()
    timing, reported = {}, {}                                  # reported: {i: traceback} of failed servers
    try:
        for proc in procs:
            proc.start()
        for i in range(m):                                    # keep only the platform's own ends
            for c in list(peer[i].values()) + [plat[i][1], rec[i][1]]:
                c.close()
        conns, recorders = [c for c, _ in plat], [c for c, _ in rec]
        try:
            for t in range(N):
                platform.open_day(t)
                pending = set(range(m))
                while pending:
                    ready = mp_wait([conns[i] for i in sorted(pending)], timeout)
                    if not ready:
                        raise RunFailed("no deployment from %s for %.0f s on day %d"
                                        % (", ".join(label[i] for i in sorted(pending)), timeout, t))
                    for c in ready:
                        i = conns.index(c)
                        try:
                            kind, day, x = c.recv()
                            if (kind, day) != ("deploy", t):
                                raise RunFailed("%s sent %s on day %d" % (label[i], (kind, day), t))
                            users, scores, g = platform.serve(i, t, x)
                            c.send(("sessions", t, users, scores))
                            c.send(("report", t, g))
                        except (EOFError, OSError):
                            raise RunFailed("%s closed its channel to the platform on day %d" % (label[i], t)) from None
                        pending.discard(i)
                if t == 0:
                    timing["startup"] = time.perf_counter() - t0
            timing["data"] = time.perf_counter() - t0 - timing["startup"]
            records, waiting = [None] * m, set(range(m))
            while waiting:
                ready = mp_wait([recorders[i] for i in sorted(waiting)], timeout)
                if not ready:
                    raise RunFailed("no record from %s for %.0f s"
                                    % (", ".join(label[i] for i in sorted(waiting)), timeout))
                for c in ready:
                    i = recorders.index(c)
                    try:
                        kind, j, payload = c.recv()
                    except (EOFError, OSError):
                        raise RunFailed("%s ended without sending its record" % label[i]) from None
                    if kind != "record":
                        reported[j] = payload.rstrip()
                        raise RunFailed("%s failed" % label[j])
                    records[j] = payload
                    waiting.discard(i)
        except (EOFError, OSError, RunFailed) as exc:
            for c in conns:                                   # servers waiting for the platform stop now
                c.close()
            for i in _collect_errors(recorders, reported):
                procs[i].join(1.0)                            # ended: collect its exit code
            report = failure_report(label, reported, [proc.exitcode for proc in procs])
            raise RunFailed("distributed run failed (%s: %s)\n%s"
                            % (type(exc).__name__, exc, "\n".join(report))) from exc
        for i, proc in enumerate(procs):
            proc.join(timeout)
            if proc.exitcode != 0:
                raise RunFailed("%s exited with code %s" % (label[i], proc.exitcode))
    finally:
        for proc in procs:
            if proc.is_alive():
                proc.terminate()
                proc.join(5)
        for c in [c for i in range(m) for c in peer[i].values()] + [c for pair in plat + rec for c in pair]:
            c.close()                                         # (closing twice is harmless)
    timing["total"] = time.perf_counter() - t0
    timing["tracking"] = timing["total"] - timing["startup"] - timing["data"]
    return DistributedRun(N=N, T=N + HORIZON, k=cs.k, tau=tau, trial=trial, seed=seed, S=S, m=m, n=cs.n,
                          p=cs.p, edges=list(world.edges), configs=cfgs, records=records, platform=platform,
                          timing=timing)


# ----------------------------------------------------------------------------
# message accounting
# ----------------------------------------------------------------------------
def link_traffic(run):
    """Per backbone link and direction: messages and reals by type, as logged
    by the sender, and whether the receiver logged the same messages."""
    rows = []
    for e, (a, b) in enumerate(run.edges):
        for i, j in ((a, b), (b, a)):
            sent = run.records[i]["links"][j]["sent"]
            got = run.records[j]["links"][i]["received"]
            row = dict(link=e + 1, src=i, dst=j)
            for kind in BACKBONE_TYPES:
                row[kind + "_msgs"] = sum(1 for msg in sent if msg[0] == kind)
                row[kind + "_reals"] = sum(msg[3] for msg in sent if msg[0] == kind)
            row["msgs"] = len(sent)
            row["reals"] = sum(msg[3] for msg in sent)
            row["received_as_sent"] = [tuple(msg) for msg in sent] == [tuple(msg) for msg in got]
            rows.append(row)
    return rows


def server_traffic(run):
    """Per server: messages and reals sent to and received from its peers, and
    the traffic on its channel to the platform (its own counters)."""
    rows = []
    for rec, cfg in zip(run.records, run.configs):
        sent = [msg for lk in rec["links"].values() for msg in lk["sent"]]
        got = [msg for lk in rec["links"].values() for msg in lk["received"]]
        pf = rec["platform"]
        rows.append(dict(i=rec["i"], degree=len(rec["links"]), neighbors=cfg.neighbors,
                         msgs_sent=len(sent), reals_sent=sum(msg[3] for msg in sent),
                         msgs_received=len(got), reals_received=sum(msg[3] for msg in got),
                         deploy_msgs=pf["deploy"].get("msgs", 0), deploy_reals=pf["deploy"].get("reals", 0),
                         session_msgs=pf["sessions"].get("msgs", 0), session_rows=pf["sessions"].get("rows", 0),
                         session_scores=pf["sessions"].get("reals", 0),
                         report_msgs=pf["report"].get("msgs", 0), report_reals=pf["report"].get("reals", 0),
                         platform_counts_agree=all(dict(run.platform.sent[rec["i"]][kd]) == pf[kd]
                                                   for kd in PLATFORM_TYPES),
                         cpu=rec["cpu"], **{"time_" + key: v for key, v in rec["timing"].items()}))
    return rows


def step_traffic(run):
    """Backbone messages and reals per step of the recursion and type (all
    links and directions, as logged by the senders): {(step, type): [msgs, reals]}."""
    out = {}
    for rec in run.records:
        for lk in rec["links"].values():
            for kind, step, _, reals in lk["sent"]:
                c = out.setdefault((step, kind), [0, 0])
                c[0] += 1
                c[1] += reals
    return out


def per_link_step(run, kinds=("gt_x", "gt_s")):
    """{(i, j, step): reals} of the given types, per directed link and step."""
    out = Counter()
    for rec in run.records:
        for j, lk in rec["links"].items():
            for kind, step, _, reals in lk["sent"]:
                if kind in kinds:
                    out[(rec["i"], j, step)] += reals
    return out


def backbone_types_seen(run):
    """Message types logged on the backbone (sent or received, every link)."""
    return sorted({msg[0] for rec in run.records for lk in rec["links"].values()
                   for side in ("sent", "received") for msg in lk[side]})


def expected_sequence(N, T, tau):
    """(type, step, round) of the messages on every link and direction, in
    order: at each step t = 0..T-2 the exchange of x_i - alpha s_i, then that
    of s_i + gamma_i(t+1) - gamma_i(t); at step N-1, between the two, the tau
    rounds of consensus on the moments."""
    seq = []
    for t in range(T - 1):
        seq.append(("gt_x", t, 0))
        if t == N - 1:
            seq += [("moments", t, r) for r in range(1, tau + 1)]
        seq.append(("gt_s", t, 0))
    return seq


def traffic_mismatches(run):
    """Where the logged traffic differs from what Algorithm 1 and the graph
    imply: on every link and direction, at both ends, the messages of
    expected_sequence with their sizes; for a server of degree d, d times that
    sent and received; on every channel to the platform (at both ends), one
    deployment, session log and gradient report per day t < N.  Returns a list
    of descriptions, empty if the traffic is as expected."""
    sizes = backbone_sizes(run.n, run.p)
    seq = [(kind, step, rnd, sizes[kind]) for kind, step, rnd in expected_sequence(run.N, run.T, run.tau)]
    reals = sum(msg[3] for msg in seq)
    nb = {i: set() for i in range(run.m)}
    for a, b in run.edges:
        nb[a].add(b)
        nb[b].add(a)
    pf = {"deploy": dict(msgs=run.N, reals=run.N * run.n),
          "sessions": dict(msgs=run.N, rows=run.N * run.S, reals=run.N * run.S * run.n, ids=run.N * run.S),
          "report": dict(msgs=run.N, reals=run.N * run.n)}
    bad = []
    for rec in run.records:
        i = rec["i"]
        if set(rec["links"]) != nb[i]:
            bad.append("server %d: links to %s, neighbors %s" % (i + 1, sorted(rec["links"]), sorted(nb[i])))
        for j, lk in rec["links"].items():
            for side in ("sent", "received"):
                if [tuple(msg) for msg in lk[side]] != seq:
                    bad.append("server %d, link to server %d: messages %s differ" % (i + 1, j + 1, side))
        if rec["platform"] != pf or {kd: dict(c) for kd, c in run.platform.sent[i].items()} != pf:
            bad.append("server %d: platform channel %s" % (i + 1, rec["platform"]))
    for r in server_traffic(run):
        d = len(nb[r["i"]])
        if (r["msgs_sent"], r["reals_sent"], r["msgs_received"], r["reals_received"]) != (d * len(seq), d * reals) * 2:
            bad.append("server %d: totals differ from degree %d x the link traffic" % (r["i"] + 1, d))
    return bad


# ----------------------------------------------------------------------------
# comparison with the in-process run
# ----------------------------------------------------------------------------
def boost_rmse(X, xstar, N):
    """Tracking RMSE over [N+50, T), as simulate.run_trial_logged (and run_trial)."""
    T = X.shape[0]
    err = np.array([np.mean(np.sum((X[t] - xstar[t]) ** 2, axis=1)) for t in range(N + RMSE_FROM, T)])
    return float(np.sqrt(np.mean(err)))


def compare(run, trial, log):
    """Max absolute differences between the distributed run and the in-process
    trial (simulate.run_trial_logged with ``log``, a SessionLog, on the same
    generators).  Returns {name: value}; the session entries are booleans or
    counts (identical sessions), the others floats."""
    key = "coop%d" % run.tau
    N, m = run.N, run.m
    A_hat, rho = trial.estimates[key]
    X = run.X
    W = world_W(run)
    M0c = ref.consensus(trial.moments["iv"][0], W, run.tau)        # as experiments.identify
    M1c = ref.consensus(trial.moments["iv"][1], W, run.tau)
    th_hat = np.stack([r["forecasts"] for r in run.records], axis=1)                  # (T-N, m, p)
    d = {}
    d["truth theta_i(t)"] = float(np.max(np.abs(run.platform.Theta - trial.Theta)))
    d["session shoppers identical"] = bool(np.array_equal(run.platform.users, log.users))
    d["session scores"] = float(np.max(np.abs(run.platform.scores - log.scores)))
    d["sessions received identical (servers)"] = int(sum(
        rec["session_digest"] == session_digest(log.users[:, i], log.scores[:, i])
        for i, rec in enumerate(run.records)))
    d["measurements ytilde_i(t)"] = float(np.max(np.abs(run.stack("y") - trial.Y_used)))
    d["gradient reports, t < N"] = float(np.max(np.abs(run.stack("reports") - trial.G_data.transpose(1, 0, 2))))
    d["window estimates theta_tilde_i"] = float(np.max(np.abs(run.stack("theta_tilde") - trial.th)))
    d["IV moments (local)"] = float(np.max(np.abs(run.stack("M_local") - np.stack(trial.moments["iv"], axis=1))))
    d["IV moments after tau rounds"] = float(np.max(np.abs(run.stack("M_consensus") - np.stack([M0c, M1c], axis=1))))
    d["A_hat_i"] = float(np.max(np.abs(run.stack("A_hat") - A_hat)))
    d["rho_raw_i"] = float(np.max(np.abs(np.array([r["rho_raw"] for r in run.records]) - rho)))
    d["forecasts theta_hat_i(t)"] = float(np.max(np.abs(th_hat - trial.forecasts[key])))
    d["boosts x_i(t), t < N"] = float(np.max(np.abs(X[:N] - trial.boosts[key][:N])))
    d["boosts x_i(t), t >= N"] = float(np.max(np.abs(X[N:] - trial.boosts[key][N:])))
    d["boosts x_i(t), all t and i"] = float(np.max(np.abs(X - trial.boosts[key])))
    d["tracking RMSE"] = abs(boost_rmse(X, trial.xstar, N) - trial.rmse[key])
    return d


def world_W(run):
    """W assembled from the servers' rows (for the comparison only)."""
    W = np.zeros((run.m, run.m))
    for cfg in run.configs:
        for j, w in cfg.weights.items():
            W[cfg.i, j] = w
    return W


def failures(diffs, m, tol=TOL):
    """Entries of compare() that fail: a difference above tol, or sessions not identical."""
    bad = []
    for name, v in diffs.items():
        if isinstance(v, (bool, np.bool_)):
            if not v:
                bad.append(name)
        elif isinstance(v, (int, np.integer)):
            if v != m:
                bad.append(name)
        elif not v <= tol:
            bad.append(name)
    return bad
