"""
Metrics of a trial, per method.

Paper metrics (as experiments.py):
    rmse        tracking RMSE of the boosts over t in [N+50, N+200)
    id          ||A_hat_i - A||_F, averaged over the servers of the trial (the
                paper's figures pool the server-trial values instead, the
                statistic run_montecarlo.py reports as id_server)
    unstable    fraction of servers whose raw estimate is not Schur stable (rho >= 1)
Product-level metrics (this demo), over the same window unless noted:
    forecast    RMSE of the interest forecasts ubar_i + theta_hat_i(t) against u_i(t),
                per genre (root mean square over days, servers and genres; rmse
                is per vector of the 3 boosts, as in the paper)
    agree       % of shoppers whose top-8 set equals the ideal one (under x*(t))
    overlap     mean overlap of the top-8 with the ideal top-8, %
    exposure    mean absolute error of the genre shares of the feed slots, in
                percentage points (4 genres incl. essentials, every region)
    excess      relative excess team cost: mean over servers of
                (F(x_i(t)) - F(x*(t))) / F(x*(t)), in parts per million
"""
import numpy as np

from .feeds import FeedEvaluator
from .simulate import RMSE_FROM

# display order and labels of the methods
METHODS = ["ideal", "oracleKF", "oracleA", "centralized", "exact", "coop3", "coop1", "pooledLS",
           "local", "persistence", "frozen", "noboost"]
LABEL = {
    "ideal": "ideal boosts x*(t)",
    "oracleKF": "oracle Kalman filter",
    "oracleA": "oracle A",
    "centralized": "centralized predictor",
    "exact": "exact averaging",
    "coop3": "cooperative (tau=3)",
    "coop1": "cooperative (tau=1)",
    "pooledLS": "pooled least squares",
    "local": "local (tau=0)",
    "persistence": "persistence (A=I)",
    "frozen": "frozen boosts",
    "noboost": "no boosts",
}
KPI_KEYS = ["rmse", "forecast", "agree", "overlap", "exposure", "excess", "id", "unstable"]


def team_cost(cs, x, u_total):
    """F(x) = sum_i f_i(x, theta_i) for x (..., n) and total interests u_total
    (..., n) = sum_i u_i(t): (sum_i lambda_i)/2 ||x||^2 + sum_l U_l softplus(-x_l)."""
    lam = float(np.sum(cs.varpi))
    return 0.5 * lam * np.sum(x * x, axis=-1) + np.sum(u_total * np.logaddexp(0.0, -x), axis=-1)


def solo_optimum(cs, u, iters=200):
    """Boosts each region would choose alone: argmin f_i(., theta_i(t)).  f_i is
    separable, and its minimizer in coordinate l is the root of
    g(x) = lambda_i x - u_il sigma(-x).  The root is unique for every u_il: g is
    increasing when u_il >= -4 lambda_i, and when u_il < -4 lambda_i (f_i is not
    convex near 0, early in a trial) g is positive for x >= 0 and concave in -x
    for x < 0.  Since |root| <= |u_il| / lambda_i, bisection on
    [-|u|/lambda - 1, |u|/lambda + 1], where g changes sign, finds it to machine
    precision.  u (T, m, n) -> (T, m, n)."""
    lam = np.broadcast_to(cs.varpi[None, :, None], u.shape)
    half = np.abs(u) / lam + 1.0
    lo, hi = -half, half.copy()                        # g(lo) < 0 <= g(hi)
    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        g = lam * mid - u * 0.5 * (1.0 - np.tanh(0.5 * mid))   # sigma(-x) = (1 - tanh(x/2)) / 2
        neg = g < 0
        lo = np.where(neg, mid, lo)
        hi = np.where(neg, hi, mid)
    return 0.5 * (lo + hi)


def window_rows(days, win):
    """Positions of the days ``win`` in the array ``days`` (any order); raises
    ValueError if one is missing."""
    pos = {int(d): k for k, d in enumerate(days)}
    missing = [int(t) for t in win if int(t) not in pos]
    if missing:
        raise ValueError("the feed evaluator must cover the RMSE window (days %d..%d; missing %d of them, first %d)"
                         % (win[0], win[-1], len(missing), missing[0]))
    return np.array([pos[int(t)] for t in win], dtype=int)


def trial_kpis(world, trial, feval=None, methods=None):
    """Metrics of every method of a trial over the paper's window.  Returns
    (kpis, daily): kpis[method][key], and daily[method] = feval.evaluate(boosts),
    the per-day feed metrics on the evaluator's days feval.days (all days
    0..T-1 for the default evaluator).  The evaluator must cover the window
    N+50..T-1; FeedEvaluator(world, trial.xstar, trial.window) is the fastest."""
    cs = world.cs
    N, T = trial.N, trial.T
    win = np.arange(N + RMSE_FROM, T)
    if feval is None:
        feval = FeedEvaluator(world, trial.xstar, np.arange(T))
    methods = [mm for mm in (methods or METHODS) if mm == "ideal" or mm in trial.boosts]
    sel = window_rows(feval.days, win)

    u_tot = trial.u.sum(axis=1)                                          # (T, n)
    F_star = team_cost(cs, trial.xstar, u_tot)                           # (T,)
    out, daily = {}, {}
    for mm in methods:
        X = np.repeat(trial.xstar[:, None, :], cs.m, axis=1) if mm == "ideal" else trial.boosts[mm]
        r = {}
        if mm == "ideal":
            r["rmse"] = 0.0
        else:
            r["rmse"] = trial.rmse[mm]
        if mm in trial.forecasts:
            err = trial.forecasts[mm][win - N] - trial.Theta[win]
            r["forecast"] = float(np.sqrt(np.mean(err ** 2)))
        elif mm == "ideal":
            r["forecast"] = 0.0
        else:
            r["forecast"] = np.nan
        d = feval.evaluate(X)
        daily[mm] = d
        r["agree"] = 100.0 * float(d["agree"][sel].mean())
        r["overlap"] = 100.0 * float(d["overlap"][sel].mean())
        r["exposure"] = 100.0 * float(np.abs(d["share"][sel] - feval.share_ideal[sel]).mean())
        F = team_cost(cs, X[win], u_tot[win][:, None, :])                 # (W, m)
        r["excess"] = 1e6 * float(np.mean((F - F_star[win][:, None]) / F_star[win][:, None]))
        if mm in trial.id:
            r["id"] = float(np.mean(trial.id[mm]))
            r["unstable"] = trial.unstable[mm]
        else:
            r["id"], r["unstable"] = np.nan, np.nan
        out[mm] = r
    return out, daily


def region_kpis(world, trial, daily, methods=("coop3", "local", "persistence", "frozen"), days=None):
    """Per-region metrics over the paper's window: rows (method, region, ...).
    ``daily`` is the second output of trial_kpis; ``days`` are the evaluator's
    days (feval.days).  Left out, they are inferred from the length of the daily
    arrays: all days 0..T-1, or the window N+50..T-1."""
    N, T = trial.N, trial.T
    win = np.arange(N + RMSE_FROM, T)
    rows = []
    for mm in methods:
        if mm not in trial.boosts:
            continue
        d = daily[mm]
        D = d["agree"].shape[0]
        if days is not None:
            sel = window_rows(days, win)
        elif D == T:
            sel = win
        elif D == len(win):
            sel = np.arange(len(win))
        else:
            raise ValueError("cannot tell the days of the daily metrics (%d rows): pass days=feval.days" % D)
        for i in range(world.m):
            err_x = trial.boosts[mm][win, i] - trial.xstar[win]
            row = dict(method=mm, region=world.regions[i]["code"],
                       boost_rmse=float(np.sqrt(np.mean(np.sum(err_x ** 2, axis=1)))),
                       agree=100.0 * float(d["agree"][sel, i].mean()),
                       overlap=100.0 * float(d["overlap"][sel, i].mean()))
            if mm in trial.forecasts:
                e = trial.forecasts[mm][win - N, i] - trial.Theta[win, i]
                row["forecast"] = float(np.sqrt(np.mean(e ** 2)))
            else:
                row["forecast"] = np.nan
            row["id"] = float(trial.id[mm][i]) if mm in trial.id else np.nan
            rows.append(row)
    return rows
