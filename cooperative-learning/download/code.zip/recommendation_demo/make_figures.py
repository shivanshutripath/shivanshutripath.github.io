#!/usr/bin/env python3
"""
make_figures.py -- the figures of the showcase run of case study (B).

    python3 make_figures.py                                   # output/ -> output/figures/
    python3 make_figures.py --src output_N50 --out output_N50/figures
    python3 make_figures.py --only boosts feeds               # some of the figures

Reads only what run_demo.py wrote to <src> (data/*.csv, kpis.csv,
kpis_by_region.csv, run_config.json) and, when it exists,
<src>/montecarlo/mc_summary.csv; it never simulates.  Writes every figure as
PNG (200 dpi) and PDF to <out>, and one caption line per figure, with the
numbers the figure supports, to <out>/captions.txt:

  fig_network          the eight regional servers on the backbone (ring and
                       chords) with their known average interests ubar_i
  fig_interests        true interests u_i(t) of the eight regions, per genre
  fig_reconstruction   drift theta_{i,l}(t), its window reconstruction
                       (t <= N-k) and its cooperative and local forecasts
                       (t >= N): region 1, genre 1 (the paper's Figure 3(b),
                       top) and the region whose local forecast is worst
  fig_boosts           boosts x_i(t) of the eight servers (cooperative) and
                       x*(t); the tracking phase of four methods (network average)
  fig_identification   ||A_hat_i - A||_F per server: local, tau = 1, tau = 3,
                       exact averaging; raw local estimates that are not
                       Schur stable are hatched
  fig_feeds            shoppers whose top-8 is the ideal top-8, per day and
                       method; genre shares of the ideal feeds of two regions
  fig_example_feed     the feeds of the typical shopper of three regions
  fig_montecarlo       medians and interquartile ranges versus N (only when
                       <src>/montecarlo/mc_summary.csv exists)

Colors: the methods keep the colors of the paper (main.tex); the genres have
their own colorblind-safe palette, and the regions (fig_interests only) a
third one.  Only numpy and matplotlib are required.
"""
import argparse
import csv
import json
import os
import re
import sys
import textwrap
from functools import cached_property

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt                                                # noqa: E402
from matplotlib import font_manager                                            # noqa: E402
from matplotlib.lines import Line2D                                            # noqa: E402
from matplotlib.patches import FancyBboxPatch, Patch, Rectangle                # noqa: E402
from matplotlib.ticker import (FixedLocator, FuncFormatter, LogLocator,        # noqa: E402
                               NullFormatter, NullLocator)
from matplotlib.transforms import blended_transform_factory                   # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from rcdemo.kpi import LABEL                                                   # noqa: E402
from rcdemo.world import BOOSTED, GENRE_KEYS, GENRES                           # noqa: E402

GK = GENRE_KEYS[:BOOSTED]                    # outdoor, home, tech (the boosted genres)
FIGURES = ["network", "interests", "reconstruction", "boosts", "identification", "feeds",
           "example_feed", "montecarlo"]
RHO_MAX = 0.999                              # safeguard of experiments.identify (rho_max)
# the trial of the paper's Figure 3(b) (rcdemo.paper.SEED; run_demo.py's defaults)
PAPER_FIG3B = dict(seed=2026, N=100, trial=0)

# ----------------------------------------------------------------------------
# colors and styles
# ----------------------------------------------------------------------------
# methods: the paper's colors (main.tex); "frozen" and "coop1" are not in the paper
C_COOP, C_LOCAL, C_PERS, C_CENT = "#0072B2", "#D55E00", "#6E6E6E", "#009E73"
C_ORACLE, C_POOLED, C_EXACT, C_AMBER = "#000000", "#CC79A7", "#56B4E9", "#E69F00"
C_COOP1, C_FROZEN = "#003C66", "#882255"
STYLE = {
    "coop3": dict(color=C_COOP, ls="-", marker="o"),
    "coop1": dict(color=C_COOP1, ls="-", marker="o"),
    "exact": dict(color=C_EXACT, ls=(0, (5, 2)), marker="o"),
    "local": dict(color=C_LOCAL, ls=(0, (4, 1.6)), marker="^"),
    "persistence": dict(color=C_PERS, ls=(0, (1, 1.3)), marker="s"),
    "frozen": dict(color=C_FROZEN, ls=(0, (8, 2.5)), marker="D"),
    "oracleA": dict(color=C_ORACLE, ls=(0, (5, 1.5, 1, 1.5)), marker="x"),
    "oracleKF": dict(color=C_ORACLE, ls=(0, (2, 1)), marker="+"),
    "centralized": dict(color=C_CENT, ls=(0, (5, 2)), marker="d"),
    "pooledLS": dict(color=C_POOLED, ls=(0, (3, 1.5)), marker="x"),
}
SHORT = {"coop3": "cooperative", "coop1": "cooperative, tau=1", "local": "local", "persistence": "persistence",
         "frozen": "frozen", "oracleA": "oracle A", "exact": "exact averaging", "noboost": "no boosts",
         "ideal": "ideal"}
# genres: green, rose, violet, khaki -- validated colorblind-safe for all pairs
# (dataviz validator: worst protan/deutan dE 9.9, normal-vision dE 21.4)
GENRE_COLOR = ["#228833", "#CC6677", "#5E4FA2", "#C9B458"]
# regions (fig_interests): the 8-slot categorical palette of the dataviz reference
REGION_COLOR = ["#2A78D6", "#EB6834", "#1BAF7A", "#EDA100", "#E87BA4", "#008300", "#6250D6", "#E34948"]
INK, INK2, MUTED = "#111111", "#4D4D4D", "#8A8A8A"
SHADE = "#EDEDED"                            # data-collection phase (the paper: black at 6%)
GRID = "#E3E3E3"
NDASH, MINUS = "\u2013", "\u2212"


def setup_style():
    narrow = "Arial Narrow" if has_font("Arial Narrow") else None
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
        "mathtext.fontset": "custom", "mathtext.rm": "Arial", "mathtext.it": "Arial:italic",
        "mathtext.bf": "Arial:bold", "mathtext.sf": "Arial", "mathtext.fallback": "stixsans",
        "font.size": 8, "axes.titlesize": 8.5, "axes.labelsize": 8, "legend.fontsize": 7.5,
        "xtick.labelsize": 7.5, "ytick.labelsize": 7.5,
        "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": 0.6,
        "axes.edgecolor": "#333333", "axes.labelcolor": INK, "text.color": INK,
        "xtick.color": "#333333", "ytick.color": "#333333",
        "xtick.major.width": 0.6, "ytick.major.width": 0.6, "xtick.major.size": 2.8, "ytick.major.size": 2.8,
        "xtick.minor.size": 1.6, "ytick.minor.size": 1.6, "xtick.minor.width": 0.5, "ytick.minor.width": 0.5,
        "axes.titlelocation": "left", "axes.titlepad": 4.0,
        "legend.frameon": False, "legend.handlelength": 2.4, "legend.columnspacing": 1.4,
        "lines.linewidth": 1.2, "hatch.linewidth": 0.8, "hatch.color": "white",
        "pdf.fonttype": 42, "ps.fonttype": 42,
        "figure.dpi": 100, "savefig.dpi": 200,
    })
    return narrow


def has_font(name):
    try:
        font_manager.findfont(font_manager.FontProperties(family=name), fallback_to_default=False)
        return True
    except ValueError:
        return False


def label(mm):
    """Display label of a method (rcdemo.kpi.LABEL with math)."""
    s = LABEL.get(mm, mm)
    return (s.replace("tau=", r"$\tau$ = ").replace("A=I", "A = I").replace("x*(t)", r"$x^\star(t)$"))


def short(mm):
    return SHORT.get(mm, mm).replace("tau=", r"$\tau$ = ")


def days(a, b):
    return "days %d%s%d" % (a, NDASH, b)


def signed(v):
    return ("+%.2f" % v) if v >= 0 else (MINUS + "%.2f" % -v)


def tint(color, f):
    """color mixed with white, f = fraction of white."""
    r, g, b = matplotlib.colors.to_rgb(color)
    return (r + (1 - r) * f, g + (1 - g) * f, b + (1 - b) * f)


def luminance(color):
    """Relative luminance (WCAG) of a color."""
    c = np.array(matplotlib.colors.to_rgb(color))
    c = np.where(c <= 0.03928, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)
    return float(0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2])


def rowmajor(items, ncol):
    """Reorder legend entries so that matplotlib's column-major legend reads row by row."""
    nrow = -(-len(items) // ncol)
    return [items[r * ncol + c] for c in range(ncol) for r in range(nrow) if r * ncol + c < len(items)]


# ----------------------------------------------------------------------------
# the data of one run
# ----------------------------------------------------------------------------
def read_columns(path, strict=True):
    """CSV file -> {column: array}; numeric columns as float (empty = nan).
    strict=False drops rows with the wrong number of fields (a file that is
    still being written) instead of failing."""
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    if not rows:
        raise ValueError("empty file")
    header, body = rows[0], rows[1:]
    if not strict:
        body = [r for r in body if len(r) == len(header)]
    cols = {}
    for k, h in enumerate(header):
        vals = [r[k] for r in body]
        try:
            cols[h] = np.array([float(v) if v != "" else np.nan for v in vals])
        except ValueError:
            cols[h] = np.array(vals, dtype=object)
    return cols


class Run:
    """The CSV files that run_demo.py wrote to ``src`` (each read on first use).

    Arrays are indexed [day, region, genre] with regions in the order of the
    servers 1..m (regions.csv) and days 0..T-1 (nan where a quantity is not
    defined, e.g. forecasts before day N)."""

    def __init__(self, src):
        self.src, self.ddir = src, os.path.join(src, "data")
        with open(os.path.join(src, "run_config.json")) as f:
            self.cfg = json.load(f)
        self.N, self.T, self.k = int(self.cfg["N"]), int(self.cfg["T"]), int(self.cfg["k"])
        w0, w1 = self.cfg["rmse_window"]
        self.win = np.arange(int(w0), int(w1) + 1)               # the paper's window [N+50, T)
        reg = read_columns(self.path("regions.csv"))
        self.codes = [str(c) for c in reg["code"]]
        self.m = len(self.codes)
        self.ridx = {c: i for i, c in enumerate(self.codes)}
        self.names = [str(c) for c in reg["region"]]
        self.hubs = [str(c) for c in reg["data_center"]]
        self.ubar = np.stack([reg["ubar_" + g] for g in GK], axis=1)       # (m, 3)
        self.w_self = reg["W_self"]

    def path(self, name):
        return os.path.join(self.ddir, name)

    def tag(self, i):
        return "%d %s" % (i + 1, self.codes[i])

    def _grid(self, c, keys, sel=None):
        day = c["day"].astype(int)
        reg = np.array([self.ridx[r] for r in c["region"]])
        vals = np.stack([c[k] for k in keys], axis=-1)
        if sel is not None:
            day, reg, vals = day[sel], reg[sel], vals[sel]
        out = np.full((self.T, self.m, len(keys)), np.nan)
        out[day, reg] = vals
        return out

    def _by_method(self, c, keys):
        meth = c["method"]
        return {mm: self._grid(c, keys, sel=(meth == mm)) for mm in dict.fromkeys(meth)}

    @cached_property
    def theta(self):
        return self._grid(read_columns(self.path("interests.csv")), ["theta_" + g for g in GK])

    @cached_property
    def u(self):
        return self.ubar[None] + self.theta

    @cached_property
    def xstar(self):
        c = read_columns(self.path("optimum.csv"))
        x = np.full((self.T, BOOSTED), np.nan)
        x[c["day"].astype(int)] = np.stack([c["xstar_" + g] for g in GK], axis=1)
        return x

    @cached_property
    def theta_tilde(self):
        return self._grid(read_columns(self.path("window_estimates.csv")), ["theta_tilde_" + g for g in GK])

    @cached_property
    def u_hat(self):
        """Daily average net engagement of the exploration sessions (t < N)."""
        return self._grid(read_columns(self.path("daily_reports.csv")), ["uhat_" + g for g in GK])

    @cached_property
    def forecasts(self):
        return self._by_method(read_columns(self.path("forecasts.csv")), ["theta_hat_" + g for g in GK])

    @cached_property
    def boosts(self):
        return self._by_method(read_columns(self.path("boosts.csv")), ["x_" + g for g in GK])

    @cached_property
    def feed_daily(self):
        """method -> agree (T, m), share (T, m, 4); 'ideal' -> the ideal shares."""
        c = read_columns(self.path("feed_daily.csv"))
        agree = self._by_method(c, ["agree"])
        share = self._by_method(c, ["share_" + g for g in GENRE_KEYS])
        return {mm: dict(agree=agree[mm][..., 0], share=share[mm]) for mm in agree}

    @cached_property
    def identification(self):
        """method -> err (m,), rho (m,)  (rho = spectral radius of the raw estimate)."""
        c = read_columns(self.path("identification.csv"))
        out = {}
        for mm in dict.fromkeys(c["method"]):
            sel = c["method"] == mm
            idx = np.array([self.ridx[r] for r in c["region"][sel]])
            err, rho = np.full(self.m, np.nan), np.full(self.m, np.nan)
            err[idx], rho[idx] = c["error_F"][sel], c["rho_raw"][sel]
            out[mm] = dict(err=err, rho=rho)
        return out

    @cached_property
    def links(self):
        """Backbone links (i, j, kind, weight), 0-based."""
        c = read_columns(self.path("backbone.csv"))
        return [(self.ridx[a], self.ridx[b], str(kd), float(w))
                for a, b, kd, w in zip(c["from"], c["to"], c["kind"], c["weight"])]

    @cached_property
    def kpis(self):
        c = read_columns(os.path.join(self.src, "kpis.csv"))
        keys = [k for k in c if k not in ("method", "label")]
        return {str(mm): {k: float(c[k][r]) for k in keys} for r, mm in enumerate(c["method"])}

    @cached_property
    def kpis_region(self):
        c = read_columns(os.path.join(self.src, "kpis_by_region.csv"))
        return [{k: (str(v[r]) if v.dtype == object else float(v[r])) for k, v in c.items()}
                for r in range(len(c["method"]))]

    @cached_property
    def example_feeds(self):
        """(region code, day, method) -> dict(shopper, items [(rank, pid, name, genre index)], x (3,))."""
        c = read_columns(self.path("example_feeds.csv"))
        gidx = {g: k for k, g in enumerate(GENRES)}
        out = {}
        for r in range(len(c["region"])):
            key = (str(c["region"][r]), int(c["day"][r]), str(c["method"][r]))
            d = out.setdefault(key, dict(shopper=str(c["shopper"][r]), items=[],
                                         x=np.array([c["x_" + g][r] for g in GK])))
            d["items"].append((int(c["rank"][r]), str(c["product"][r]), str(c["name"][r]), gidx[str(c["genre"][r])]))
        for d in out.values():
            d["items"].sort()
        return out

    def shopper_affinity(self, uids):
        c = read_columns(self.path("shoppers.csv"))
        pos = {str(s): r for r, s in enumerate(c["shopper"])}
        return {s: np.array([c["affinity_" + g][pos[s]] for g in GK]) for s in uids}


# ----------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------
def save(fig, out, name):
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(out, "%s.%s" % (name, ext)), bbox_inches="tight", pad_inches=0.04,
                    facecolor="white")
    plt.close(fig)


def phases(ax, N, T, t0=0, labels=False, fontsize=6.8, y=0.985, after="no data: forecast"):
    """Shade the data-collection phase [t0, N), mark t = N, optionally name the
    phases (``after`` names the phase t >= N)."""
    ax.axvspan(t0, N, color=SHADE, lw=0, zorder=0)
    ax.axvline(N, color="#7A7A7A", lw=0.7, ls=(0, (3, 2)), zorder=1)
    if labels:
        tr = blended_transform_factory(ax.transData, ax.transAxes)
        ax.text((t0 + N) / 2, y, "data collection", transform=tr, ha="center", va="top", fontsize=fontsize,
                color=INK2, zorder=6)
        ax.text((N + T) / 2, y, after, transform=tr, ha="center", va="top", fontsize=fontsize,
                color=INK2, zorder=6)


def ygrid(ax, x1=None):
    """Horizontal hairline grid at the y ticks (up to x = x1 if given)."""
    if x1 is None:
        ax.grid(axis="y", color=GRID, lw=0.5, zorder=0)
        ax.set_axisbelow(True)
        return
    y0, y1 = ax.get_ylim()
    for y in ax.get_yticks():
        if min(y0, y1) <= y <= max(y0, y1):
            ax.plot([ax.get_xlim()[0], x1], [y, y], color=GRID, lw=0.5, zorder=0.5)


def day_axis(ax, T, extra=0):
    ax.set_xlim(0, T + extra)
    ax.xaxis.set_major_locator(FixedLocator(np.arange(0, T + 1, 50)))
    if extra:
        ax.spines["bottom"].set_bounds(0, T)


def log_ticks(ax):
    """Readable ticks (1, 2, 5 x 10^k, plain numbers) on a log y axis."""
    lo, hi = ax.get_ylim()
    for mult in [(1, 2, 5), (1, 1.5, 2, 3, 5, 7)]:
        ticks = [mu * 10.0 ** e for e in range(-5, 4) for mu in mult if lo <= mu * 10.0 ** e <= hi]
        if len(ticks) >= 3:
            break
    ax.yaxis.set_major_locator(FixedLocator(ticks))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: "%g" % v))
    ax.yaxis.set_minor_locator(LogLocator(subs=np.arange(2, 10)))
    ax.yaxis.set_minor_formatter(NullFormatter())


def spread(y, gap, lo=-np.inf, hi=np.inf):
    """Label positions closest (least squares) to the targets y whose sorted
    gaps are at least ``gap``, kept inside [lo, hi]; same order as y."""
    y = np.asarray(y, float)
    order = np.argsort(y)
    ys = y[order]

    def place(b):
        return np.mean(ys[b]) + gap * (np.arange(len(b)) - (len(b) - 1) / 2.0)

    blocks = [[k] for k in range(len(ys))]
    pos = [place(b) for b in blocks]
    merged = True
    while merged:
        merged = False
        for j in range(len(blocks) - 1):
            if pos[j][-1] + gap > pos[j + 1][0] + 1e-12:
                blocks[j] = blocks[j] + blocks[j + 1]
                del blocks[j + 1], pos[j + 1]
                pos[j] = place(blocks[j])
                merged = True
                break
    p = np.concatenate(pos)
    if p[-1] > hi:
        p -= p[-1] - hi
    if p[0] < lo:
        p += lo - p[0]
    out = np.empty_like(p)
    out[order] = p
    return out


def data_per_point(ax):
    """y data units per typographic point in ax (the figure must be laid out)."""
    fig = ax.figure
    fig.canvas.draw()
    h_in = ax.get_window_extent().height / fig.dpi
    y0, y1 = ax.get_ylim()
    return (y1 - y0) / (72.0 * h_in)


def end_labels(ax, x_end, x_text, ys, texts, colors, fontsize=6.4, mark="dot"):
    """Direct labels right of the data, spread apart, each with a thin leader
    that starts after a gap (so that it does not read as data).

    mark="dot": ys are the last values of the lines; a dot marks each end.
    mark="tick": ys are summary levels (e.g. means); a short horizontal tick
    right of the data marks each level."""
    dpp = data_per_point(ax)
    y0, y1 = ax.get_ylim()
    pos = spread(ys, 1.12 * fontsize * dpp, lo=y0 + 0.6 * fontsize * dpp, hi=y1 - 0.6 * fontsize * dpp)
    d = x_text - x_end
    for y, p, s, c in zip(ys, pos, texts, colors):
        if mark == "dot":
            ax.plot([x_end], [y], marker="o", ms=2.6, color=c, mec="white", mew=0.4, zorder=6, clip_on=False)
            x_start = x_end + 0.18 * d
        else:
            ax.plot([x_end + 0.10 * d, x_end + 0.42 * d], [y, y], color=c, lw=1.8, solid_capstyle="butt",
                    zorder=6, clip_on=False)
            x_start = x_end + 0.48 * d
        ax.plot([x_start, x_text - 0.10 * d], [y, p], color=c, lw=0.55, zorder=4, clip_on=False)
        ax.text(x_text, p, s, color=INK, fontsize=fontsize, va="center", ha="left", zorder=5)


def rmse(a, axis=None):
    return float(np.sqrt(np.nanmean(np.asarray(a) ** 2, axis=axis)))


def text_width(fig, s, size, weight="normal", family=None):
    """Width (inches) of the string s rendered in the figure's sans-serif font."""
    prop = font_manager.FontProperties(family=family or plt.rcParams["font.sans-serif"][0], size=size,
                                       weight=weight)
    w, _, _ = fig.canvas.get_renderer().get_text_width_height_descent(s, prop, ismath=False)
    return w / fig.dpi


# ----------------------------------------------------------------------------
# 1. network
# ----------------------------------------------------------------------------
def fig_network(run, out):
    """The eight servers on the backbone, laid out as the paper's Figure 3(a):
    a ring with server 1 at the right, numbered counter-clockwise."""
    m, ubar = run.m, run.ubar
    W = np.diag(run.w_self.astype(float))
    for i, j, _, w in run.links:
        W[i, j] = W[j, i] = w
    sigma = float(np.linalg.norm(W - np.ones((m, m)) / m, 2))
    weights = sorted({w for *_, w in run.links})
    wtxt = ("Metropolis weight %g per link" % weights[0]) if len(weights) == 1 else \
        ("Metropolis weights %g%s%g" % (weights[0], NDASH, weights[-1]))
    chords = [(i, j) for i, j, kd, _ in run.links if kd == "chord"]

    R, cw, ch = 2.05, 1.24, 0.80                      # ring radius, card width / height (data units)
    ang = np.deg2rad(22.5 + 360.0 / m * np.arange(m))
    P = R * np.stack([np.cos(ang), np.sin(ang)], axis=1)
    xl, yl = 2.72, 2.42
    unit = 1.15                                       # inches per data unit
    fig = plt.figure(figsize=(2 * xl * unit, 2 * yl * unit + 1.05))
    H = fig.get_figheight()
    ax = fig.add_axes([0, 0.62 / H, 1, 2 * yl * unit / H])
    ax.set_xlim(-xl, xl)
    ax.set_ylim(-yl, yl)
    ax.set_aspect("equal")
    ax.axis("off")

    for i, j, kd, _ in run.links:
        if kd == "chord":
            ax.plot(*P[[i, j]].T, color="#5A5A5A", lw=1.3, ls=(0, (5, 3)), zorder=1, solid_capstyle="butt")
        else:
            ax.plot(*P[[i, j]].T, color="#3A3A3A", lw=2.0, zorder=1, solid_capstyle="butt")

    vmax = max(3.0, float(np.ceil(np.max(ubar))))     # full bar (net-engagement units): no bar is clipped
    for i in range(m):
        x0, y1 = P[i, 0] - cw / 2, P[i, 1] + ch / 2
        ax.add_patch(FancyBboxPatch((x0, y1 - ch), cw, ch, boxstyle="round,pad=0,rounding_size=0.06",
                                    fc="white", ec="#9C6B00", lw=0.9, zorder=3))
        bs = 0.22                                     # server badge (the paper's amber server icon)
        ax.add_patch(FancyBboxPatch((x0 + 0.06, y1 - 0.06 - bs), bs, bs, boxstyle="round,pad=0,rounding_size=0.04",
                                    fc=C_AMBER, ec="#9C6B00", lw=0.7, zorder=4))
        ax.text(x0 + 0.06 + bs / 2, y1 - 0.06 - bs / 2, str(i + 1), ha="center", va="center", fontsize=8,
                fontweight="bold", color=INK, zorder=5)
        # header: code (bold) and data-center city, shrunk if it would overrun the card
        room = (cw - 0.36 - 0.07) * unit
        for size in (7.6, 7.3, 7.0, 6.7, 6.4):
            w_code = text_width(fig, run.codes[i] + " ", size, "bold")
            if w_code + text_width(fig, run.hubs[i], size - 0.3) <= room:
                break
        ax.text(x0 + 0.36, y1 - 0.115, run.codes[i], ha="left", va="center", fontsize=size, fontweight="bold",
                color=INK, zorder=5)
        ax.text(x0 + 0.36 + w_code / unit, y1 - 0.115, run.hubs[i], ha="left", va="center", fontsize=size - 0.3,
                color=INK, zorder=5)
        ax.text(x0 + 0.36, y1 - 0.245, run.names[i], ha="left", va="center", fontsize=6.4, color=INK2, zorder=5)
        L, bh = 0.66, 0.085
        for l in range(BOOSTED):
            yc = y1 - 0.40 - 0.125 * l
            ax.add_patch(Rectangle((x0 + 0.08, yc - bh / 2), L, bh, fc="#EEEEEE", ec="none", zorder=4))
            ax.add_patch(Rectangle((x0 + 0.08, yc - bh / 2), L * min(ubar[i, l], vmax) / vmax, bh,
                                   fc=GENRE_COLOR[l], ec="none", zorder=5))
            ax.text(x0 + 0.08 + L + 0.04, yc, "%.2f" % ubar[i, l], ha="left", va="center", fontsize=6.3,
                    color=INK, zorder=5)

    fig.text(0.5, 1 - 0.12 / H, "Regional servers and backbone links", ha="center", va="top", fontsize=10,
             fontweight="bold")
    ctext = " and ".join("%d%s%d" % (a + 1, NDASH, b + 1) for a, b in chords)
    fig.text(0.5, 1 - 0.36 / H, "ring 1%s2%s\u2026%s%d%s1 with the chords %s; %s; contraction factor $\\sigma$ = %.2f"
             % (NDASH, NDASH, NDASH, m, NDASH, ctext, wtxt, sigma), ha="center", va="top", fontsize=7.4, color=INK2)
    handles = [Patch(fc=GENRE_COLOR[l], ec="none", label=GENRES[l]) for l in range(BOOSTED)]
    handles += [Line2D([], [], color="#3A3A3A", lw=2.0, label="ring link"),
                Line2D([], [], color="#5A5A5A", lw=1.3, ls=(0, (5, 3)), label="chord")]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5, 0.20 / H), ncol=5, fontsize=7.4,
               handlelength=2.0, columnspacing=1.3)
    fig.text(0.5, 0.10 / H, r"bars: known average interest $\bar u_{i,\ell}$ of the region's shoppers per genre"
             r" (net-engagement units; grey track = %g)" % vmax, ha="center", va="bottom", fontsize=7, color=INK2)
    save(fig, out, "fig_network")
    k_hi = np.argmax(ubar, axis=0)
    return ("fig_network: the %d regional servers on a ring with chords %s (%d links, Metropolis weights, "
            "sigma = %.3f), each with its data center and known average interests ubar_i; highest ubar per "
            "genre: %s" % (m, ctext.replace(NDASH, "-"), len(run.links), sigma,
                           ", ".join("%s %s %.2f" % (GENRES[l], run.codes[k_hi[l]], ubar[k_hi[l], l])
                                     for l in range(BOOSTED))))


# ----------------------------------------------------------------------------
# 2. interests
# ----------------------------------------------------------------------------
GENRE_STORY = [
    "damped seasonal cycle, period about 25 days",
    "the same cycle, a quarter period apart",
    "fading hype: the deviation from the average decays 5% a day",
]


def fig_interests(run, out):
    u, N, T, m = run.u, run.N, run.T, run.m
    t = np.arange(T)
    fig, axes = plt.subplots(BOOSTED, 1, figsize=(7.0, 6.9), sharex=True, layout="constrained")
    lo, hi = np.nanmin(u), np.nanmax(u)
    pad = 0.04 * (hi - lo)
    extra = 30
    for l, ax in enumerate(axes):
        phases(ax, N, T, labels=(l == 0), after="tracking phase: no data")    # the curves are true interests
        for i in range(m):
            ax.plot(t, u[:, i, l], color=REGION_COLOR[i], lw=0.85, label=run.tag(i), zorder=3)
        day_axis(ax, T, extra)
        ax.set_ylim(lo - pad, hi + 3.5 * pad)
        ax.set_ylabel(r"interest $u_{i,%d}(t)$" % (l + 1) + "\n(net-engagement units)")
        ax.set_title("%s (genre %d): %s" % (GENRES[l], l + 1, GENRE_STORY[l]) if l < len(GENRE_STORY)
                     else GENRES[l])
    axes[-1].set_xlabel("day $t$")
    handles = [Line2D([], [], color=REGION_COLOR[i], lw=1.4) for i in range(m)]
    labels = ["%s %s" % (run.tag(i), run.hubs[i]) for i in range(m)]
    fig.legend(rowmajor(handles, 4), rowmajor(labels, 4), loc="outside upper center", ncol=4, fontsize=7.2,
               handlelength=1.6, columnspacing=1.6)
    for l, ax in enumerate(axes):
        ygrid(ax, x1=T)
        end_labels(ax, T - 1, T + 10, u[T - 1, :, l], run.codes, REGION_COLOR)
    save(fig, out, "fig_interests")
    w = run.win
    spread0 = np.ptp(u[0], axis=0)
    spreadw = np.mean(np.ptp(u[w], axis=1), axis=0)
    return ("fig_interests: true interests u_i(t) of the %d regions; on day 0 they range over %.2f..%.2f, the "
            "cycle of genres 1-2 and the tech hype die out, and over %s every region stays near its own ubar_i "
            "(across-region spread per genre %s, against %s on day 0)"
            % (m, np.nanmin(u[0]), np.nanmax(u[0]), days(w[0], w[-1]).replace(NDASH, "-"),
               " ".join("%.2f" % v for v in spreadw), " ".join("%.2f" % v for v in spread0)))


# ----------------------------------------------------------------------------
# 3. reconstruction and forecasts
# ----------------------------------------------------------------------------
def worst_local_forecast(run):
    """(region, genre) of the worst local forecast: the region from
    kpis_by_region.csv, its genre with the largest forecast RMSE over the window."""
    rows = [r for r in run.kpis_region if r["method"] == "local" and np.isfinite(r["forecast"])]
    rows.sort(key=lambda r: -r["forecast"])
    for r in rows:
        i = run.ridx[r["region"]]
        e = run.forecasts["local"][run.win, i] - run.theta[run.win, i]
        l = int(np.argmax(np.sqrt(np.mean(e ** 2, axis=0))))
        if (i, l) != (0, 0):
            return i, l, r["forecast"]
    return None


def fig_reconstruction(run, out):
    th, tt, N, T, k = run.theta, run.theta_tilde, run.N, run.T, run.k
    fc = run.forecasts
    meas = run.u_hat - run.ubar[None]                    # daily measurement from the sessions, t < N
    has_meas = bool(np.any(np.isfinite(meas)))           # False for a run without session logs (--no-sessions)
    n_sess = int(run.cfg.get("sessions_per_day") or 0)
    meas_label = (r"daily measurement $\hat u_{i,\ell}(t)-\bar u_{i,\ell}$"
                  + (" (%d sessions)" % n_sess if n_sess else ""))
    paper_trial = (all(run.cfg.get(key) == v for key, v in PAPER_FIG3B.items())
                   and bool(run.cfg.get("same_trial", False)))
    cases = [(0, 0, None)]
    wl = worst_local_forecast(run)
    if wl is not None:
        cases.append(wl)
    t = np.arange(T)
    tf = np.arange(N, T)
    z0 = max(N - 10, 0)
    w0, w1 = run.win[0], run.win[-1]
    fig = plt.figure(figsize=(7.2, 2.35 * len(cases) + 0.55), layout="constrained")
    gs = fig.add_gridspec(len(cases), 2, width_ratios=[1.65, 1])
    rho_local = run.identification.get("local", {}).get("rho")
    texts = []
    footnote = None
    for row, (i, l, _) in enumerate(cases):
        r_c = rmse(fc["coop3"][run.win, i, l] - th[run.win, i, l])
        r_l = rmse(fc["local"][run.win, i, l] - th[run.win, i, l])
        texts.append((i, l, r_c, r_l))
        for col in range(2):
            ax = fig.add_subplot(gs[row, col])
            t0 = 0 if col == 0 else z0
            phases(ax, N, T, t0=t0, labels=(row == 0 and col == 0))
            sl = slice(t0, T)
            ax.plot(t[sl], th[sl, i, l], color="black", lw=0.85, zorder=3, label=r"true drift $\theta_{i,\ell}(t)$")
            ok = np.isfinite(meas[:, i, l]) & (t >= t0)
            if has_meas:
                ax.plot(t[ok], meas[ok, i, l], ls="none", marker="o", ms=1.7, mfc="none", mec="#A8A8A8", mew=0.5,
                        zorder=2, label=meas_label)
            okw = np.isfinite(tt[:, i, l]) & (t >= t0)
            ax.plot(t[okw], tt[okw, i, l], ls="none", marker="o", ms=2.3, color=C_AMBER, mec="none", zorder=4,
                    label=r"window reconstruction $\tilde\theta_{i,\ell}(t)$, $t \leq N-k$")
            ax.plot(tf, fc["coop3"][N:, i, l], color=C_COOP, lw=1.5, zorder=5, label="forecast, " + label("coop3"))
            ax.plot(tf, fc["local"][N:, i, l], color=C_LOCAL, lw=1.3, ls=STYLE["local"]["ls"], zorder=6,
                    label="forecast, " + label("local"))
            if col == 0:
                day_axis(ax, T)
                vals = np.concatenate([th[:, i, l], tt[:, i, l], meas[:, i, l], fc["coop3"][N:, i, l],
                                       fc["local"][N:, i, l]])
                lo, hi = np.nanmin(vals), np.nanmax(vals)
                pad = 0.06 * (hi - lo)
                y0, y1 = lo - pad, hi + (3.2 if row == 0 else 1.0) * pad
                ax.set_ylim(y0, y1)
                ax.set_ylabel(r"drift $\theta_{%d,%d}(t)$" % (i + 1, l + 1) + "\n(net-engagement units)")
                head = "%s (%s), %s" % (run.tag(i), run.hubs[i], GENRES[l])
                if row == 0:
                    ax.set_title(head + (": the paper's Figure 3(b), top" if paper_trial
                                         else ": like the paper's Figure 3(b), top"))
                else:
                    ax.set_title(head + ": the worst local forecast")
                    if rho_local is not None and np.isfinite(rho_local[i]):
                        if rho_local[i] >= 1.0:
                            note = ("raw local estimate of A at server %d: spectral\nradius %.3f, not Schur stable; "
                                    "rescaled to %.3f,\nso the local forecast hardly decays"
                                    % (i + 1, rho_local[i], RHO_MAX))
                        else:
                            note = "raw local estimate of A at server %d:\nspectral radius %.3f" % (i + 1, rho_local[i])
                        # inside the panel if the bottom of the forecast phase is free of data, else a footnote
                        band = np.concatenate([th[N:, i, l], fc["coop3"][N:, i, l], fc["local"][N:, i, l]])
                        if np.nanmin(band) > y0 + 0.30 * (y1 - y0):
                            tr = blended_transform_factory(ax.transData, ax.transAxes)
                            ax.text(N + 0.04 * (T - N), 0.05, note, transform=tr, ha="left", va="bottom",
                                    fontsize=6.7, color=INK, zorder=7, linespacing=1.15,
                                    bbox=dict(fc="white", ec="none", alpha=0.9, pad=1.0))
                        elif rho_local[i] >= 1.0:
                            footnote = ("Bottom row: the raw local estimate of A at server %d has spectral radius %.3f "
                                        "(not Schur stable);\nrescaled to %.3f, its forecast hardly decays."
                                        % (i + 1, rho_local[i], RHO_MAX))
                        else:
                            footnote = ("Bottom row: the raw local estimate of A at server %d has spectral radius %.3f."
                                        % (i + 1, rho_local[i]))
            else:
                ax.set_xlim(z0, T)
                ax.xaxis.set_major_locator(FixedLocator(np.arange(50 * np.ceil(z0 / 50), T + 1, 50)))
                vals = np.concatenate([th[z0:, i, l], fc["coop3"][N:, i, l], fc["local"][N:, i, l]])
                lo, hi = np.nanmin(vals), np.nanmax(vals)
                pad = 0.08 * (hi - lo)
                ax.set_ylim(lo - pad, hi + 3.6 * pad)
                ax.set_title("zoom, %s" % days(z0, T - 1))
                ax.text(0.98, 0.97, "forecast RMSE, %s:\ncooperative %.3f, local %.3f" % (days(w0, w1), r_c, r_l),
                        transform=ax.transAxes, ha="right", va="top", fontsize=6.9, color=INK, zorder=7,
                        bbox=dict(fc="white", ec="none", alpha=0.85, pad=1.0))
            ygrid(ax)
            if row == len(cases) - 1:
                ax.set_xlabel("day $t$")
            if row == 0 and col == 0:
                handles, labels = ax.get_legend_handles_labels()
    fig.legend(rowmajor(handles, 3), rowmajor(labels, 3), loc="outside upper center", ncol=3, fontsize=7.1,
               handlelength=2.2, columnspacing=1.2, markerscale=1.6)
    if footnote:
        fig.supxlabel(footnote, x=0.01, ha="left", fontsize=6.9, color=INK, linespacing=1.2)
    save(fig, out, "fig_reconstruction")
    s = "; ".join("%s %s: forecast RMSE cooperative %.3f vs local %.3f" % (run.tag(i), GENRES[l], rc, rl)
                  for i, l, rc, rl in texts)
    recon = rmse(tt[:N - k + 1] - th[:N - k + 1])
    return ("fig_reconstruction: drift, its window reconstruction (RMS error per server and genre %.3f, "
            "t <= N-k) and the forecasts after the data stop; %s (days %d-%d)" % (recon, s, w0, w1))


# ----------------------------------------------------------------------------
# 4. boosts
# ----------------------------------------------------------------------------
def fig_boosts(run, out):
    B, xs, N, T, m = run.boosts, run.xstar, run.N, run.T, run.m
    t = np.arange(T)
    z0 = max(N - 10, 0)
    tz = np.arange(z0, T)
    methods = [mm for mm in ["coop3", "local", "persistence", "frozen"] if mm in B]
    fig = plt.figure(figsize=(7.2, 5.1), layout="constrained")
    gs = fig.add_gridspec(2, BOOSTED, height_ratios=[1, 1.1])
    top = []
    for l in range(BOOSTED):
        ax = fig.add_subplot(gs[0, l], sharey=top[0] if top else None)
        top.append(ax)
        phases(ax, N, T, labels=False)
        ax.plot(t, xs[:, l], color="black", lw=2.0, zorder=2, label=r"ideal boosts $x^\star_\ell(t)$")
        for i in range(m):
            ax.plot(t, B["coop3"][:, i, l], color=C_COOP, lw=0.55, alpha=0.8, zorder=3,
                    label=("boosts $x_{i,\\ell}(t)$ of the %d servers, " % m + label("coop3")) if i == 0 else None)
        day_axis(ax, T)
        ygrid(ax)
        ax.set_title("%s (genre %d)" % (GENRES[l], l + 1))
        if l == 0:
            ax.set_ylabel("boost (logit units)")
        else:
            ax.tick_params(labelleft=False)
        ax.set_xlabel("day $t$")

        ax2 = fig.add_subplot(gs[1, l])
        phases(ax2, N, T, t0=z0)
        ax2.plot(tz, xs[tz, l], color="black", lw=2.0, zorder=2)
        for mm in methods:
            st = STYLE[mm]
            ax2.plot(tz, np.mean(B[mm][tz, :, l], axis=1), color=st["color"], ls=st["ls"],
                     lw=1.5 if mm == "persistence" else 1.25, zorder=4 if mm == "coop3" else 3)
        ax2.set_xlim(z0, T)
        ax2.xaxis.set_major_locator(FixedLocator(np.arange(50 * np.ceil(z0 / 50), T + 1, 50)))
        vals = np.concatenate([xs[tz, l]] + [np.mean(B[mm][tz, :, l], axis=1) for mm in methods])
        lo, hi = np.nanmin(vals), np.nanmax(vals)
        pad = 0.07 * (hi - lo)
        ax2.set_ylim(lo - pad, hi + pad)
        ygrid(ax2)
        ax2.set_title("zoom: network average, %s" % days(z0, T - 1), fontsize=7.6, color=INK2)
        if l == 0:
            ax2.set_ylabel("network-average boost\n(logit units)")
        ax2.set_xlabel("day $t$")
    tr = blended_transform_factory(top[0].transData, top[0].transAxes)
    top[0].text(N / 2, 0.04, "data\ncollection", transform=tr, ha="center", va="bottom", fontsize=6.6, color=INK2)
    lo = min(np.nanmin(B["coop3"]), np.nanmin(xs))
    hi = max(np.nanmax(B["coop3"]), np.nanmax(xs))
    top[0].set_ylim(lo - 0.04 * (hi - lo), hi + 0.06 * (hi - lo))
    h1, l1 = top[0].get_legend_handles_labels()
    fig.legend(h1, l1, loc="outside upper center", ncol=2, fontsize=7.3)
    h2 = [Line2D([], [], color="black", lw=2.0)] + [
        Line2D([], [], color=STYLE[mm]["color"], ls=STYLE[mm]["ls"], lw=1.5 if mm == "persistence" else 1.25)
        for mm in methods]
    l2 = [r"ideal boosts $x^\star(t)$"] + ["%s (RMSE %.3f)" % (label(mm), run.kpis[mm]["rmse"]) for mm in methods]
    fig.legend(rowmajor(h2, 3), rowmajor(l2, 3), loc="outside lower center", ncol=3, fontsize=7.3,
               title="tracking RMSE of the boosts over %s (the paper's metric):" % days(run.win[0], run.win[-1]),
               title_fontsize=7.3)
    save(fig, out, "fig_boosts")
    return ("fig_boosts: the 8 servers' cooperative boosts converge to x*(t) during data collection and keep "
            "tracking it after the data stop; tracking RMSE over days %d-%d: %s"
            % (run.win[0], run.win[-1], ", ".join("%s %.4f" % (SHORT[mm], run.kpis[mm]["rmse"]) for mm in methods)))


# ----------------------------------------------------------------------------
# 5. identification
# ----------------------------------------------------------------------------
def fig_identification(run, out):
    idt, m = run.identification, run.m
    methods = [mm for mm in ["local", "coop1", "coop3", "exact"] if mm in idt]
    fig, ax = plt.subplots(figsize=(7.2, 3.35), layout="constrained")
    x = np.arange(m)
    bw = 0.8 / len(methods)
    floor = 0.01
    bad = np.flatnonzero(idt["local"]["rho"] >= 1.0) if "local" in idt else np.array([], int)
    for k, mm in enumerate(methods):
        e = idt[mm]["err"]
        off = (k - (len(methods) - 1) / 2) * bw
        ax.bar(x + off, e - floor, bottom=floor, width=bw * 0.9, color=STYLE[mm]["color"], lw=0, zorder=3,
               label="%s: mean %.3f" % (label(mm), np.mean(e)))
        if mm == "local":
            for i in bad:
                ax.bar(x[i] + off, e[i] - floor, bottom=floor, width=bw * 0.9, fc="none", ec="white", lw=0,
                       hatch="/////", zorder=4)
                ax.text(x[i] + off, e[i] * 1.07, r"$\rho$ = %.3f" % idt[mm]["rho"][i], ha="center", va="bottom",
                        fontsize=6.6, color=INK, zorder=5)
    ax.set_yscale("log")
    allv = np.concatenate([idt[mm]["err"] for mm in methods])
    ax.set_ylim(floor, max(1.0, 10 ** (np.log10(np.nanmax(allv)) + 0.3)))
    log_ticks(ax)
    ax.set_xticks(x)
    ax.set_xticklabels(["%s\n%s" % (run.tag(i), run.hubs[i]) for i in range(m)])
    ax.set_xlim(-0.6, m - 0.4)
    ax.tick_params(axis="x", length=0)
    ax.set_ylabel(r"identification error $\|\hat A_i - A\|_F$" + "\n(log scale)")
    ygrid(ax)
    gain = np.mean(idt["local"]["err"]) / np.mean(idt["coop3"]["err"])
    ax.set_title(r"Estimate of A at day N = %d, per server: cooperation ($\tau$ = 3) lowers the mean error "
                 r"%.1f$\times$ ($\sqrt{m}$ = %.2f)" % (run.N, gain, np.sqrt(m)))
    handles, labels = ax.get_legend_handles_labels()
    if len(bad):
        handles.append(Patch(fc=C_LOCAL, ec="white", lw=0, hatch="/////"))
        labels.append(r"raw local estimate not Schur stable ($\rho \geq 1$)")
    fig.legend(rowmajor(handles, 3), rowmajor(labels, 3), loc="outside lower center", ncol=3, fontsize=7.2,
               handlelength=1.4, columnspacing=1.6)
    save(fig, out, "fig_identification")
    n_coop_bad = int(np.sum(idt["coop3"]["rho"] >= 1.0))
    return ("fig_identification: ||A_hat_i - A||_F per server; mean %s: cooperation (tau=3) lowers it %.1fx "
            "(sqrt(m) = %.2f); %d of %d raw local estimates are not Schur stable (%s; rescaled to rho = %.3f), "
            "%d of the cooperative (tau=3) ones"
            % (", ".join("%s %.3f" % (SHORT[mm].replace("cooperative, ", "") if mm != "coop3" else "tau=3",
                                      np.mean(idt[mm]["err"])) for mm in methods),
               gain, np.sqrt(m), len(bad), m,
               ", ".join("%s rho=%.3f" % (run.codes[i], idt["local"]["rho"][i]) for i in bad) or "none",
               RHO_MAX, n_coop_bad))


# ----------------------------------------------------------------------------
# 6. feeds
# ----------------------------------------------------------------------------
def fig_feeds(run, out, share_regions=("LA", "SA")):
    fd, N, T = run.feed_daily, run.N, run.T
    methods = [mm for mm in ["coop3", "local", "persistence", "frozen"] if mm in fd]
    share_regions = [r for r in share_regions if r in run.ridx]
    t = np.arange(T)
    win = run.win
    A = {mm: 100.0 * np.mean(fd[mm]["agree"], axis=1) for mm in methods}
    fig = plt.figure(figsize=(7.2, 5.7), layout="constrained")
    gs = fig.add_gridspec(2, max(len(share_regions), 1), height_ratios=[1.0, 1.0])
    ax = fig.add_subplot(gs[0, :])
    phases(ax, N, T, labels=True)
    shared = all(np.allclose(A[mm][:N], A[methods[0]][:N]) for mm in methods)
    if shared:
        ax.plot(t[:N], A[methods[0]][:N], color="#3C3C3C", lw=1.0, zorder=3)
        ax.text(N - 2, 3, "same boosts\nfor every method", fontsize=6.6, color=INK2, ha="right", va="bottom")
    t1 = N - 1 if shared else 0
    for mm in methods:
        st = STYLE[mm]
        ax.plot(t[t1:], A[mm][t1:], color=st["color"], ls=st["ls"] if mm != "coop3" else "-",
                lw=1.3 if mm == "persistence" else 0.95, zorder=5 if mm == "coop3" else 4)
    extra = 72
    day_axis(ax, T, extra)
    ax.set_ylim(0, 104)
    ax.yaxis.set_major_locator(FixedLocator([0, 20, 40, 60, 80, 100]))
    ygrid(ax, x1=T)
    ax.set_ylabel("shoppers whose top-8 is\nthe ideal top-8 (%)")
    ax.set_xlabel("day $t$")
    ax.set_title("(a) Feeds served by each method versus the ideal feeds (network average over the %d regions)"
                 % run.m)
    means = [float(np.mean(A[mm][win])) for mm in methods]
    end_labels(ax, T - 1, T + 17, means, ["%s %.1f%%" % (SHORT[mm], v) for mm, v in zip(methods, means)],
               [STYLE[mm]["color"] for mm in methods], fontsize=6.9, mark="tick")
    ax.text(T + 2, 101.5, "mean over %s" % days(win[0], win[-1]), fontsize=6.6, color=INK2, ha="left",
            va="bottom")

    letters = "bcdefgh"
    for k, code in enumerate(share_regions):
        i = run.ridx[code]
        ax = fig.add_subplot(gs[1, k])
        S = 100.0 * fd["ideal"]["share"][:, i, :]                          # (T, 4)
        ax.stackplot(t, S.T, colors=GENRE_COLOR, edgecolor="white", linewidth=0.5, zorder=2)
        ax.axvline(N, color="#7A7A7A", lw=0.7, ls=(0, (3, 2)), zorder=3)
        day_axis(ax, T)
        ax.set_xlim(0, T - 1)
        ax.set_ylim(0, 100)
        ax.yaxis.set_major_locator(FixedLocator([0, 25, 50, 75, 100]))
        ax.set_xlabel("day $t$")
        if k == 0:
            ax.set_ylabel("share of the feed slots (%)\nunder the ideal boosts")
        ax.set_title("(%s) Ideal feeds in %s %s (%s)" % (letters[k], run.codes[i], run.names[i], run.hubs[i]))
        cum = np.cumsum(S, axis=1)
        xm = int(0.62 * T)
        for g in range(len(GENRES)):
            thick = S[xm, g]
            if thick >= 9.0:
                yc = cum[xm, g] - thick / 2
                tc = "white" if luminance(GENRE_COLOR[g]) < 0.2 else INK
                ax.text(xm, yc, "%s %.0f%%" % (GENRES[g], np.mean(S[win, g])), ha="center", va="center",
                        fontsize=6.8, color=tc, zorder=4)
    handles = [Patch(fc=GENRE_COLOR[g], ec="none", label=GENRES[g]) for g in range(len(GENRES))]
    fig.legend(handles=handles, loc="outside lower center", ncol=4, fontsize=7.2,
               title="genre of the feed slot (in-band labels: mean share over %s)" % days(win[0], win[-1]),
               title_fontsize=7.0)
    save(fig, out, "fig_feeds")
    sh = {code: 100.0 * np.mean(fd["ideal"]["share"][win, run.ridx[code]], axis=0) for code in share_regions}
    return ("fig_feeds: %% of shoppers whose top-8 is the ideal top-8, days %d-%d: %s; ideal feed of %s"
            % (win[0], win[-1], ", ".join("%s %.1f%%" % (SHORT[mm], v) for mm, v in zip(methods, means)),
               "; ".join("%s %s" % (code, ", ".join("%s %.0f%%" % (GENRES[g], sh[code][g])
                                                    for g in range(len(GENRES)))) for code in share_regions)))


# ----------------------------------------------------------------------------
# 7. example feeds
# ----------------------------------------------------------------------------
def tile_text(name):
    """Product name with non-breaking spaces inside quantities ("1 kg", "set of 6")."""
    s = re.sub(r"(\d) (L|kg|mAh|rolls)\b", "\\1\u00a0\\2", name)
    return s.replace("set of 6", "set\u00a0of\u00a06")


class TileFitter:
    """Largest font (and line breaking, at most two lines) for which a product
    name fits the inner width of a tile, measured with the renderer."""

    def __init__(self, fig, family, width_in, sizes=(6.6, 6.3, 6.0, 5.7, 5.4, 5.1)):
        self.r = fig.canvas.get_renderer()
        self.dpi, self.family, self.width, self.sizes = fig.dpi, family, width_in, sizes
        self.cache = {}

    def _w(self, s, size):
        prop = font_manager.FontProperties(family=self.family, size=size)
        w, _, _ = self.r.get_text_width_height_descent(s, prop, ismath=False)
        return w / self.dpi

    def fit(self, name):
        if name not in self.cache:
            s = tile_text(name)
            best = None
            for size in self.sizes:
                for width in (24, 18, 16, 14, 12, 10):
                    lines = textwrap.wrap(s, width, break_on_hyphens=False)
                    if len(lines) <= 2 and max(self._w(x, size) for x in lines) <= self.width:
                        best = ("\n".join(lines), size)
                        break
                if best:
                    break
            self.cache[name] = best or ("\n".join(textwrap.wrap(s, 12, break_on_hyphens=False)[:2]), self.sizes[-1])
        return self.cache[name]


def fig_example_feed(run, out, regions=("NAM", "EU", "SA"), narrow=None):
    ex = run.example_feeds
    days_ = sorted({d for (_, d, _) in ex})
    d_ref = run.N + 50 if run.N + 50 in days_ else min([d for d in days_ if d >= run.N] or [days_[-1]])
    early = [d for d in (0, 25, 50) if d in days_ and d < run.N]
    rows = [(mm, d_ref) for mm in ["ideal", "coop3", "local", "frozen", "noboost"]] + [("ideal", d) for d in early]
    regions = [r for r in regions if (r, d_ref, "ideal") in ex]
    if not regions:
        print("fig_example_feed: skipped (no ideal feed on day %d for the requested regions)" % d_ref)
        return None
    aff = run.shopper_affinity([ex[(r, d_ref, "ideal")]["shopper"] for r in regions])

    # layout in inches, y downwards
    W = 7.2
    lab_w, day_w, tile_gap, right = 1.30, 0.44, 0.04, 0.05
    x_t0 = lab_w + day_w
    tile_w = (W - x_t0 - right - 7 * tile_gap) / 8
    tile_h, pitch, head_h, grp_gap, blk_gap = 0.228, 0.258, 0.30, 0.10, 0.13
    top_h, leg_h = 0.66, 0.34
    blk_h = head_h + len(rows) * pitch + grp_gap
    H = top_h + len(regions) * blk_h + (len(regions) - 1) * blk_gap + leg_h
    fig = plt.figure(figsize=(W, H))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, W)
    ax.set_ylim(H, 0)
    ax.axis("off")
    family = narrow or "Arial"
    fitter = TileFitter(fig, family, tile_w - 0.075 - 0.03)

    ax.text(W / 2, 0.08, "The feed of a typical shopper: top-8 products, ranked left to right", ha="center",
            va="top", fontsize=10, fontweight="bold")
    ax.text(W / 2, 0.30, "tile color = genre; outlined = not in the ideal feed of day %d (each region's first row); "
            "under each method: its boosts x = (outdoor, home, tech) in logit units" % d_ref, ha="center", va="top",
            fontsize=6.9, color=INK2)
    for c in range(8):
        ax.text(x_t0 + c * (tile_w + tile_gap) + tile_w / 2, top_h - 0.04, "rank %d" % (c + 1), ha="center",
                va="bottom", fontsize=6.4, color=MUTED)

    y = top_h
    n_diff = {}
    for r in regions:
        i = run.ridx[r]
        ref = ex[(r, d_ref, "ideal")]
        ref_set = {p for _, p, _, _ in ref["items"]}
        a = aff[ref["shopper"]]
        ax.add_patch(Rectangle((0.03, y + 0.035), W - 0.06, head_h - 0.07, fc="#F2F2F2", ec="none"))
        ax.text(0.09, y + head_h / 2, "%s %s (%s)" % (run.tag(i), run.names[i], run.hubs[i]), ha="left",
                va="center", fontsize=8.2, fontweight="bold")
        ax.text(W - 0.09, y + head_h / 2, "typical shopper %s; genre affinity: outdoor %s, home %s, tech %s"
                % (ref["shopper"], signed(a[0]), signed(a[1]), signed(a[2])), ha="right", va="center",
                fontsize=6.9, color=INK2)
        y += head_h
        for k, (mm, d) in enumerate(rows):
            if k == 5:
                ax.plot([0.09, W - 0.09], [y + grp_gap / 2] * 2, color="#D0D0D0", lw=0.6)
                y += grp_gap
            key = (r, d, mm)
            yc = y + pitch / 2
            name = r"ideal $x^\star(t)$" if mm == "ideal" else (label(mm) if mm in ("coop3", "local") else short(mm))
            ax.text(0.09, yc - 0.045, name, ha="left", va="center", fontsize=7.0,
                    fontweight="bold" if (mm == "ideal" and d == d_ref) else "normal")
            ax.text(lab_w, yc, "day %d" % d, ha="left", va="center", fontsize=6.7, color=INK2)
            if key not in ex:
                ax.text(x_t0, yc, "(not in example_feeds.csv)", ha="left", va="center", fontsize=6.6, color=MUTED)
                y += pitch
                continue
            xv = ex[key]["x"]
            ax.text(0.09, yc + 0.065, "x = %.2f, %.2f, %.2f" % tuple(xv), ha="left", va="center", fontsize=6.0,
                    color=INK2)
            nd = 0
            for c, (_, pid, nm, g) in enumerate(ex[key]["items"]):
                x0 = x_t0 + c * (tile_w + tile_gap)
                y0 = yc - tile_h / 2
                new = pid not in ref_set
                nd += new
                ax.add_patch(FancyBboxPatch((x0, y0), tile_w, tile_h, boxstyle="round,pad=0,rounding_size=0.035",
                                            fc=tint(GENRE_COLOR[g], 0.70), ec=INK if new else "none",
                                            lw=1.3 if new else 0, zorder=2))
                ax.add_patch(Rectangle((x0 + 0.012, y0 + 0.03), 0.042, tile_h - 0.06, fc=GENRE_COLOR[g], ec="none",
                                       zorder=3))
                txt, size = fitter.fit(nm)
                ax.text(x0 + 0.06 + (tile_w - 0.06) / 2, yc, txt, ha="center", va="center", linespacing=0.92,
                        color=INK, zorder=4, family=family, fontsize=size)
            n_diff[key] = nd
            y += pitch
        y += blk_gap
    handles = [Patch(fc=tint(GENRE_COLOR[g], 0.70), ec=GENRE_COLOR[g], lw=1.0, label=GENRES[g])
               for g in range(len(GENRES))]
    handles.append(Patch(fc="white", ec=INK, lw=1.3, label="not in the ideal feed of day %d" % d_ref))
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5, 0.03 / H), ncol=5, fontsize=7.0,
               handlelength=1.6, columnspacing=1.2)
    save(fig, out, "fig_example_feed")
    parts = []
    for r in regions:
        parts.append("%s: %s" % (r, ", ".join("%s %d" % (SHORT[mm] if mm != "ideal" else "ideal day %d" % d,
                                                         n_diff.get((r, d, mm), -1)) for mm, d in rows[1:])))
    return ("fig_example_feed: feeds of the typical shopper of %s on day %d and the ideal feed on days %s; products "
            "not in the ideal day-%d feed: %s" % (", ".join(regions), d_ref, ", ".join(map(str, early)), d_ref,
                                                  "; ".join(parts)))


# ----------------------------------------------------------------------------
# 8. Monte Carlo
# ----------------------------------------------------------------------------
MC_METRICS = [("agree", "shoppers whose top-8 is\nthe ideal top-8 (%)", "feed agreement"),
              ("forecast", "interest forecast RMSE\n(net-engagement units)", "forecast error"),
              ("rmse", "boost tracking RMSE\n(logit units)", "tracking error (the paper's metric)")]
MC_METHODS = ["coop3", "local", "persistence", "frozen", "oracleA"]
MC_ZORDER = {"coop3": 6, "local": 5, "oracleA": 4, "frozen": 3, "persistence": 3}


def fig_montecarlo(run, out):
    path = os.path.join(run.src, "montecarlo", "mc_summary.csv")
    if not os.path.exists(path):
        print("fig_montecarlo: skipped (%s not found)" % path)
        return None
    try:
        c = read_columns(path, strict=False)
    except (ValueError, OSError) as e:
        print("fig_montecarlo: skipped (%s unreadable: %s)" % (path, e))
        return None
    need = {"N", "method", "metric", "median", "q25", "q75"}
    if not need <= set(c):
        print("fig_montecarlo: skipped (%s lacks the columns %s)" % (path, ", ".join(sorted(need - set(c)))))
        return None
    if len(c["N"]) == 0 or c["N"].dtype == object:
        print("fig_montecarlo: skipped (%s has no complete numeric rows yet)" % path)
        return None
    metrics = [mt for mt in MC_METRICS if np.any(c["metric"] == mt[0])]
    methods = [mm for mm in MC_METHODS if np.any(c["method"] == mm)]
    if not metrics or not methods:
        print("fig_montecarlo: skipped (no rows for the metrics agree/forecast/rmse and the methods %s)" % MC_METHODS)
        return None
    plotted = np.isin(c["method"], methods) & np.isin(c["metric"], [mt[0] for mt in metrics])
    Ns = np.unique(c["N"][plotted])
    fig, axes = plt.subplots(1, len(metrics), figsize=(7.2, 2.8), layout="constrained", squeeze=False)
    found = []
    for p, (ax, (mt, ylab, title)) in enumerate(zip(axes[0], metrics)):
        vals = []
        for mm in methods:
            sel = (c["metric"] == mt) & (c["method"] == mm)
            if not np.any(sel):
                continue
            o = np.argsort(c["N"][sel])
            n_, med, q25, q75 = (c[key][sel][o] for key in ("N", "median", "q25", "q75"))
            if mt == "agree" and np.nanmax(np.abs(med)) <= 1.0:
                med, q25, q75 = 100 * med, 100 * q25, 100 * q75            # fractions -> %
            st = STYLE[mm]
            z = MC_ZORDER.get(mm, 3)
            ax.fill_between(n_, q25, q75, color=st["color"], alpha=0.13, lw=0, zorder=1)
            ax.plot(n_, med, color=st["color"], ls=st["ls"], lw=1.2, marker=st["marker"], ms=3.6,
                    mfc=st["color"], mec=st["color"] if st["marker"] in ("x", "+") else "white", mew=0.6, zorder=z,
                    label=label(mm) if mm != "oracleA" else "oracle A (knows A)")
            vals.append(np.concatenate([q25, q75, med]))
            found.append((mt, mm, n_, med))
        ax.set_xscale("log")
        ax.xaxis.set_major_locator(FixedLocator(Ns))
        ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: "%g" % v))
        ax.xaxis.set_minor_locator(NullLocator())
        ax.set_xlim(Ns.min() / 1.15, Ns.max() * 1.15)
        v = np.concatenate(vals)
        v = v[np.isfinite(v)]
        if mt != "agree" and v.size and v.min() > 0 and v.max() / v.min() > 4:
            ax.set_yscale("log")
            log_ticks(ax)
        ax.set_xlabel("days of data collection $N$")
        ax.set_ylabel(ylab)
        ax.set_title("(%s) %s" % ("abc"[p], title), fontsize=8.2)
        ygrid(ax)
    handles, labels = [], []
    for ax in axes[0]:                                   # the union of the methods drawn in any panel
        for h, lb in zip(*ax.get_legend_handles_labels()):
            if lb not in labels:
                handles.append(h)
                labels.append(lb)
    if "n" in c:
        nn = c["n"][plotted]
        ntxt = ("%d trials per point" % nn.min()) if nn.min() == nn.max() else \
            ("%d%s%d trials per point (partial run)" % (nn.min(), NDASH, nn.max()))
    else:
        ntxt = "number of trials not given"
    fig.legend(handles, labels, loc="outside lower center", ncol=len(handles), fontsize=7.2,
               title="lines: medians, bands: interquartile ranges, %s" % ntxt, title_fontsize=7.0)
    save(fig, out, "fig_montecarlo")
    msg = []
    for mt, mm, n_, med in found:
        if mm in ("coop3", "local"):
            msg.append("%s %s %s" % (mt, SHORT[mm], " ".join("N=%g:%.3g" % (a, b) for a, b in zip(n_, med))))
    return "fig_montecarlo: medians/IQR versus N (%s); %s" % (ntxt.replace(NDASH, "-"), "; ".join(msg))


# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--src", default=os.path.join(HERE, "output"), help="folder written by run_demo.py")
    ap.add_argument("--out", default=None, help="where to write the figures (default <src>/figures)")
    ap.add_argument("--only", nargs="+", choices=FIGURES, help="make only these figures")
    ap.add_argument("--feed-regions", default="NAM,EU,SA", help="regions of fig_example_feed (codes)")
    ap.add_argument("--share-regions", default="LA,SA", help="the two regions of fig_feeds (b)-(c)")
    args = ap.parse_args()
    out = args.out or os.path.join(args.src, "figures")
    os.makedirs(out, exist_ok=True)
    narrow = setup_style()
    run = Run(args.src)
    captions = []
    for name in args.only or FIGURES:
        if name == "example_feed":
            cap = fig_example_feed(run, out, regions=args.feed_regions.split(","), narrow=narrow)
        elif name == "feeds":
            cap = fig_feeds(run, out, share_regions=args.share_regions.split(","))
        else:
            cap = globals()["fig_" + name](run, out)
        if cap:
            captions.append(cap)
            print(cap, flush=True)
    if not args.only:
        with open(os.path.join(out, "captions.txt"), "w", encoding="utf-8") as f:
            f.write("Figures of %s (N = %d, trial %d, seed %d)\n" % (os.path.abspath(args.src), run.N,
                                                                  run.cfg.get("trial", 0), run.cfg.get("seed", 0)))
            for cap in captions:
                f.write(cap + "\n")
    print("figures written to %s" % out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
