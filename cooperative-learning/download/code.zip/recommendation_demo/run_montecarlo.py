#!/usr/bin/env python3
"""
run_montecarlo.py -- the product-level metrics over the paper's Monte Carlo
trials of case study (B).

    python3 run_montecarlo.py                      # the paper's N-sweep: 50 trials x N = 30, 50, 100, 150, 200
    python3 run_montecarlo.py --quick              # 5 trials per N, into output/montecarlo_quick/
    python3 run_montecarlo.py --trials 2 --Ns 30 --jobs 2 --out /tmp/mc

The trials are those of the paper's N-sweep (experiments.n_sweep): trial r at
horizon N is experiments.run_trial(cs, N, rng([2026, 3, N, r]), taus=(3, 1)),
replayed by rcdemo.simulate.run_trial_logged with the paper's measurement model
(measure=None, which reproduces run_trial bit for bit).  The boosts of every
method are turned into the feeds of the 4,000 shoppers and scored against the
ideal feeds by rcdemo.kpi.trial_kpis, over the paper's window [N+50, N+200).

Writes to <out>/ (default output/montecarlo/):
  mc_trials.csv    one row per (N, trial, method): rmse, forecast, agree, overlap,
                   exposure, excess, id, unstable (defined in rcdemo/kpi.py) and
                   id_servers, the 8 per-server errors ||A_hat_i - A||_F, space
                   separated (only for the methods that estimate A)
  mc_summary.csv   N, method, metric, median, q25, q75, mean, n: statistics over
                   the trials; metric "id_server" pools the 8 servers of every
                   trial (n = 8 x trials), the paper's identification statistic
  mc_table.md      medians [q25, q75] of every metric, per method and N
  mc_check.txt     reproduction check against the paper's run: the medians of
                   the tracking RMSE and of the identification error and the
                   fraction of unstable estimates, recomputed from these trials,
                   against paper_v4_package/code/data/rc_*.dat

Only numpy is required.  One trial takes about 6 s on one core (2 s for the
trial, 4 s to rank the feeds of every method); the full sweep, 250 trials,
takes a few minutes with 6 worker processes.
"""
import argparse
import csv
import multiprocessing as mp
import os
import re
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from rcdemo import kpi                                                      # noqa: E402
from rcdemo.feeds import FeedEvaluator                                      # noqa: E402
from rcdemo.kpi import KPI_KEYS, LABEL, METHODS, trial_kpis                 # noqa: E402
from rcdemo.paper import CASE_ID, REF_DATA, SEED, ref                       # noqa: E402
from rcdemo.simulate import HORIZON, RMSE_FROM, paper_trial_rng, run_trial_logged  # noqa: E402
from rcdemo.world import make_world                                         # noqa: E402

NS = [30, 50, 100, 150, 200]        # the paper's N-sweep
TRIALS = 50                          # trials per N of the paper's run
QUICK_TRIALS = 5
TAUS = (3, 1)                        # consensus rounds of the N-sweep: coop3 and coop1
TOL = 1e-5                           # the .dat files print 6 significant digits
ID_SERVER = "id_server"              # ||A_hat_i - A||_F over all (trial, server) pairs
TRIAL_COLUMNS = ["N", "trial", "method"] + KPI_KEYS + ["id_servers"]
SUMMARY_COLUMNS = ["N", "method", "metric", "median", "q25", "q75", "mean", "n"]
HEADLINE_METHODS = ["coop3", "local", "persistence", "frozen"]
THREAD_VARS = ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"]
TABLE_FMT = {"rmse": "%.4f", "forecast": "%.4f", "agree": "%.1f", "overlap": "%.2f", "exposure": "%.2f",
             "excess": "%.1f", "id": "%.4f", "unstable": "%.3f", ID_SERVER: "%.4f"}


# ----------------------------------------------------------------------------
# the trials
# ----------------------------------------------------------------------------
_WORLDS = {}                         # the world of this process, per seed


def world_of(seed):
    """make_world(seed), built once per process."""
    if seed not in _WORLDS:
        _WORLDS[seed] = make_world(seed=seed)
    return _WORLDS[seed]


def run_one(job):
    """One trial of the N-sweep and its metrics; job = (seed, N, trial).
    Returns a dict: N, trial, kpis[method][key] (rcdemo.kpi.trial_kpis),
    ids[method] (m,) the per-server errors ||A_hat_i - A||_F, seconds."""
    seed, N, tr = job
    t0 = time.time()
    world = world_of(seed)
    trial = run_trial_logged(world.cs, N, paper_trial_rng(N, tr, seed), taus=TAUS)   # the paper's measurements
    kpis, _ = trial_kpis(world, trial, FeedEvaluator(world, trial.xstar, trial.window))
    ids = {key: np.asarray(v, float) for key, v in trial.id.items()}
    return dict(N=N, trial=tr, kpis=kpis, ids=ids, seconds=time.time() - t0)


def run_all(Ns, trials, jobs, seed, log=print):
    """Trials 0..trials-1 for every N, in ``jobs`` processes ('spawn').
    Returns the results ordered by N (as in Ns) and trial."""
    work = [(seed, N, tr) for N in sorted(Ns, reverse=True) for tr in range(trials)]   # longest trials first
    jobs = max(1, min(jobs, len(work)))
    done, t0 = {}, time.time()
    step = max(1, len(work) // 10)

    def collect(res):
        done[(res["N"], res["trial"])] = res
        if len(done) % step == 0 or len(done) == len(work):
            el = time.time() - t0
            log("  %4d/%d trials  %4.0fs elapsed, about %.0fs left" % (
                len(done), len(work), el, el * (len(work) - len(done)) / len(done)))

    if jobs == 1:
        for job in work:
            collect(run_one(job))
    else:
        # one BLAS thread per worker (the feeds are ranked by argpartition; BLAS threads only oversubscribe)
        unset = [v for v in THREAD_VARS if v not in os.environ]
        os.environ.update({v: "1" for v in unset})
        try:
            pool = mp.get_context("spawn").Pool(jobs)      # the workers inherit the environment now
        finally:
            for v in unset:
                os.environ.pop(v, None)
        with pool:
            for res in pool.imap_unordered(run_one, work):
                collect(res)
            pool.close()                 # let the workers exit normally (terminate() would leave
            pool.join()                  # the OpenMP runtime's registration files behind in /tmp)
    return [done[(N, tr)] for N in Ns for tr in range(trials)]


# ----------------------------------------------------------------------------
# statistics
# ----------------------------------------------------------------------------
def values(results, N, mm, key):
    """The values of a metric over the trials of one N (NaN dropped); for
    ID_SERVER, the per-server errors of all trials, trial by trial."""
    res = [r for r in results if r["N"] == N]
    if key == ID_SERVER:
        v = np.concatenate([r["ids"][mm] for r in res]) if mm in res[0]["ids"] else np.zeros(0)
    else:
        v = np.array([r["kpis"][mm][key] for r in res], float)
    return v[~np.isnan(v)]


def summary_rows(results, Ns):
    """Rows of mc_summary.csv (N, method, metric, median, q25, q75, mean, n),
    with experiments.quantiles' conventions (np.median, np.percentile)."""
    rows = []
    for N in Ns:
        kp = next(r for r in results if r["N"] == N)["kpis"]
        for mm in [mm for mm in METHODS if mm in kp]:
            for key in KPI_KEYS + [ID_SERVER]:
                v = values(results, N, mm, key)
                if v.size:
                    rows.append([N, mm, key, float(np.median(v)), float(np.percentile(v, 25)),
                                 float(np.percentile(v, 75)), float(np.mean(v)), int(v.size)])
    return rows


def fmt(v):
    if isinstance(v, (int, np.integer)):
        return str(v)
    if isinstance(v, (float, np.floating)):
        return "" if np.isnan(v) else "%.10g" % v
    return str(v)


def write_csv(path, header, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f)
        wr.writerow(header)
        for row in rows:
            wr.writerow([fmt(v) for v in row])


def trial_rows(results):
    """Rows of mc_trials.csv, methods in rcdemo.kpi.METHODS order."""
    rows = []
    for r in results:
        for mm in [mm for mm in METHODS if mm in r["kpis"]]:
            ids = " ".join("%.10g" % v for v in r["ids"][mm]) if mm in r["ids"] else ""
            rows.append([r["N"], r["trial"], mm] + [r["kpis"][mm][key] for key in KPI_KEYS] + [ids])
    return rows


# ----------------------------------------------------------------------------
# reproduction check against the paper's run
# ----------------------------------------------------------------------------
def read_dat(path):
    """Header and rows of a .dat file of experiments.write_dat."""
    with open(path) as f:
        header = f.readline().split()
        rows = [[float(v) for v in line.split()] for line in f if line.strip()]
    return header, np.array(rows)


def paper_run(data_dir=REF_DATA):
    """(trials, seed, first line) of the paper's run, from data/run_log.txt."""
    try:
        with open(os.path.join(data_dir, "run_log.txt")) as f:
            line = f.readline().strip()
    except OSError:
        return TRIALS, SEED, "(no run_log.txt)"
    mt = re.search(r"trials=(\d+)\s+seed=(\d+)", line)
    return (int(mt.group(1)), int(mt.group(2)), line) if mt else (TRIALS, SEED, line)


def rel_diff(ours, paper):
    """|ours - paper| / |paper|, or |ours| where the paper's value is 0."""
    return abs(ours - paper) / abs(paper) if paper != 0 else abs(ours)


# the paper's statistics, as experiments.n_sweep computes them from the trials of one N
PAPER_STAT = {
    "rmse": lambda res, key: float(np.median([r["kpis"][key]["rmse"] for r in res])),
    "id": lambda res, key: float(np.median(np.concatenate([r["ids"][key] for r in res]))),
    "unstable": lambda res, key: float(np.mean([r["kpis"][key]["unstable"] for r in res])),
}


def check(results, Ns, trials, seed, elapsed=None, jobs=None, data_dir=REF_DATA):
    """Recomputes the paper's statistics from the trials and compares them with
    the paper's data files.  Returns (lines of mc_check.txt, verdict), verdict
    PASS / FAIL, or NOT APPLICABLE when the run is not the paper's trial set."""
    p_trials, p_seed, p_line = paper_run(data_dir)
    by_N = {N: [r for r in results if r["N"] == N] for N in Ns}
    files = ([("rmse", "rc_rmse_%s.dat" % key, key, "y") for key in ref.RMSE_KEYS]
             + [("id", "rc_id_%s.dat" % key, key, "y") for key in ref.ID_KEYS]
             + [("unstable", "rc_unstable.dat", key, key) for key in ref.ID_KEYS])
    comps = []                                         # (group, file, column, N, ours, paper, rel)
    for group, fname, key, col in files:
        header, d = read_dat(os.path.join(data_dir, fname))
        for x, y in zip(d[:, header.index("x")], d[:, header.index(col)]):
            N = int(round(x))
            if N in by_N:
                ours = PAPER_STAT[group](by_N[N], key)
                comps.append((group, fname, col, N, ours, float(y), rel_diff(ours, float(y))))
    compared = sorted({c[3] for c in comps})
    applicable = trials == p_trials and seed == p_seed and bool(comps)
    ok = all(c[6] < TOL for c in comps)
    verdict = ("PASS" if ok else "FAIL") if applicable else "NOT APPLICABLE"

    L = ["Reproduction check: the paper's N-sweep of case study (B), recomputed from the trials of this run",
         "paper's run (paper_v4_package/code/data/run_log.txt): %s" % p_line,
         "this run: trials 0..%d at N = %s, seed %d, generator rng([%d, %d, N, trial]), taus %s, the paper's"
         % (trials - 1, " ".join(map(str, Ns)), seed, seed, CASE_ID, TAUS),
         "  measurement model (run_trial_logged with measure=None)%s" % (
             "" if elapsed is None else "; %d trials in %.0f s with %s jobs" % (len(results), elapsed, jobs)),
         "statistics (as experiments.n_sweep):",
         "  rc_rmse_<method>.dat  median over the trials of the tracking RMSE over [N+%d, N+%d)" % (RMSE_FROM, HORIZON),
         "  rc_id_<method>.dat    median over all trial-server values of ||A_hat_i - A||_F",
         "  rc_unstable.dat       mean over the trials of the fraction of servers whose raw estimate",
         "                        is not Schur stable",
         "relative difference |ours - paper| / |paper| (|ours| where the paper's value is 0); the .dat files",
         "print 6 significant digits; tolerance %.0e" % TOL,
         "",
         "  %-24s %-11s %4s %16s %12s %10s" % ("file", "column", "N", "this run", "paper", "rel. diff")]
    for group, fname, col, N, ours, paper, rel in comps:
        L.append("  %-24s %-11s %4d %16.10g %12.6g %10.1e%s" % (fname, col, N, ours, paper, rel,
                                                               "  <-- above tolerance" if applicable and rel >= TOL else ""))
    L.append("")
    if comps:
        parts = []
        for group, what in (("rmse", "files"), ("id", "files"), ("unstable", "columns")):
            cg = [c for c in comps if c[0] == group]
            if cg:
                nfiles = len({(c[1], c[2]) for c in cg})
                parts.append("%s %.1e (%d %s)" % (group, max(c[6] for c in cg), nfiles, what))
        L.append("max relative difference: %s, over N = %s" % (", ".join(parts), " ".join(map(str, compared))))
    if applicable:
        L.append("result: %s" % verdict)
    elif comps:
        L.append("result: NOT APPLICABLE (the paper's statistics are over trials 0..%d with seed %d; this run"
                 % (p_trials - 1, p_seed))
        L.append("        has trials 0..%d with seed %d), the differences above are for information only"
                 % (trials - 1, seed))
    else:
        L.append("result: NOT APPLICABLE (no N of this run is in the paper's files, N = %s)" % " ".join(map(str, NS)))
    return L, verdict


# ----------------------------------------------------------------------------
# tables
# ----------------------------------------------------------------------------
def metric_definitions():
    """{metric: definition}, from the docstring of rcdemo/kpi.py, plus ID_SERVER."""
    defs, cur = {}, None
    for line in (kpi.__doc__ or "").splitlines():
        mt = re.match(r"^    (\w+)\s{2,}(\S.*)$", line)
        if mt and mt.group(1) in KPI_KEYS:
            cur = mt.group(1)
            defs[cur] = mt.group(2).strip()
        elif cur and re.match(r"^ {8,}\S", line):
            defs[cur] += " " + line.strip()
        else:
            cur = None
    defs[ID_SERVER] = ("||A_hat_i - A||_F of a single server, the 8 servers of every trial pooled "
                       "(the paper's statistic for the identification error)")
    return defs


def md(s):
    """Escapes what markdown reads as a table cell separator or as emphasis."""
    return s.replace("|", "\\|").replace("*", "\\*")


def table_lines(summary, Ns, trials, seed):
    """mc_table.md: one table per metric, rows = methods (rcdemo.kpi.METHODS
    order), columns = N, cells = median [q25, q75] over the trials."""
    st = {(row[0], row[1], row[2]): row[3:] for row in summary}
    defs = metric_definitions()
    L = ["# Case study (B) over the paper's Monte Carlo trials", "",
         "Trials 0..%d of the paper's N-sweep at N = %s (seed %d, generator rng([%d, %d, N, trial]), "
         "consensus rounds tau = 3 and 1, the paper's measurement model), the trials of `experiments.n_sweep` "
         "(see `mc_check.txt`). `rmse`, `forecast` and `excess` are computed over the paper's window t in "
         "[N+%d, N+%d) from the boosts and the interest forecasts, `agree`, `overlap` and `exposure` over the "
         "same window from the feeds of the 4,000 shoppers of the 8 regions; `id`, `unstable` and `id_server` "
         "concern the estimates of A that the servers make at t = N. Each cell is the median [q25, q75] over "
         "the %d trials (`mc_summary.csv` also has the means)."
         % (trials - 1, ", ".join(map(str, Ns)), seed, seed, CASE_ID, RMSE_FROM, HORIZON, trials), "",
         "Metrics (definitions from `rcdemo/kpi.py`):", ""]
    for key in KPI_KEYS + [ID_SERVER]:
        L.append("- `%s`: %s" % (key, md(defs.get(key, ""))))
    L += ["", "A method is left out of a table when it has no such metric: frozen boosts and no boosts make no "
          "forecasts, and only the methods that estimate A have `id`, `unstable` and `id_server` (the "
          "centralized predictor uses the estimate of cooperative (tau=3)). In `id_server` the statistics "
          "are over 8 x %d server-trial values." % trials]
    for key in KPI_KEYS + [ID_SERVER]:
        L += ["", "## %s" % key, "", md(defs.get(key, "")), "",
              "| method | " + " | ".join("N = %d" % N for N in Ns) + " |",
              "|:---|" + "---:|" * len(Ns)]
        for mm in METHODS:
            cells = [st.get((N, mm, key)) for N in Ns]
            if all(c is None for c in cells):
                continue
            L.append("| %s | %s |" % (md(LABEL[mm]), " | ".join(
                "-" if c is None else "%s [%s, %s]" % tuple(TABLE_FMT[key] % v for v in c[:3]) for c in cells)))
    L += ["", "## unstable, mean over the trials", "",
          "The paper's statistic (`rc_unstable.dat`): mean over the trials of the fraction of servers whose raw "
          "estimate is not Schur stable.", "",
          "| method | " + " | ".join("N = %d" % N for N in Ns) + " |", "|:---|" + "---:|" * len(Ns)]
    for mm in METHODS:
        cells = [st.get((N, mm, "unstable")) for N in Ns]
        if not all(c is None for c in cells):
            L.append("| %s | %s |" % (md(LABEL[mm]), " | ".join("-" if c is None else "%.4f" % c[3] for c in cells)))
    return L


def headline_lines(summary, Ns):
    """Medians per N of agree, forecast and rmse for the headline methods."""
    st = {(row[0], row[1], row[2]): row[3] for row in summary}
    L = []
    for key, f in (("agree", "%8.2f"), ("forecast", "%8.4f"), ("rmse", "%8.4f")):
        L.append(("  median %s" % key).ljust(30) + "".join("%8s" % ("N=%d" % N) for N in Ns))
        for mm in HEADLINE_METHODS:
            L.append("    %-26s" % LABEL[mm] + "".join(
                ("%8s" % "-") if (N, mm, key) not in st else f % st[(N, mm, key)] for N in Ns))
    return L


# ----------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--Ns", default=",".join(map(str, NS)), help="comma separated values of N (default: the paper's)")
    ap.add_argument("--trials", type=int, default=TRIALS, help="trials 0..trials-1 per N (default 50, the paper's)")
    ap.add_argument("--quick", action="store_true", help="%d trials per N" % QUICK_TRIALS)
    ap.add_argument("--jobs", type=int, default=max(1, min(6, (os.cpu_count() or 1) - 2)),
                    help="worker processes (default min(6, cpus - 2))")
    ap.add_argument("--seed", type=int, default=SEED, help="seed of the instance and of the trials (default 2026)")
    ap.add_argument("--out", default=None,
                    help="output directory (default output/montecarlo/, or output/montecarlo_quick/ with --quick)")
    args = ap.parse_args(argv)
    if args.out is None:   # a quick run never overwrites the paper's sweep
        args.out = os.path.join(HERE, "output", "montecarlo_quick" if args.quick else "montecarlo")
    Ns = list(dict.fromkeys(int(v) for v in args.Ns.split(",") if v.strip()))
    trials = QUICK_TRIALS if args.quick else args.trials
    if not Ns or trials < 1:
        ap.error("need at least one N and one trial")
    os.makedirs(args.out, exist_ok=True)

    t0 = time.time()
    print("Monte Carlo of case study (B): trials 0..%d x N = %s, seed %d, %d jobs -> %s" % (
        trials - 1, " ".join(map(str, Ns)), args.seed, args.jobs, args.out), flush=True)
    results = run_all(Ns, trials, args.jobs, args.seed, log=lambda s: print(s, flush=True))
    elapsed = time.time() - t0

    write_csv(os.path.join(args.out, "mc_trials.csv"), TRIAL_COLUMNS, trial_rows(results))
    summary = summary_rows(results, Ns)
    write_csv(os.path.join(args.out, "mc_summary.csv"), SUMMARY_COLUMNS, summary)
    with open(os.path.join(args.out, "mc_table.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(table_lines(summary, Ns, trials, args.seed)) + "\n")
    lines, verdict = check(results, Ns, trials, args.seed, elapsed=elapsed, jobs=args.jobs)
    with open(os.path.join(args.out, "mc_check.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    print("\n".join(headline_lines(summary, Ns)))
    print("\n".join(lines[len(lines) - lines[::-1].index(""):]))           # the verdict, after the last blank line
    print("%d trials in %.0f s (%.1f s per trial in a worker); wrote %s" % (
        len(results), elapsed, np.mean([r["seconds"] for r in results]), args.out), flush=True)
    return 1 if verdict == "FAIL" else 0


if __name__ == "__main__":
    sys.exit(main())
