#!/usr/bin/env python3
"""
make_dashboard_data.py -- the tables behind the results dashboard.

    python3 make_dashboard_data.py [--N 100 --trial 0] [--out output/dashboard]

Re-runs the showcase trial of run_demo.py (same generators, so the same trial
and the same session logs) and writes small, page-ready tables to
<out>/*.csv: regions, links, catalog, a sample of the exploration sessions,
the servers' daily interest estimates, interests and forecasts, the
identification errors, the boost errors after day N, feed agreement and genre
mix per day, example feeds of two shoppers per region (the typical shopper of
run_demo.py, and the "contrast" shopper: the one whose top-8 local learning got
wrong, and cooperative learning right, on the most days of the metric window),
the metrics of every
method, and (when output/montecarlo/mc_summary.csv exists) the Monte Carlo
summary.  Only numpy is required.
"""
import argparse
import csv
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from rcdemo.feeds import FeedEvaluator, feed_of, region_scores, topk_mask    # noqa: E402
from rcdemo.kpi import KPI_KEYS, LABEL, region_kpis, trial_kpis             # noqa: E402
from rcdemo.paper import CASE_ID, SEED, ref                                 # noqa: E402
from rcdemo.simulate import SESSIONS_PER_DAY, SessionLog, paper_trial_rng, run_trial_logged  # noqa: E402
from rcdemo.world import BOOSTED, CHORDS, GENRES, GENRE_KEYS, make_world   # noqa: E402
from run_demo import SESSION_STREAM, typical_shopper, write_csv            # noqa: E402

def feed_days(N, T):
    """Days of the example feeds: 0, N/4, N/2, the last day with data, N+50 (the first day of
    the metric window), N+100 and the last day (0, 25, 50, 99, 150, 200, 299 for N = 100)."""
    return sorted({t for t in (0, N // 4, N // 2, N - 1, N + 50, N + 100, T - 1) if 0 <= t < T})


FEED_METHODS = ["ideal", "coop3", "local", "persistence", "frozen", "noboost"]
STRIP_METHODS = ["coop3", "local", "frozen"]
CURVE_METHODS = ["coop3", "local", "persistence", "frozen", "oracleA"]
ERROR_METHODS = ["coop3", "local", "persistence", "frozen"]
SESSIONS_SHOWN = 5
MC_METRICS = ["agree", "forecast", "rmse", "id_server", "exposure"]   # id_server: the paper's pooled statistic
MC_METHODS = ["coop3", "local", "persistence", "frozen", "oracleA", "exact", "centralized"]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--N", type=int, default=100)
    ap.add_argument("--trial", type=int, default=0)
    ap.add_argument("--out", default=os.path.join(HERE, "output", "dashboard"))
    ap.add_argument("--mc", default=os.path.join(HERE, "output", "montecarlo", "mc_summary.csv"))
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    N, tr = args.N, args.trial
    o = lambda name: os.path.join(args.out, name)   # noqa: E731

    world = make_world()
    cs, m = world.cs, world.m
    codes = [r["code"] for r in world.regions]
    P, Uu = world.products, world.users
    log = SessionLog(world, np.random.default_rng([SEED, CASE_ID, SESSION_STREAM, N, tr]))
    trial = run_trial_logged(cs, N, paper_trial_rng(N, tr), taus=(3, 1), measure=log)
    T, k = trial.T, trial.k
    feval = FeedEvaluator(world, trial.xstar, np.arange(T))
    kpis, daily = trial_kpis(world, trial, feval)
    win = trial.window
    GK = GENRE_KEYS[:BOOSTED]

    # --- the platform
    write_csv(o("regions.csv"), ["server", "code", "region", "data_center", "lambda"]
              + ["ubar_%s" % g for g in GK] + ["neighbors", "shoppers"],
              [[r["index"] + 1, r["code"], r["name"], r["hub"], r["lam"]] + list(r["ubar"])
               + [" ".join(codes[j] for j in r["neighbors"]), len(world.by_region[i])]
               for i, r in enumerate(world.regions)], nd=4)
    chords0 = {(a - 1, b - 1) for a, b in CHORDS}
    write_csv(o("links.csv"), ["link", "from", "to", "kind"],
              [["%s-%s" % (codes[i], codes[j]), codes[i], codes[j], "chord" if (i, j) in chords0 else "ring"]
               for (i, j) in world.edges])
    write_csv(o("catalog.csv"), ["product", "name", "genre", "boosted", "price_usd", "base_score"],
              [[P["pid"][j], P["name"][j], GENRES[P["genre"][j]], "yes" if P["genre"][j] < BOOSTED else "no",
                P["price"][j], P["base"][j]] for j in range(len(P["pid"]))])

    # --- the data the servers receive (t < N)
    rows = []
    for i in range(m):
        for t in sorted({0, N // 2, N - 1}):           # first, middle and last day with data
            if t >= N:
                continue
            for s in range(SESSIONS_SHOWN):
                rows.append([t, codes[i], "%s-%03d-%03d" % (codes[i], t, s + 1), Uu["uid"][log.users[t, i, s]]]
                            + list(log.scores[t, i, s]))
    write_csv(o("sessions.csv"), ["day", "region", "session", "shopper"] + ["net_%s" % g for g in GK], rows, nd=3)
    write_csv(o("reports.csv"), ["day", "region"] + ["uhat_%s" % g for g in GK],
              [[t, codes[i]] + list(log.u_hat[t, i]) for t in range(N) for i in range(m)], nd=4)
    rows = []
    for t in range(T):
        for i in range(m):
            for g in range(BOOSTED):
                ub = cs.ubar[i, g]
                win_est = ub + trial.th[i, t, g] if t < trial.th.shape[1] else np.nan
                fc = lambda key: ub + trial.forecasts[key][t - N, i, g] if t >= N else np.nan   # noqa: E731
                rows.append([t, codes[i], GK[g], trial.u[t, i, g], win_est, fc("coop3"), fc("local"),
                             fc("coop3") - trial.u[t, i, g], fc("local") - trial.u[t, i, g]])
    write_csv(o("interests.csv"), ["day", "region", "genre", "true", "window", "coop3", "local",
                                   "err_coop3", "err_local"], rows, nd=4)

    # --- identification
    rows = []
    for key in ["local", "coop1", "coop3", "exact", "pooledLS"]:
        _, rho = trial.estimates[key]
        for i in range(m):
            rows.append([key, codes[i], trial.id[key][i], rho[i], "no" if rho[i] >= 1 else "yes"])
    write_csv(o("identification.csv"), ["method", "region", "error_F", "rho_raw", "stable_raw"], rows, nd=4)

    # --- boosts after the data stop: network-average error per genre
    rows = []
    for key in ERROR_METHODS:
        xb = trial.boosts[key].mean(axis=1)                         # (T, n)
        for t in range(N, T):
            for g in range(BOOSTED):
                rows.append([t, key, GK[g], xb[t, g] - trial.xstar[t, g], xb[t, g], trial.xstar[t, g]])
    write_csv(o("boost_error.csv"), ["day", "method", "genre", "error", "boost", "ideal"], rows, nd=5)

    # --- feeds: agreement with the ideal feed (network average) and genre mix per region
    rows = []
    for key in CURVE_METHODS:
        d = daily[key]
        for t in range(T):
            rows.append([t, key, 100 * d["agree"][t].mean(), 100 * d["overlap"][t].mean()])
    write_csv(o("agreement.csv"), ["day", "method", "agree", "overlap"], rows, nd=5)
    rows = []
    for t in range(T):
        for i in range(m):
            for g in range(len(GENRES)):
                rows.append([t, codes[i], GENRE_KEYS[g], 100 * feval.share_ideal[t, i, g],
                             100 * daily["coop3"]["share"][t, i, g]])
    write_csv(o("mix.csv"), ["day", "region", "genre", "ideal", "coop3"], rows, nd=4)

    # --- example feeds: a typical shopper and the one whose feed local learning got wrong most often
    shop_rows, feed_rows, strip_rows = [], [], []
    track = np.arange(N, T)
    for i in range(m):
        idx = world.by_region[i]
        ideal_mk = topk_mask(region_scores(world, i, trial.xstar[track]))
        differs = {key: (topk_mask(region_scores(world, i, trial.boosts[key][track, i])) != ideal_mk).any(axis=2)
                   for key in STRIP_METHODS}                                   # (days, U_i)
        inwin = track >= win[0]
        wrong = {key: differs[key][inwin].sum(axis=0) for key in STRIP_METHODS}
        typ = typical_shopper(world, i)
        # the shopper whose feed local learning got wrong, and cooperative learning right, on the most
        # days of the window (ties: the most days with local learning wrong)
        only_local = (differs["local"] & ~differs["coop3"])[inwin].sum(axis=0)
        con = int(idx[np.lexsort((-wrong["local"], -only_local))[0]])
        for kind, s in (("typical", typ), ("contrast", con)):
            pos = int(np.flatnonzero(idx == s)[0])
            hit = np.flatnonzero(inwin & differs["local"][:, pos] & ~differs["coop3"][:, pos])
            first = int(track[hit[0]]) if len(hit) else -1                       # first such day in the window
            shop_rows.append([codes[i], Uu["uid"][s], kind] + list(Uu["affinity"][s])
                             + [int(wrong["coop3"][pos]), int(wrong["local"][pos]), int(wrong["frozen"][pos]),
                                len(win), first])
            for key in STRIP_METHODS:
                for d, t in enumerate(track):
                    strip_rows.append([codes[i], kind, int(t), key, 0 if differs[key][d, pos] else 1])
            for t in sorted(set(feed_days(N, T) + ([first] if first >= 0 else []))):
                ideal_set = set(feed_of(world, s, trial.xstar[t]).tolist())
                for key in FEED_METHODS:
                    x = trial.xstar[t] if key == "ideal" else trial.boosts[key][t, i]
                    for rnk, j in enumerate(feed_of(world, s, x)):
                        feed_rows.append([codes[i], Uu["uid"][s], kind, t, key, rnk + 1, P["pid"][j], P["name"][j],
                                          GENRE_KEYS[P["genre"][j]], "yes" if j in ideal_set else "no"] + list(x))
    write_csv(o("shoppers.csv"), ["region", "shopper", "kind"] + ["affinity_%s" % g for g in GK]
              + ["days_coop3_differs", "days_local_differs", "days_frozen_differs", "days", "first_contrast_day"],
              shop_rows, nd=3)
    write_csv(o("strip.csv"), ["region", "kind", "day", "method", "same"], strip_rows)
    write_csv(o("feeds.csv"), ["region", "shopper", "kind", "day", "method", "rank", "product", "name", "genre",
                               "in_ideal"] + ["x_%s" % g for g in GK], feed_rows, nd=4)

    # --- metrics
    write_csv(o("kpis.csv"), ["method", "label"] + KPI_KEYS,
              [[mm, LABEL[mm]] + [kpis[mm][kk] for kk in KPI_KEYS] for mm in kpis], nd=5)
    rk = region_kpis(world, trial, daily, methods=("coop3", "local"))
    write_csv(o("kpis_region.csv"), ["method", "region", "boost_rmse", "agree", "overlap", "forecast", "id"],
              [[r["method"], r["region"], r["boost_rmse"], r["agree"], r["overlap"], r["forecast"], r["id"]]
               for r in rk], nd=4)
    if os.path.exists(args.mc):
        with open(args.mc) as f:
            mc = [r for r in csv.DictReader(f) if r["metric"] in MC_METRICS and r["method"] in MC_METHODS]
        write_csv(o("mc.csv"), ["N", "method", "metric", "median", "q25", "q75", "n"],
                  [[r["N"], r["method"], r["metric"], float(r["median"]), float(r["q25"]), float(r["q75"]), r["n"]]
                   for r in mc], nd=5)
        print("Monte Carlo summary: %d rows" % len(mc))
    else:
        print("no Monte Carlo summary at %s (skipped mc.csv)" % args.mc)
    run = [("N", N, "days of data collection"), ("T", T, "days simulated"), ("trial", tr, "trial of the paper's N-sweep"),
           ("seed", SEED, "seed of the paper's run"), ("tau", trial.taus[0], "consensus rounds"), ("k", k, "window length"),
           ("sessions_per_day", SESSIONS_PER_DAY, "exploration sessions per region and day"),
           ("sessions_total", N * m * SESSIONS_PER_DAY, "exploration sessions logged"),
           ("shoppers", len(Uu["uid"]), "shoppers"), ("products", len(P["pid"]), "products"), ("regions", m, "regions"),
           ("window_start", int(win[0]), "first day of the metric window"), ("window_end", int(win[-1]), "last day"),
           ("session_sd", float(log.sigma[0]), "per-session spread of the scores"),
           ("noise_sd", float(np.sqrt(cs.R[0, 0])), "measurement noise of the paper"),
           ("sqrt_m", float(np.sqrt(m)), "square root of the number of servers"),
           ("days_tracking", T - N, "days without data"),
           ("a_rho", 0.98, "damping of the Outdoor/Home cycle in A"), ("a_angle", 0.25, "rotation per day of that cycle (rad)"),
           ("a_period", float(2 * np.pi / 0.25), "period of the cycle (days)"), ("a_fade", 0.95, "daily fading of Trending Tech in A"),
           ("alpha", cs.alpha, "step size of gradient tracking"), ("sigma_W", float(ref.contraction(cs.W)), "contraction factor of the backbone"),
           ("feed_size", 8, "products on the first screen")]
    assert abs(cs.A[0, 0] - 0.98 * np.cos(0.25)) < 1e-12 and abs(cs.A[2, 2] - 0.95) < 1e-12
    write_csv(o("run.csv"), ["key", "value", "meaning"], run)
    # consistency with run_demo.py's output/, when that folder holds the same trial
    cfg_p, kp = os.path.join(HERE, "output", "run_config.json"), os.path.join(HERE, "output", "kpis.csv")
    note = "output/ holds another trial: not compared"
    if os.path.exists(cfg_p) and os.path.exists(kp):
        with open(cfg_p) as f:
            cfg = json.load(f)
        if (cfg.get("N"), cfg.get("trial"), cfg.get("seed"), cfg.get("sessions_per_day")) == (N, tr, SEED, SESSIONS_PER_DAY):
            with open(kp) as f:
                ref_agree = float(next(r for r in csv.DictReader(f) if r["method"] == "coop3")["agree"])
            note = "|diff vs output/kpis.csv| = %.2g" % abs(kpis["coop3"]["agree"] - ref_agree)
    print("wrote %s (coop3 feed agreement %.2f%%, %s)" % (args.out, kpis["coop3"]["agree"], note))


if __name__ == "__main__":
    main()
