"""
Shared fixtures of the test suite of recommendation_demo.

The tests import ``rcdemo`` the way run_demo.py does, so the demo folder is put
on sys.path here.  The expensive objects are built once per test session:

    world          make_world(): the paper's instance of case study (B) (seed 2026)
                   with its concrete layer (regions, catalog, 4,000 shoppers)
    trials         memoized trials: trials.get(N, trial, sessions) -> Run with
                   .trial (run_trial_logged from rng([2026, 3, N, trial]), taus=(3, 1)),
                   .log (the SessionLog, or None), .state (the state of the trial
                   generator after the run), .sess_before/.sess_after (states of the
                   session generator rng([2026, 3, 9002, N, trial]) of run_demo.py)
    showcase       (trial, log): the trial of run_demo.py, N = 100, trial 0 (the
                   trial of the paper's Figure 3(b)), measurements from session logs
    showcase_trial, session_log   its two parts
    paper_trial    the same trial with the paper's measurement model (measure=None)
    session_rng    the function (N, trial) -> run_demo.py's session generator

Tests write only to pytest's tmp directories, never to recommendation_demo/output/.
"""
import os
import sys
from types import SimpleNamespace

import numpy as np
import pytest

TESTS = os.path.dirname(os.path.abspath(__file__))
DEMO = os.path.dirname(TESTS)                      # .../recommendation_demo
if DEMO not in sys.path:
    sys.path.insert(0, DEMO)

from rcdemo.paper import CASE_ID, SEED                                    # noqa: E402
from rcdemo.simulate import SessionLog, paper_trial_rng, run_trial_logged  # noqa: E402
from rcdemo.world import make_world                                       # noqa: E402

SHOWCASE_N, SHOWCASE_TRIAL = 100, 0     # run_demo.py's default trial
SESSION_STREAM = 9002                   # run_demo.py: rng([seed, 3, 9002, N, trial]) draws the sessions
TAUS = (3, 1)                           # consensus rounds of the paper's N-sweep (experiments.n_sweep)


def _session_rng(N, trial, seed=SEED):
    """The generator run_demo.py gives SessionLog for (N, trial)."""
    return np.random.default_rng([seed, CASE_ID, SESSION_STREAM, N, trial])


class TrialCache:
    """Trials of the paper's N-sweep, simulated once per test session."""

    def __init__(self, world):
        self.world = world
        self.runs = {}

    def get(self, N, trial, sessions=True):
        key = (N, trial, bool(sessions))
        if key not in self.runs:
            g = paper_trial_rng(N, trial)
            log = gs = before = None
            if sessions:
                gs = _session_rng(N, trial)
                before = gs.bit_generator.state
                log = SessionLog(self.world, gs)
            t = run_trial_logged(self.world.cs, N, g, taus=TAUS, measure=log)
            self.runs[key] = SimpleNamespace(trial=t, log=log, state=g.bit_generator.state, sess_before=before,
                                             sess_after=gs.bit_generator.state if sessions else None)
        return self.runs[key]


@pytest.fixture(scope="session")
def demo_dir():
    return DEMO


@pytest.fixture(scope="session")
def session_rng():
    return _session_rng


@pytest.fixture(scope="session")
def world():
    return make_world()


@pytest.fixture(scope="session")
def trials(world):
    return TrialCache(world)


@pytest.fixture(scope="session")
def showcase(trials):
    """(trial, log) of run_demo.py's default run (measurements from session logs)."""
    run = trials.get(SHOWCASE_N, SHOWCASE_TRIAL, sessions=True)
    return run.trial, run.log


@pytest.fixture(scope="session")
def showcase_trial(showcase):
    return showcase[0]


@pytest.fixture(scope="session")
def session_log(showcase):
    return showcase[1]


@pytest.fixture(scope="session")
def paper_trial(trials):
    """run_demo.py's trial with the paper's measurement model (measure=None)."""
    return trials.get(SHOWCASE_N, SHOWCASE_TRIAL, sessions=False).trial
