"""
Metrics of a trial (rcdemo.kpi) against their definitions.

team_cost is compared with the paper's F = sum_i f_i (experiments' value_F);
solo_optimum with its first-order condition lambda_i x = u sigma(-x); and the
metrics of trial_kpis on the showcase trial (N = 100, trial 0, window
t = 150..299) with an independent implementation written from the definitions
in kpi.py's docstring: top-8 sets by a full sort, boosts applied by hand, team
cost by value_F, and every average spelled out.
"""
import numpy as np
import pytest

from rcdemo.feeds import FeedEvaluator
from rcdemo.kpi import KPI_KEYS, METHODS, region_kpis, solo_optimum, team_cost, trial_kpis

NO_FORECAST = {"frozen", "noboost"}
WITH_ID = {"local", "coop1", "coop3", "exact", "pooledLS"}


@pytest.fixture(scope="module")
def kpis(world, showcase_trial):
    """trial_kpis with a feed evaluator over the window, as the brief recommends."""
    t = showcase_trial
    return trial_kpis(world, t, FeedEvaluator(world, t.xstar, t.window))


def test_team_cost_equals_value_F(world):
    cs = world.cs
    g = np.random.default_rng(2)
    for _ in range(50):
        x = g.normal(scale=2.0, size=3)
        Theta = g.normal(scale=1.5, size=(8, 3))
        u_tot = (cs.ubar + Theta).sum(axis=0)
        assert team_cost(cs, x, u_tot) == pytest.approx(cs.value_F(x, Theta), rel=1e-12, abs=1e-12)
    # broadcast over days and servers, as trial_kpis uses it: x (D, m, n), u_total (D, 1, n)
    X, Th = g.normal(size=(6, 8, 3)), g.normal(scale=1.5, size=(6, 8, 3))
    F = team_cost(cs, X, (cs.ubar[None] + Th).sum(axis=1)[:, None, :])
    assert F.shape == (6, 8)
    for d in range(6):
        for i in range(8):
            assert F[d, i] == pytest.approx(cs.value_F(X[d, i], Th[d]), rel=1e-12)


def solo_residual(cs, u, x):
    """lambda_i x - u sigma(-x), elementwise, for u, x of shape (T, m, n)."""
    return cs.varpi[None, :, None] * x - u / (1.0 + np.exp(x))


def test_solo_optimum_on_the_showcase_trial(world, showcase_trial):
    cs, u = world.cs, showcase_trial.u
    x = solo_optimum(cs, u)
    assert x.shape == u.shape
    assert np.max(np.abs(solo_residual(cs, u, x))) <= 1e-10
    # and it is the minimizer of the separable f_i: f_i'' > 0 there
    s = 1.0 / (1.0 + np.exp(x))
    assert np.all(cs.varpi[None, :, None] + u * s * (1 - s) > 0)


def test_solo_optimum_where_f_i_is_convex(world):
    """u_il > -4 lambda_i makes f_i strictly convex in x_l (f'' >= lambda_i - |u|/4)."""
    cs = world.cs
    lam = cs.varpi
    fr = np.concatenate([np.linspace(-0.999, 0.0, 120), np.linspace(0.0, 4.0, 120)])
    u = (4.0 * lam[None, :] * fr[:, None])[:, :, None] * np.ones((1, 1, 3))     # (240, 8, 3)
    x = solo_optimum(cs, u)
    assert np.max(np.abs(solo_residual(cs, u, x))) <= 1e-10


def test_solo_optimum_on_the_interests_of_a_paper_trial(world, trials):
    """Trial 5 of the paper's N-sweep at N = 30 starts with u_il(0) < -4 lambda_i
    for some (i, l) (theta_i(0) ~ N(0, 1.5^2 I)).  f_i is not convex there, but
    it still has a unique minimizer, at which the first-order condition holds."""
    cs = world.cs
    t = trials.get(30, 5, sessions=False).trial
    with np.errstate(over="ignore"):
        x = solo_optimum(cs, t.u)
        r = np.abs(solo_residual(cs, t.u, x))
    r = np.where(np.isfinite(r), r, np.inf)
    d, i, l = np.unravel_index(np.argmax(r), r.shape)
    stationary = bool(np.max(r) <= 1e-10)
    assert stationary, (
        "solo_optimum is not stationary on %d of %d entries; worst: day %d, region %d, genre %d: "
        "u = %.4f, lambda = %.4f (4 lambda = %.4f), x = %.5f, residual %.3g"
        % (int(np.sum(~(r <= 1e-10))), r.size, d, i, l, t.u[d, i, l], cs.varpi[i], 4 * cs.varpi[i],
           x[d, i, l], r[d, i, l]))


def test_kpis_have_every_method_and_key(kpis):
    k, daily = kpis
    assert list(k) == METHODS
    for mm in METHODS:
        assert set(k[mm]) == set(KPI_KEYS), mm
        assert set(daily[mm]) == {"agree", "overlap", "share"}


def test_ideal_row_is_perfect(kpis):
    r = kpis[0]["ideal"]
    assert r["rmse"] == 0.0 and r["forecast"] == 0.0
    assert r["agree"] == 100.0 and r["overlap"] == 100.0
    assert r["exposure"] == 0.0 and r["excess"] == 0.0
    assert np.isnan(r["id"]) and np.isnan(r["unstable"])


def test_rmse_equals_trial_rmse(kpis, showcase_trial):
    for mm in METHODS[1:]:
        assert kpis[0][mm]["rmse"] == showcase_trial.rmse[mm], mm


# ----------------------------------------------------------------------------
# independent recomputation
# ----------------------------------------------------------------------------
def top8_sets(world, Xday):
    """Feed sets (U, 8), sorted product indices, of every shopper when server i
    applies the boosts Xday[i] (m, 3) to the shoppers of region i."""
    genre, region = world.products["genre"], world.users["region"]
    shift = np.zeros((world.m, 4))
    shift[:, :3] = Xday
    scores = world.users["base_scores"] + shift[region][:, genre]
    return np.sort(np.argsort(-scores, axis=1, kind="stable")[:, :8], axis=1)


def slot_mask(sets, P=32):
    M = np.zeros((sets.shape[0], P), dtype=bool)
    M[np.arange(sets.shape[0])[:, None], sets] = True
    return M


@pytest.fixture(scope="module")
def recomputed(world, showcase_trial):
    cs, t = world.cs, showcase_trial
    N, m = t.N, world.m
    win = np.arange(N + 50, N + 200)             # the paper's window, not Trial.window
    region, genre = world.users["region"], world.products["genre"]
    n_i = np.bincount(region, minlength=m)
    assert np.all(n_i == 500)                    # equal regions: % of all shoppers = mean over regions
    onehot = (genre[:, None] == np.arange(4)[None, :]).astype(float)

    def shares(M):
        """(m, 4): slots of each genre over all feeds of region i / (8 * shoppers of region i)."""
        c = M.astype(float) @ onehot
        return np.stack([np.bincount(region, weights=c[:, gg], minlength=m) for gg in range(4)], axis=1) / (8.0 * n_i[:, None])

    ideal = {}
    for d in win:
        fi = top8_sets(world, np.repeat(t.xstar[d][None], m, axis=0))
        ideal[d] = (fi, slot_mask(fi), shares(slot_mask(fi)))
    out = {}
    for mm in METHODS:
        X = np.repeat(t.xstar[:, None, :], m, axis=1) if mm == "ideal" else t.boosts[mm]
        agree, overlap, share_err, excess = [], [], [], []
        for d in win:
            f = top8_sets(world, X[d])
            fi, Mi, sh_i = ideal[d]
            agree.append(np.mean(np.all(f == fi, axis=1)))                 # same top-8 set
            Mf = slot_mask(f)
            overlap.append(np.mean(np.sum(Mf & Mi, axis=1)) / 8.0)
            share_err.append(np.abs(shares(Mf) - sh_i))                    # (m, 4)
            F_star = cs.value_F(t.xstar[d], t.Theta[d])
            for i in range(m):
                excess.append((cs.value_F(X[d, i], t.Theta[d]) - F_star) / F_star)
        r = dict(agree=100.0 * np.mean(agree), overlap=100.0 * np.mean(overlap),
                 exposure=100.0 * np.mean(share_err), excess=1e6 * np.mean(excess))
        err = X[win] - t.xstar[win][:, None, :]
        r["rmse"] = np.sqrt(np.mean(np.sum(err ** 2, axis=2)))
        if mm == "ideal":
            r["forecast"] = 0.0
        elif mm in NO_FORECAST:
            r["forecast"] = np.nan
        else:
            u_hat = cs.ubar[None] + t.forecasts[mm][win - N]               # forecast interests
            r["forecast"] = np.sqrt(np.mean((u_hat - t.u[win]) ** 2))
        if mm in WITH_ID:
            A_hat, rho = t.estimates[mm]
            r["id"] = np.mean([np.linalg.norm(A_hat[i] - cs.A, "fro") for i in range(m)])
            r["unstable"] = np.mean(rho >= 1.0)
        else:
            r["id"] = r["unstable"] = np.nan
        out[mm] = r
    return out


@pytest.mark.parametrize("key", ["forecast", "agree"])
def test_forecast_and_agreement_match_a_recomputation(kpis, recomputed, key):
    bad = {}
    for mm in METHODS:
        a, b = kpis[0][mm][key], recomputed[mm][key]
        if np.isnan(b):
            ok = np.isnan(a)
        else:
            ok = a == pytest.approx(b, rel=1e-10, abs=1e-10)
        if not ok:
            bad[mm] = (a, b)
    assert not bad, "%s differs from the recomputation (kpi, mine): %s" % (key, bad)


@pytest.mark.parametrize("key", ["rmse", "overlap", "exposure", "excess", "id", "unstable"])
def test_other_metrics_match_a_recomputation(kpis, recomputed, key):
    bad = {}
    for mm in METHODS:
        a, b = kpis[0][mm][key], recomputed[mm][key]
        ok = np.isnan(a) if np.isnan(b) else a == pytest.approx(b, rel=1e-8, abs=1e-9)
        if not ok:
            bad[mm] = (a, b)
    assert not bad, "%s differs from the recomputation (kpi, mine): %s" % (key, bad)


def test_metrics_order_the_methods_sensibly(kpis):
    """Sanity of the showcase numbers: cooperation beats local estimation, which
    beats persistence; every method's excess cost is >= 0 (x* is the minimizer)."""
    k = kpis[0]
    for key in ("rmse", "forecast"):
        assert k["coop3"][key] < k["local"][key] < k["persistence"][key], key
    assert k["coop3"]["id"] < k["local"]["id"]
    assert k["coop3"]["agree"] > k["local"]["agree"] > k["persistence"]["agree"] > k["noboost"]["agree"]
    assert all(k[mm]["excess"] >= -1e-6 for mm in METHODS)


def full_days(daily, days, T):
    """daily arrays of a window evaluator, placed at their absolute days (NaN elsewhere)."""
    out = {}
    for mm, d in daily.items():
        out[mm] = {}
        for key, v in d.items():
            a = np.full((T,) + v.shape[1:], np.nan)
            a[days] = v
            out[mm][key] = a
    return out


def test_region_kpis_agree_with_the_network_metrics(world, showcase_trial, kpis):
    """region_kpis indexes daily by absolute day (as with FeedEvaluator(..., arange(T)) in run_demo.py)."""
    t = showcase_trial
    k, daily = kpis
    rows = region_kpis(world, t, full_days(daily, t.window, t.T))
    codes = [r["code"] for r in world.regions]
    for mm in ("coop3", "local", "persistence", "frozen"):
        rr = [r for r in rows if r["method"] == mm]
        assert [r["region"] for r in rr] == codes, mm
        assert np.mean([r["agree"] for r in rr]) == pytest.approx(k[mm]["agree"], rel=1e-12), mm
        assert np.mean([r["overlap"] for r in rr]) == pytest.approx(k[mm]["overlap"], rel=1e-12), mm
        assert np.sqrt(np.mean([r["boost_rmse"] ** 2 for r in rr])) == pytest.approx(k[mm]["rmse"], rel=1e-12), mm
        if mm in NO_FORECAST:
            assert all(np.isnan(r["forecast"]) for r in rr)
        else:
            assert np.sqrt(np.mean([r["forecast"] ** 2 for r in rr])) == pytest.approx(k[mm]["forecast"], rel=1e-12)
        if mm in WITH_ID:
            assert [r["id"] for r in rr] == [float(v) for v in t.id[mm]]


def test_region_kpis_accept_the_daily_metrics_of_a_window_evaluator(world, showcase_trial, kpis):
    """trial_kpis accepts (and the brief recommends, for speed) an evaluator over
    the window only; region_kpis should then work on the daily metrics it returns
    and give the same rows as with the daily metrics placed at absolute days."""
    t = showcase_trial
    k, daily = kpis
    want = region_kpis(world, t, full_days(daily, t.window, t.T))
    got = region_kpis(world, t, daily)
    assert len(got) == len(want)
    for g, w in zip(got, want):                       # NaN (no forecast / no estimate) equals NaN
        assert g.keys() == w.keys()
        assert all(g[c] == w[c] or (g[c] != g[c] and w[c] != w[c]) for c in w), (g, w)


def test_trial_kpis_rejects_an_evaluator_that_misses_the_window(world, showcase_trial):
    """kpi.trial_kpis raises ValueError('the feed evaluator must cover the RMSE window')
    when the evaluator does not cover t = N+50..T-1."""
    t = showcase_trial
    for days in (np.arange(0, t.N), np.arange(t.N + 50, t.T - 1), np.r_[np.arange(t.N + 50, 200), np.arange(201, t.T)]):
        with pytest.raises(ValueError, match="cover the RMSE window"):
            trial_kpis(world, t, FeedEvaluator(world, t.xstar, days), methods=["ideal"])
