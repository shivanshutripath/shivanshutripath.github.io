"""
End-to-end runs of what the other test files do not run: make_figures.py and
make_dashboard_data.py on a run with N = 30 (a horizon shorter than the
showcase's, so every day-dependent choice is exercised), and run_demo.py with a
non-default seed, whose verification must use that seed.
"""
import csv
import os
import subprocess
import sys

import numpy as np
import pytest

from rcdemo.feeds import region_scores, topk_mask

N = 30


def run(args, cwd, timeout=900):
    return subprocess.run([sys.executable] + [str(a) for a in args], capture_output=True, text=True,
                          timeout=timeout, cwd=str(cwd))


def rows(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


@pytest.fixture(scope="module")
def small_run(tmp_path_factory, demo_dir):
    """run_demo.py --N 30 into a tmp folder."""
    out = tmp_path_factory.mktemp("scripts") / "run_N30"
    p = run([os.path.join(demo_dir, "run_demo.py"), "--N", N, "--out", out], out.parent)
    assert p.returncode == 0, p.stderr[-3000:]
    return out


@pytest.fixture(scope="module")
def small_dashboard(tmp_path_factory, demo_dir):
    """make_dashboard_data.py --N 30 into a tmp folder, without a Monte Carlo summary."""
    base = tmp_path_factory.mktemp("dash")
    out = base / "dashboard_N30"
    p = run([os.path.join(demo_dir, "make_dashboard_data.py"), "--N", N, "--out", out, "--mc", base / "none.csv"], base)
    assert p.returncode == 0, p.stderr[-3000:]
    return out, p.stdout


def test_make_figures_on_another_run(small_run, demo_dir, tmp_path):
    figs = tmp_path / "figs"
    p = run([os.path.join(demo_dir, "make_figures.py"), "--src", small_run, "--out", figs], tmp_path)
    assert p.returncode == 0, p.stderr[-3000:]
    for name in ["network", "interests", "reconstruction", "boosts", "identification", "feeds", "example_feed"]:
        assert (figs / ("fig_%s.png" % name)).stat().st_size > 10_000, name
        assert (figs / ("fig_%s.pdf" % name)).exists(), name
    assert not (figs / "fig_montecarlo.png").exists()          # this run has no Monte Carlo summary
    first = (figs / "captions.txt").read_text(encoding="utf-8").splitlines()[0]
    assert "N = %d, trial 0" % N in first, first


def test_make_dashboard_data_with_a_short_horizon(small_dashboard):
    out, stdout = small_dashboard
    names = {f[:-4] for f in os.listdir(out) if f.endswith(".csv")}
    assert names == {"regions", "links", "catalog", "sessions", "reports", "interests", "identification",
                     "boost_error", "agreement", "mix", "shoppers", "strip", "feeds", "kpis", "kpis_region", "run"}
    assert "not compared" in stdout          # output/ holds the N = 100 run, which is not this trial
    run_kv = {r["key"]: r["value"] for r in rows(out / "run.csv")}
    assert run_kv["N"] == str(N) and run_kv["T"] == str(N + 200) and run_kv["window_start"] == str(N + 50)
    feeds = rows(out / "feeds.csv")
    days = {int(r["day"]) for r in feeds}
    assert {0, N // 4, N // 2, N - 1, N + 50, N + 100, N + 199} <= days and max(days) == N + 199
    groups = {}
    for r in feeds:
        groups.setdefault((r["region"], r["kind"], r["day"], r["method"]), []).append(int(r["rank"]))
    assert all(sorted(v) == list(range(1, 9)) for v in groups.values())
    assert {int(r["day"]) for r in rows(out / "sessions.csv")} == {0, N // 2, N - 1}


def test_contrast_shopper_follows_its_rule(small_dashboard, world, trials):
    """The contrast shopper of each region has the most days of the window on which
    local learning got the top 8 wrong and cooperative learning right (ties: the most
    days with local wrong), recomputed here over all 500 shoppers of the region; its
    day counts in shoppers.csv agree with strip.csv."""
    out, _ = small_dashboard
    t = trials.get(N, 0, sessions=True).trial             # the same generators as make_dashboard_data.py
    win = t.window
    shoppers = rows(out / "shoppers.csv")
    strip = rows(out / "strip.csv")
    uid_index = {u: k for k, u in enumerate(world.users["uid"])}
    for i, reg in enumerate(world.regions):
        idx = world.by_region[i]
        ideal = topk_mask(region_scores(world, i, t.xstar[win]))
        wrong = {m: (topk_mask(region_scores(world, i, t.boosts[m][win, i])) != ideal).any(axis=2)
                 for m in ("coop3", "local")}
        only_local = (wrong["local"] & ~wrong["coop3"]).sum(axis=0)
        local_days = wrong["local"].sum(axis=0)
        con = next(r for r in shoppers if r["region"] == reg["code"] and r["kind"] == "contrast")
        pos = int(np.flatnonzero(idx == uid_index[con["shopper"]])[0])
        best = only_local.max()
        assert only_local[pos] == best, (reg["code"], only_local[pos], best)
        assert local_days[pos] == local_days[only_local == best].max(), reg["code"]
        for r in (s for s in shoppers if s["region"] == reg["code"]):
            mine = [q for q in strip if q["region"] == r["region"] and q["kind"] == r["kind"] and int(q["day"]) >= win[0]]
            for m in ("coop3", "local", "frozen"):
                assert sum(q["same"] == "0" for q in mine if q["method"] == m) == int(r["days_%s_differs" % m])


def test_run_demo_with_another_seed(demo_dir, tmp_path):
    """--seed changes the instance and the trial; the verification must use the same seed."""
    out = tmp_path / "seed7"
    p = run([os.path.join(demo_dir, "run_demo.py"), "--N", N, "--seed", 7, "--no-sessions", "--out", out], tmp_path)
    assert p.returncode == 0, p.stderr[-3000:]
    lines = (out / "verification.txt").read_text().splitlines()
    assert "rng([7, 3, %d, 0])" % N in lines[0], lines[0]
    assert lines[-1].startswith("result: SAME TRIAL"), lines[-1]
