"""
End-to-end test of run_demo.py: ``run_demo.py --N 30 --out <tmp>`` as a
subprocess (trial 0, measurements from the session logs), then the files it
writes: names, headers, row counts, run_config.json, verification.txt, and the
values of the main tables against the same trial simulated in-process
(rng([2026, 3, 30, 0]) and the session stream rng([2026, 3, 9002, 30, 0])),
to the significant digits the CSVs are written with (6, 4 for the session and
shopper tables, 5 for feed_daily.csv).

The feed tables are checked against an independent computation: feed_daily.csv
on selected days against a shopper-by-shopper full sort, the product metrics of
kpis.csv and kpis_by_region.csv against the window t = N+50..N+199 of
feed_daily.csv (whose entries are fractions of 500 shoppers or 4,000 slots, so
5 significant digits store them exactly) and against the in-process trial, and
example_feeds.csv against a full sort of the example shopper's scores.

boosts.csv holds the boosts of the servers, i.e. the 11 methods of METHODS
other than "ideal" (whose boosts x*(t) are in optimum.csv): 11 * (N + 200) * 8
rows.  feed_daily.csv covers all 12 methods.  A second run with --no-sessions
(the paper's measurement model) must verify with every difference exactly 0.
"""
import csv
import json
import os
import subprocess
import sys

import numpy as np
import pytest

from rcdemo.kpi import LABEL, METHODS
from rcdemo.world import CATALOG, GENRES

N, TRIAL, T, K, M, S = 30, 0, 230, 3, 8, 100
GK = ["outdoor", "home", "tech"]
GK4 = GK + ["essentials"]
BOOST_METHODS = [mm for mm in METHODS if mm != "ideal"]                    # 11
FORECAST_METHODS = ["oracleKF", "oracleA", "centralized", "exact", "coop3", "coop1", "pooledLS", "local",
                    "persistence"]                                          # METHODS order
EXAMPLE_DAYS = [d for d in (0, 25, 50, 99, 100, 150, 200, 299) if d < T]

HEADERS = {
    "data/regions.csv": ["server", "code", "region", "data_center", "lat", "lon", "lambda", "W_self"]
                        + ["ubar_" + g for g in GK] + ["neighbors", "shoppers"],
    "data/backbone.csv": ["link", "from", "to", "kind", "weight"],
    "data/catalog.csv": ["product", "name", "genre", "boosted", "price_usd", "base_score"],
    "data/shoppers.csv": ["shopper", "region"] + ["affinity_" + g for g in GK] + ["favorite_genre", "exploration_feed"],
    "data/shopper_scores.csv": ["shopper"] + ["P%02d" % (j + 1) for j in range(32)],
    "data/sessions_explore.csv": ["day", "region", "session", "shopper"] + ["net_" + g for g in GK],
    "data/daily_reports.csv": ["day", "region", "sessions"] + ["uhat_" + g for g in GK] + ["ytilde_" + g for g in GK]
                              + ["boost_" + g for g in GK] + ["grad_" + g for g in GK],
    "data/interests.csv": ["day", "region"] + ["theta_" + g for g in GK] + ["u_" + g for g in GK]
                          + ["solo_boost_" + g for g in GK],
    "data/optimum.csv": ["day"] + ["xstar_" + g for g in GK] + ["U_" + g for g in GK],
    "data/window_estimates.csv": ["day", "region"] + ["theta_tilde_" + g for g in GK],
    "data/identification.csv": ["method", "region"] + ["a%d%d" % (a, b) for a in (1, 2, 3) for b in (1, 2, 3)]
                               + ["error_F", "rho_raw", "stable_raw"],
    "data/forecasts.csv": ["day", "method", "region"] + ["theta_hat_" + g for g in GK] + ["u_hat_" + g for g in GK],
    "data/boosts.csv": ["day", "method", "region"] + ["x_" + g for g in GK],
    "data/feed_daily.csv": ["day", "method", "region", "agree", "overlap"] + ["share_" + g for g in GK4]
                           + ["ideal_share_" + g for g in GK4],
    "data/example_feeds.csv": ["region", "shopper", "day", "method", "rank", "product", "name", "genre", "score"]
                              + ["x_" + g for g in GK],
    "kpis.csv": ["method", "label", "rmse", "forecast", "agree", "overlap", "exposure", "excess", "id", "unstable"],
    "kpis_by_region.csv": ["method", "region", "boost_rmse", "agree", "overlap", "forecast", "id"],
}
ROWS = {
    "data/regions.csv": M, "data/backbone.csv": 10, "data/catalog.csv": 32, "data/shoppers.csv": 4000,
    "data/shopper_scores.csv": 4000,
    "data/sessions_explore.csv": N * M * S,                  # 24,000
    "data/daily_reports.csv": N * M,                         # 240
    "data/interests.csv": T * M, "data/optimum.csv": T,
    "data/window_estimates.csv": (N - K + 1) * M,
    "data/identification.csv": 6 * M,                        # local, coop1, coop3, exact, pooledLS, true
    "data/forecasts.csv": len(FORECAST_METHODS) * (T - N) * M,
    "data/boosts.csv": len(BOOST_METHODS) * (N + 200) * M,   # 11 * 230 * 8 = 20,240
    "data/feed_daily.csv": len(METHODS) * T * M,             # 12 * 230 * 8
    "data/example_feeds.csv": M * len(EXAMPLE_DAYS) * 6 * 8,
    "kpis.csv": len(METHODS), "kpis_by_region.csv": 4 * M,
}
OTHER_FILES = ["summary.txt", "verification.txt", "run_config.json"]


@pytest.fixture(scope="module")
def demo_run(tmp_path_factory, demo_dir):
    out = tmp_path_factory.mktemp("run_demo_N30")
    proc = subprocess.run([sys.executable, os.path.join(demo_dir, "run_demo.py"), "--N", str(N), "--out", str(out)],
                          capture_output=True, text=True, timeout=900, cwd=str(out))
    return out, proc


@pytest.fixture(scope="module")
def tables(demo_run):
    out, proc = demo_run
    if proc.returncode != 0:
        pytest.fail("run_demo.py failed (exit %d):\n%s" % (proc.returncode, proc.stderr[-3000:]))
    tabs = {}
    for name in HEADERS:
        path = os.path.join(out, name)
        if os.path.exists(path):
            with open(path, newline="", encoding="utf-8") as f:
                rows = list(csv.reader(f))
            tabs[name] = (rows[0], rows[1:])
    return tabs


@pytest.fixture(scope="module")
def same(trials):
    """The trial of the run, simulated in-process."""
    run = trials.get(N, TRIAL, sessions=True)
    return run.trial, run.log


def col(table, name):
    header, rows = table
    j = header.index(name)
    return np.array([float(r[j]) if r[j] != "" else np.nan for r in rows])


def cols(table, names):
    return np.column_stack([col(table, nm) for nm in names])


def assert_sig(stored, value, nd, what):
    """stored = '%.<nd>g' % value up to the rounding of the last significant digit."""
    stored, value = np.asarray(stored, float), np.asarray(value, float)
    assert stored.shape == value.shape, (what, stored.shape, value.shape)
    mag = np.where(value == 0, 0.0, 10.0 ** (np.floor(np.log10(np.abs(np.where(value == 0, 1.0, value)))) - nd + 1))
    bad = np.abs(stored - value) > 0.5 * mag * (1 + 1e-9) + 1e-9
    assert not bad.any(), "%s: %d values differ beyond %d significant digits (first: %r vs %r)" % (
        what, bad.sum(), nd, stored[bad][0], value[bad][0])


def test_exit_code_and_verification(demo_run):
    out, proc = demo_run
    assert proc.returncode == 0, proc.stderr[-3000:]
    with open(os.path.join(out, "verification.txt")) as f:
        text = f.read()
    assert "SAME TRIAL" in text and "MISMATCH" not in text
    assert "result: SAME TRIAL" in text
    assert "N=%d, rng([2026, 3, %d, %d])" % (N, N, TRIAL) in text
    assert "computed from the session logs" in text
    assert "verification: same trial as experiments.run_trial" in proc.stdout


def test_expected_files_exist_with_their_headers(demo_run, tables):
    out, _ = demo_run
    for name in OTHER_FILES:
        assert os.path.isfile(os.path.join(out, name)), name
    missing = [name for name in HEADERS if name not in tables]
    assert not missing, missing
    for name, header in HEADERS.items():
        assert tables[name][0] == header, name


def test_row_counts(tables):
    got = {name: len(tables[name][1]) for name in ROWS}
    assert got == ROWS
    assert got["data/sessions_explore.csv"] == N * 8 * 100
    assert got["data/daily_reports.csv"] == N * 8
    assert got["data/boosts.csv"] == 11 * (N + 200) * 8


def test_method_layout(tables):
    def methods_of(name, column="method"):
        seen = []
        for v in tables[name][1]:
            m = v[tables[name][0].index(column)]
            if not seen or seen[-1] != m:
                seen.append(m)
        return seen
    assert methods_of("data/boosts.csv") == BOOST_METHODS
    assert methods_of("data/forecasts.csv") == FORECAST_METHODS
    assert methods_of("data/feed_daily.csv") == METHODS
    assert methods_of("data/identification.csv") == ["local", "coop1", "coop3", "exact", "pooledLS", "true"]
    for name, n in (("data/boosts.csv", T * M), ("data/forecasts.csv", (T - N) * M), ("data/feed_daily.csv", T * M)):
        meth = [r[1] for r in tables[name][1]]
        assert all(meth.count(mm) == n for mm in set(meth)), name


def test_run_config(demo_run):
    out, _ = demo_run
    with open(os.path.join(out, "run_config.json")) as f:
        cfg = json.load(f)
    assert (cfg["seed"], cfg["case_id"], cfg["N"], cfg["trial"], cfg["T"], cfg["k"]) == (2026, 3, N, TRIAL, T, K)
    assert cfg["taus"] == [3, 1]
    assert cfg["rmse_window"] == [N + 50, T - 1]
    assert cfg["trial_stream"] == [2026, 3, N, TRIAL]
    assert cfg["session_stream"] == [2026, 3, 9002, N, TRIAL]
    assert cfg["sessions_per_day"] == S
    assert np.allclose(cfg["session_sigma"], 3.0)
    assert cfg["feed_size"] == 8
    assert cfg["same_trial"] is True
    v = cfg["verification"]
    assert all(v[kk] <= 1e-8 for kk in v), v
    assert v["measurements"] <= 1e-12


def test_kpis_csv(tables, same):
    trial, _ = same
    header, rows = tables["kpis.csv"]
    assert [r[0] for r in rows] == METHODS
    assert [r[1] for r in rows] == [LABEL[mm] for mm in METHODS]
    k = {r[0]: dict(zip(header, r)) for r in rows}
    ideal = k["ideal"]
    assert [float(ideal[c]) for c in ("rmse", "forecast", "agree", "overlap", "exposure", "excess")] == [0, 0, 100, 100, 0, 0]
    assert ideal["id"] == "" and ideal["unstable"] == ""
    for mm in METHODS[1:]:
        assert_sig(float(k[mm]["rmse"]), trial.rmse[mm], 6, "kpis.csv rmse " + mm)
        if mm in trial.id:
            assert_sig(float(k[mm]["id"]), np.mean(trial.id[mm]), 6, "kpis.csv id " + mm)
            assert_sig(float(k[mm]["unstable"]), trial.unstable[mm], 6, "kpis.csv unstable " + mm)


def test_world_tables(world, tables):
    cs = world.cs
    reg = tables["data/regions.csv"]
    assert [r[1] for r in reg[1]] == [r["code"] for r in world.regions]
    assert_sig(col(reg, "lambda"), cs.varpi, 6, "lambda")
    assert_sig(cols(reg, ["ubar_" + g for g in GK]), cs.ubar, 6, "ubar")
    assert_sig(col(reg, "W_self"), np.diag(cs.W), 6, "W_self")
    assert [int(v) for v in col(reg, "shoppers")] == [500] * M
    bb = tables["data/backbone.csv"]
    codes = [r["code"] for r in world.regions]
    assert [(r[1], r[2]) for r in bb[1]] == [(codes[i], codes[j]) for i, j in world.edges]
    assert sorted((r[1], r[2]) for r in bb[1] if r[3] == "chord") == [("MEA", "OC"), ("NAM", "SEA")]
    ca = tables["data/catalog.csv"]
    assert [tuple(r[:4]) for r in ca[1]] == [(c[0], c[1], GENRES[c[2]], "yes" if c[2] < 3 else "no") for c in CATALOG]
    assert_sig(cols(ca, ["price_usd", "base_score"]), np.array([[c[3], c[4]] for c in CATALOG]), 6, "catalog")
    sh = tables["data/shoppers.csv"]
    U = world.users
    assert [r[0] for r in sh[1]] == list(U["uid"])
    assert [r[1] for r in sh[1]] == [codes[i] for i in U["region"]]
    assert_sig(cols(sh, ["affinity_" + g for g in GK]), U["affinity"], 4, "affinities")
    assert [r[sh[0].index("favorite_genre")] for r in sh[1]] == [GENRES[g] for g in np.argmax(U["affinity"], axis=1)]
    feeds = [r[-1].split() for r in sh[1]]
    assert all(len(f) == 12 for f in feeds)
    assert feeds == [list(world.products["pid"][e]) for e in world.explore_feed]
    sc = tables["data/shopper_scores.csv"]
    assert_sig(np.array([[float(v) for v in r[1:]] for r in sc[1]]), world.users["base_scores"], 4, "base scores")


def test_sessions_and_daily_reports(world, tables, same):
    trial, log = same
    codes = [r["code"] for r in world.regions]
    uid = world.users["uid"]
    se = tables["data/sessions_explore.csv"]
    rows = se[1]
    k = 0
    for t in range(N):
        for i in range(M):
            for s in range(S):
                r = rows[k]
                assert (int(r[0]), r[1], r[2]) == (t, codes[i], "%s-%03d-%03d" % (codes[i], t, s + 1)), k
                assert r[3] == uid[log.users[t, i, s]], k
                assert r[3].startswith(codes[i] + "-"), k        # the shopper lives in the session's region
                k += 1
    net = cols(se, ["net_" + g for g in GK]).reshape(N, M, S, 3)
    assert_sig(net, log.scores, 4, "session scores")
    shoppers = np.array([r[3] for r in rows]).reshape(N, M, S)
    assert all(len(set(shoppers[t, i])) == S for t in range(N) for i in range(M))
    dr = tables["data/daily_reports.csv"]
    assert [(int(r[0]), r[1]) for r in dr[1]] == [(t, codes[i]) for t in range(N) for i in range(M)]
    assert np.all(col(dr, "sessions") == S)
    uhat = cols(dr, ["uhat_" + g for g in GK]).reshape(N, M, 3)
    assert_sig(uhat, log.u_hat, 6, "uhat")
    assert_sig(cols(dr, ["ytilde_" + g for g in GK]).reshape(N, M, 3), trial.Y_used.transpose(1, 0, 2), 6, "ytilde")
    assert_sig(cols(dr, ["boost_" + g for g in GK]).reshape(N, M, 3), trial.X_data, 6, "boosts during collection")
    assert_sig(cols(dr, ["grad_" + g for g in GK]).reshape(N, M, 3), trial.G_data, 6, "gradients")
    # a reader of the CSVs can recompute each server's daily average (scores have 4 digits, |score| < 100)
    assert np.max(np.abs(net.mean(axis=2) - uhat)) <= 5e-3
    # and its measurement ytilde = C_i(0)(uhat - ubar_i) = -(uhat - ubar_i) / 2
    ytilde = cols(dr, ["ytilde_" + g for g in GK]).reshape(N, M, 3)
    assert np.all(np.abs(ytilde + 0.5 * (uhat - world.cs.ubar[None])) <= 1e-5 * (1.0 + np.abs(uhat)))


def test_trajectories(world, tables, same):
    trial, _ = same
    op = tables["data/optimum.csv"]
    assert_sig(cols(op, ["xstar_" + g for g in GK]), trial.xstar, 6, "xstar")
    assert_sig(cols(op, ["U_" + g for g in GK]), trial.u.sum(axis=1), 6, "U")
    it = tables["data/interests.csv"]
    assert_sig(cols(it, ["theta_" + g for g in GK]).reshape(T, M, 3), trial.Theta, 6, "theta")
    assert_sig(cols(it, ["u_" + g for g in GK]).reshape(T, M, 3), trial.u, 6, "u")
    we = tables["data/window_estimates.csv"]
    assert_sig(cols(we, ["theta_tilde_" + g for g in GK]).reshape(N - K + 1, M, 3), trial.th.transpose(1, 0, 2), 6,
               "window estimates")
    bo = tables["data/boosts.csv"]
    X = cols(bo, ["x_" + g for g in GK]).reshape(len(BOOST_METHODS), T, M, 3)
    for a, mm in enumerate(BOOST_METHODS):
        assert_sig(X[a], trial.boosts[mm], 6, "boosts " + mm)
    fc = tables["data/forecasts.csv"]
    F = cols(fc, ["theta_hat_" + g for g in GK]).reshape(len(FORECAST_METHODS), T - N, M, 3)
    for a, mm in enumerate(FORECAST_METHODS):
        assert_sig(F[a], trial.forecasts[mm], 6, "forecasts " + mm)
    idt = tables["data/identification.csv"]
    Ah = cols(idt, ["a%d%d" % (a, b) for a in (1, 2, 3) for b in (1, 2, 3)]).reshape(6, M, 3, 3)
    for a, mm in enumerate(["local", "coop1", "coop3", "exact", "pooledLS"]):
        assert_sig(Ah[a], trial.estimates[mm][0], 6, "A_hat " + mm)
    assert_sig(Ah[5], np.repeat(world.cs.A[None], M, axis=0), 6, "true A")


def test_feed_daily(tables):
    fd = tables["data/feed_daily.csv"]
    meth = [r[1] for r in fd[1]]
    agree, overlap = col(fd, "agree"), col(fd, "overlap")
    share = cols(fd, ["share_" + g for g in GK4])
    ideal_share = cols(fd, ["ideal_share_" + g for g in GK4])
    assert np.all((0 <= agree) & (agree <= 1)) and np.all((0 <= overlap) & (overlap <= 1))
    assert np.allclose(share.sum(axis=1), 1.0, atol=5e-5) and np.allclose(ideal_share.sum(axis=1), 1.0, atol=5e-5)
    is_ideal = np.array(meth) == "ideal"
    assert np.all(agree[is_ideal] == 1) and np.all(overlap[is_ideal] == 1)
    assert np.array_equal(share[is_ideal], ideal_share[is_ideal])
    # the ideal shares are the same for every method on a given (day, region)
    per = ideal_share.reshape(len(METHODS), T * M, 4)
    assert np.all(per == per[:1])


# ----------------------------------------------------------------------------
# the feed tables against an independent computation
# ----------------------------------------------------------------------------
WINDOW = np.arange(N + 50, N + 200)                 # the paper's RMSE window [N+50, N+200)
REGION_METHODS = ["coop3", "local", "persistence", "frozen"]


@pytest.fixture(scope="module")
def feed_daily(world, tables):
    """feed_daily.csv as arrays in (method, day, region) order: agree, overlap
    (12, T, M), share, ideal_share (12, T, M, 4)."""
    fd = tables["data/feed_daily.csv"]
    codes = [r["code"] for r in world.regions]
    want = [(str(t), mm, c) for mm in METHODS for t in range(T) for c in codes]
    assert [(r[0], r[1], r[2]) for r in fd[1]] == want
    nm = len(METHODS)
    return dict(agree=col(fd, "agree").reshape(nm, T, M), overlap=col(fd, "overlap").reshape(nm, T, M),
                share=cols(fd, ["share_" + g for g in GK4]).reshape(nm, T, M, 4),
                ideal_share=cols(fd, ["ideal_share_" + g for g in GK4]).reshape(nm, T, M, 4))


def feed_masks(world, Xday):
    """(U, 32) masks of the top-8 products of every shopper by a full sort, when
    server i's boosts Xday[i] (M, 3) rank the shoppers of region i."""
    genre, region = world.products["genre"], world.users["region"]
    shift = np.zeros((M, 4))
    shift[:, :3] = Xday
    order = np.argsort(-(world.users["base_scores"] + shift[region][:, genre]), axis=1)
    mask = np.zeros(order.shape, dtype=bool)
    mask[np.arange(len(order))[:, None], order[:, :8]] = True
    return mask


def test_feed_daily_against_a_shopper_by_shopper_recomputation(world, feed_daily, same):
    """Every method on selected days (data phase, switch to forecasts, window):
    per region, the fraction of shoppers whose top-8 set is the ideal one, the
    mean overlap / 8, and the genre shares of the slots, with shopper s of region
    i ranked by server i's boosts x_i(t) and the ideal feed by x*(t)."""
    trial, _ = same
    region, genre = world.users["region"], world.products["genre"]
    onehot = (genre[:, None] == np.arange(4)[None, :]).astype(int)
    for t in (0, N - 1, N, N + 49, N + 50, T - 1):
        ideal = feed_masks(world, np.repeat(trial.xstar[t][None], M, axis=0))
        for a, mm in enumerate(METHODS):
            X = np.repeat(trial.xstar[t][None], M, axis=0) if mm == "ideal" else trial.boosts[mm][t]
            mk = feed_masks(world, X)
            same_set = np.all(mk == ideal, axis=1)
            common = np.sum(mk & ideal, axis=1)
            for i in range(M):
                sel = region == i
                n_i = sel.sum()
                assert feed_daily["agree"][a, t, i] == pytest.approx(same_set[sel].mean(), abs=1e-12), (t, mm, i)
                assert feed_daily["overlap"][a, t, i] == pytest.approx(common[sel].sum() / (8.0 * n_i), abs=1e-12)
                share = (mk[sel].astype(int) @ onehot).sum(axis=0) / (8.0 * n_i)
                share_id = (ideal[sel].astype(int) @ onehot).sum(axis=0) / (8.0 * n_i)
                assert np.allclose(feed_daily["share"][a, t, i], share, rtol=0, atol=1e-12), (t, mm, i)
                assert np.allclose(feed_daily["ideal_share"][a, t, i], share_id, rtol=0, atol=1e-12), (t, mm, i)


def test_kpis_csv_product_metrics(world, tables, feed_daily, same):
    """kpis.csv over the window: agree, overlap and exposure (mean absolute error
    of the 4 genre shares, pp) are the window means of feed_daily.csv; forecast is
    the RMSE of ubar_i + theta_hat_i(t) against u_i(t); excess is the mean over
    servers and days of (F(x_i(t)) - F(x*(t))) / F(x*(t)) in ppm, with F the
    paper's value_F."""
    trial, _ = same
    cs = world.cs
    header, rows = tables["kpis.csv"]
    k = {r[0]: dict(zip(header, r)) for r in rows}
    F_star = np.array([cs.value_F(trial.xstar[d], trial.Theta[d]) for d in WINDOW])
    assert np.all(F_star > 0)
    for a, mm in enumerate(METHODS):
        r = k[mm]
        fd = {key: v[a, WINDOW] for key, v in feed_daily.items()}
        assert_sig(float(r["agree"]), 100.0 * fd["agree"].mean(), 6, "agree " + mm)
        assert_sig(float(r["overlap"]), 100.0 * fd["overlap"].mean(), 6, "overlap " + mm)
        assert_sig(float(r["exposure"]), 100.0 * np.abs(fd["share"] - fd["ideal_share"]).mean(), 6, "exposure " + mm)
        if mm == "ideal":
            assert float(r["forecast"]) == 0.0
        elif mm in FORECAST_METHODS:
            err = cs.ubar[None] + trial.forecasts[mm][WINDOW - N] - trial.u[WINDOW]
            assert_sig(float(r["forecast"]), np.sqrt(np.mean(err ** 2)), 6, "forecast " + mm)
        else:
            assert r["forecast"] == "", mm
        X = np.repeat(trial.xstar[:, None, :], M, axis=1) if mm == "ideal" else trial.boosts[mm]
        rel = [(cs.value_F(X[d, i], trial.Theta[d]) - F_star[j]) / F_star[j] for j, d in enumerate(WINDOW)
               for i in range(M)]
        assert_sig(float(r["excess"]), 1e6 * np.mean(rel), 6, "excess " + mm)


def test_kpis_by_region_csv(world, tables, feed_daily, same):
    """kpis_by_region.csv: per method and region, the boost RMSE, agreement and
    overlap (window means of feed_daily.csv), forecast RMSE and ||A_hat_i - A||_F."""
    trial, _ = same
    codes = [r["code"] for r in world.regions]
    header, rows = tables["kpis_by_region.csv"]
    assert [(r[0], r[1]) for r in rows] == [(mm, c) for mm in REGION_METHODS for c in codes]
    for r in rows:
        d = dict(zip(header, r))
        mm, i = d["method"], codes.index(d["region"])
        a = METHODS.index(mm)
        err = trial.boosts[mm][WINDOW, i] - trial.xstar[WINDOW]
        assert_sig(float(d["boost_rmse"]), np.sqrt(np.mean(np.sum(err ** 2, axis=1))), 6, "boost_rmse")
        assert_sig(float(d["agree"]), 100.0 * feed_daily["agree"][a, WINDOW, i].mean(), 6, "agree")
        assert_sig(float(d["overlap"]), 100.0 * feed_daily["overlap"][a, WINDOW, i].mean(), 6, "overlap")
        if mm in FORECAST_METHODS:
            e = trial.forecasts[mm][WINDOW - N, i] - trial.Theta[WINDOW, i]
            assert_sig(float(d["forecast"]), np.sqrt(np.mean(e ** 2)), 6, "forecast")
        else:
            assert d["forecast"] == ""
        if mm in trial.id:
            assert_sig(float(d["id"]), trial.id[mm][i], 6, "id")
        else:
            assert d["id"] == ""


def test_example_feeds(world, demo_run, tables, same):
    """example_feeds.csv: for every region, the shopper whose affinities are
    closest to the region's mean affinity; on every example day and for every
    example method, the 8 products of the first screen, best first, by a full sort
    of base score + boost, under x*(t) (ideal) or the boosts x_i(t) of the
    shopper's server."""
    trial, _ = same
    out, _ = demo_run
    P, U = world.products, world.users
    codes = [r["code"] for r in world.regions]
    rows = tables["data/example_feeds.csv"][1]
    k, chosen = 0, {}
    for i in range(M):
        idx = world.by_region[i]
        a = U["affinity"][idx]
        s = int(idx[np.argmin(np.sum((a - a.mean(axis=0)) ** 2, axis=1))])
        chosen[codes[i]] = U["uid"][s]
        for t in EXAMPLE_DAYS:
            for mm in ["ideal", "coop3", "local", "persistence", "frozen", "noboost"]:
                x = trial.xstar[t] if mm == "ideal" else trial.boosts[mm][t, i]
                sc = U["base_scores"][s] + np.array([x[g] if g < 3 else 0.0 for g in P["genre"]])
                for rank, j in enumerate(sorted(range(32), key=lambda jj: -sc[jj])[:8]):
                    r = rows[k]
                    k += 1
                    assert r[:8] == [codes[i], U["uid"][s], str(t), mm, str(rank + 1), P["pid"][j], P["name"][j],
                                     GENRES[P["genre"][j]]], (r, t, mm)
                    assert_sig(float(r[8]), sc[j], 4, "score")
                    assert_sig(np.array([float(v) for v in r[9:12]]), x, 4, "boosts")
    assert k == len(rows)
    with open(os.path.join(out, "run_config.json")) as f:
        assert json.load(f)["example_shoppers"] == chosen


def test_each_regions_own_optimum(world, tables, same):
    """interests.csv solo_boost_*: argmin_x f_i(x, theta_i(t)), per genre the unique
    root of lambda_i x = u_il sigma(-x), which lies in [min(0, u/lambda), max(0,
    u/lambda)] (the residual is -u/2 at 0 and u sigma(u/lambda) at u/lambda);
    found here by bisection."""
    trial, _ = same
    u = trial.u
    lam = np.broadcast_to(world.cs.varpi[None, :, None], u.shape)
    lo, hi = np.minimum(0.0, u / lam), np.maximum(0.0, u / lam)
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        up = lam * mid - u / (1.0 + np.exp(mid)) > 0
        hi, lo = np.where(up, mid, hi), np.where(up, lo, mid)
    solo = cols(tables["data/interests.csv"], ["solo_boost_" + g for g in GK]).reshape(T, M, 3)
    assert_sig(solo, 0.5 * (lo + hi), 6, "solo boosts")


def test_no_sessions_run_is_bit_identical(tmp_path, demo_dir, trials):
    """run_demo.py --no-sessions: the servers use the paper's measurement model, so the
    verification is exact (every difference 0), and no session table is written."""
    out = tmp_path / "run_demo_N30_plain"
    proc = subprocess.run([sys.executable, os.path.join(demo_dir, "run_demo.py"), "--N", str(N), "--out", str(out),
                           "--no-sessions"], capture_output=True, text=True, timeout=900, cwd=str(tmp_path))
    assert proc.returncode == 0, proc.stderr[-3000:]
    with open(out / "verification.txt") as f:
        lines = f.read().splitlines()
    assert "the servers' measurements are the paper's" in lines[1]
    values = dict(ln.split() for ln in lines[2:-1])
    assert set(values) == {"rmse", "rmse_centralized", "id", "theta", "xstar", "window", "iterates_data",
                           "iterates_coop", "iterates_local", "measurements"}
    assert all(float(v) == 0.0 for v in values.values()), values
    assert lines[-1].startswith("result: SAME TRIAL")
    assert not (out / "data" / "sessions_explore.csv").exists()
    with open(out / "run_config.json") as f:
        cfg = json.load(f)
    assert cfg["sessions_per_day"] == 0 and cfg["session_sigma"] is None and cfg["session_stream"] is None
    with open(out / "data" / "daily_reports.csv", newline="") as f:
        dr = list(csv.reader(f))
    table = (dr[0], dr[1:])
    assert len(table[1]) == N * M
    assert np.all(col(table, "sessions") == 0)
    assert np.all(np.isnan(cols(table, ["uhat_" + g for g in GK])))
    plain = trials.get(N, TRIAL, sessions=False).trial
    assert_sig(cols(table, ["ytilde_" + g for g in GK]).reshape(N, M, 3), plain.Y.transpose(1, 0, 2), 6, "ytilde")
