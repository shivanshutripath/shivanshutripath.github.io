"""
make_world(): the paper's instance of case study (B) and its concrete layer.

The instance is checked against the paper (Section 5.1 and Table 1: m = 8,
n = p = 3, ring + chords (1,5), (3,7) with Metropolis weights and contraction
factor 0.68, A = blkdiag(0.98 Rot(0.25), 0.95), Q = 0.02^2 I, R = 0.15^2 I,
P0 = 1.5^2 I, lambda_i in [0.4, 0.8], ubar_il in [1, 3], exploration x^e = 0,
k = 3, alpha = 0.25) and against an independent draw of the known constants
from the instance generator rng([2026, 3]) of experiments.py.  The backbone
and its weights are rebuilt here from scratch.
"""
import numpy as np

from rcdemo.world import (BOOSTED, CATALOG, EXPLORE_PER_GENRE, FEED_SIZE, GENRES, REGIONS, boost_vector,
                          make_world)

M = 8
RING_CHORDS_1BASED = [(1, 5), (3, 7)]


def backbone_adjacency():
    adj = np.zeros((M, M), dtype=bool)
    for i in range(M):
        adj[i, (i + 1) % M] = adj[(i + 1) % M, i] = True
    for a, b in RING_CHORDS_1BASED:
        adj[a - 1, b - 1] = adj[b - 1, a - 1] = True
    return adj


def metropolis_weights(adj):
    deg = adj.sum(axis=1)
    W = np.zeros(adj.shape)
    for i, j in zip(*np.nonzero(adj)):
        W[i, j] = 1.0 / (1.0 + max(deg[i], deg[j]))
    W[np.diag_indices(len(adj))] = 1.0 - W.sum(axis=1)
    return W


def test_instance_constants_are_the_papers(world):
    cs = world.cs
    assert (cs.m, cs.n, cs.p) == (8, 3, 3)
    th = 0.25
    A = np.zeros((3, 3))
    A[:2, :2] = 0.98 * np.array([[np.cos(th), -np.sin(th)], [np.sin(th), np.cos(th)]])
    A[2, 2] = 0.95
    assert np.allclose(cs.A, A, rtol=0, atol=1e-15)
    assert np.allclose(cs.Q, 0.02 ** 2 * np.eye(3), rtol=0, atol=1e-15)
    assert np.allclose(cs.R, 0.15 ** 2 * np.eye(3), rtol=0, atol=1e-15)
    assert np.allclose(cs.P0, 1.5 ** 2 * np.eye(3), rtol=0, atol=1e-15)
    assert cs.k == 3 and cs.alpha == 0.25
    for i in range(cs.m):
        assert np.array_equal(cs.explore(i, 7, np.ones(3)), np.zeros(3))          # x^e = 0
        assert np.allclose(cs.C(i, np.zeros(3)), -0.5 * np.eye(3))                 # C_i(0) = -I/2
    # the known constants: drawn once by experiments.Recommendation from rng([2026, 3])
    g = np.random.default_rng([2026, 3])
    varpi = g.uniform(0.4, 0.8, size=8)
    ubar = g.uniform(1.0, 3.0, size=(8, 3))
    assert np.array_equal(cs.varpi, varpi)
    assert np.array_equal(cs.ubar, ubar)
    assert world.seed == 2026


def test_backbone_is_the_ring_with_chords(world):
    adj = backbone_adjacency()
    want = [(i, j) for i in range(M) for j in range(i + 1, M) if adj[i, j]]
    assert sorted(world.edges) == want
    assert len(world.edges) == 10
    for i, r in enumerate(world.regions):
        assert sorted(r["neighbors"]) == list(np.flatnonzero(adj[i])), i
        assert len(r["neighbors"]) in (2, 3)          # "each server exchanges messages only with two or three peers"


def test_weights_are_metropolis(world):
    W = world.cs.W
    assert np.allclose(W, metropolis_weights(backbone_adjacency()), rtol=0, atol=1e-15)
    assert np.array_equal(W, W.T)
    assert np.allclose(W.sum(axis=0), 1.0) and np.allclose(W.sum(axis=1), 1.0)
    edges = set(world.edges) | {(j, i) for i, j in world.edges}
    for i in range(M):
        for j in range(M):
            if i != j:
                assert (W[i, j] != 0) == ((i, j) in edges), (i, j)
    sigma = np.linalg.norm(W - np.ones((M, M)) / M, 2)
    assert round(sigma, 2) == 0.68                    # Table 1


def test_regions_carry_lambda_and_ubar(world):
    cs = world.cs
    assert [r["code"] for r in world.regions] == ["NAM", "EU", "MEA", "SA", "SEA", "EA", "OC", "LA"]
    assert [r["code"] for r in world.regions] == [r[0] for r in REGIONS]
    for i, r in enumerate(world.regions):
        assert r["index"] == i
        assert r["lam"] == cs.varpi[i]
        assert np.array_equal(r["ubar"], cs.ubar[i])
        assert 0.4 <= r["lam"] <= 0.8
        assert np.all((1.0 <= r["ubar"]) & (r["ubar"] <= 3.0))
    # the regions hold copies of ubar_i, not views of the instance's array
    assert not any(np.shares_memory(r["ubar"], cs.ubar) for r in world.regions)


def test_catalog_has_32_unique_products_8_per_genre(world):
    P = world.products
    assert len(CATALOG) == 32 and len(P["pid"]) == 32
    assert len(set(P["pid"])) == 32
    assert len(set(P["name"])) == 32
    assert len(GENRES) == 4 and BOOSTED == 3
    assert np.array_equal(np.bincount(P["genre"], minlength=4), [8, 8, 8, 8])
    assert np.all(P["price"] > 0)
    assert FEED_SIZE == 8


def test_500_shoppers_per_region(world):
    U = world.users
    assert len(U["uid"]) == 4000 and len(set(U["uid"])) == 4000
    assert np.array_equal(np.bincount(U["region"], minlength=M), [500] * M)
    allidx = np.concatenate(world.by_region)
    assert np.array_equal(np.sort(allidx), np.arange(4000))
    for i in range(M):
        idx = world.by_region[i]
        assert len(idx) == 500
        assert np.all(U["region"][idx] == i)
        code = world.regions[i]["code"]
        assert all(u.startswith(code + "-") for u in U["uid"][idx])
    assert U["affinity"].shape == (4000, 3)
    assert U["taste"].shape == U["base_scores"].shape == (4000, 32)


def test_base_scores_decompose(world):
    """score_{s,j}(0) = b_j + a_{s,g(j)} + e_{s,j} (boosted genres), b_j + e_{s,j} (essentials)."""
    U, P = world.users, world.products
    want = P["base"][None, :] + U["taste"]
    for j in range(32):
        g = P["genre"][j]
        if g < BOOSTED:
            want[:, j] = want[:, j] + U["affinity"][:, g]
    assert np.allclose(U["base_scores"], want, rtol=0, atol=1e-14)


def test_affinities_are_centered_on_the_regional_interests(world):
    """a_s = 0.5 (ubar_i - mean_l ubar_il) + 0.4 z: the region means estimate the tilt."""
    cs = world.cs
    tilt = 0.5 * (cs.ubar - cs.ubar.mean(axis=1, keepdims=True))
    for i in range(M):
        a = world.users["affinity"][world.by_region[i]]
        assert np.all(np.abs(a.mean(axis=0) - tilt[i]) <= 5 * 0.4 / np.sqrt(len(a))), i


def test_boost_vector(world):
    g = world.products["genre"]
    x = np.array([0.7, -1.2, 2.5])
    v = boost_vector(world, x)
    assert v.shape == (32,)
    for j in range(32):
        assert v[j] == (x[g[j]] if g[j] < BOOSTED else 0.0)
    X = np.random.default_rng(0).normal(size=(5, 8, 3))
    V = boost_vector(world, X)
    assert V.shape == (5, 8, 32)
    assert np.array_equal(V[2, 3], boost_vector(world, X[2, 3]))


def test_exploration_feed_is_the_best_3_of_every_genre_at_x0(world):
    E = world.explore_feed
    g = world.products["genre"]
    assert EXPLORE_PER_GENRE == 3
    assert E.shape == (4000, 12)
    scores0 = world.users["base_scores"] + boost_vector(world, np.zeros(3))
    for s in range(4000):
        for k in range(4):
            block = list(E[s, 3 * k:3 * k + 3])
            assert all(g[j] == k for j in block), (s, k)
            cand = [j for j in range(32) if g[j] == k]
            best = sorted(cand, key=lambda j: -scores0[s, j])[:3]
            assert block == best, (s, k)


def test_make_world_is_deterministic(world):
    w2 = make_world()
    for key in ("affinity", "taste", "base_scores", "region"):
        assert np.array_equal(w2.users[key], world.users[key]), key
    assert np.array_equal(w2.explore_feed, world.explore_feed)
    # the shoppers have their own stream: the instance does not depend on them
    w3 = make_world(users_per_region=10)
    assert np.array_equal(w3.cs.varpi, world.cs.varpi) and np.array_equal(w3.cs.ubar, world.cs.ubar)
    assert np.array_equal(w3.cs.W, world.cs.W)
    assert len(w3.users["uid"]) == 80
