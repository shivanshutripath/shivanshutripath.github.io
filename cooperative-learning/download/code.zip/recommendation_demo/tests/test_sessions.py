"""
The exploration session logs of SessionLog (showcase trial: N = 100, trial 0,
8 regions, S = 100 sessions per region and day, 3 boosted genres).

SessionLog draws the S scores of (day t, region i) conditionally on their mean,
which it sets to u_i(t) + C_i(0)^{-1} w_m,i(t) with the paper's measurement noise
w_m,i(t) ~ N(0, 0.15^2 I) and C_i(0) = -I/2.  The claim is that, in distribution,
the per-session scores are i.i.d. N(u_i(t), sigma^2 I) with sigma = 0.15 sqrt(S)
/ |C_ll(0)| = 3, so that the server's measurement ytilde_i(t) = C_i(0)(mean -
ubar_i) is the paper's.  The statistical checks below use the standardized
residuals z = (score - u_i(t)) / sigma, which must be i.i.d. N(0, 1); every
tolerance is Z_TOL standard errors of the statistic for the sample size at hand
(a false alarm has probability ~1e-6 per check), and the KS test is run at 1%.
"""
import numpy as np
import pytest
from scipy import stats

from rcdemo.simulate import SESSIONS_PER_DAY, session_sigma

Z_TOL = 5.0           # tolerance, in standard errors of the statistic
S = 100               # sessions per region and day (run_demo.py)


@pytest.fixture(scope="module")
def z(showcase):
    """Standardized residuals (N, m, S, n)."""
    trial, log = showcase
    return (log.scores - trial.u[:trial.N, :, None, :]) / log.sigma


def test_sigma_is_3_for_100_sessions(world, session_log):
    assert SESSIONS_PER_DAY == S == session_log.S
    assert np.allclose(session_sigma(world.cs, S), 3.0, rtol=0, atol=1e-12)
    assert np.allclose(session_log.sigma, 3.0, rtol=0, atol=1e-12)
    for s in (1, 25, 400):     # sigma = 0.15 sqrt(S) / 0.5
        assert np.allclose(session_sigma(world.cs, s), 0.3 * np.sqrt(s), rtol=1e-12)


def test_logs_have_the_documented_shapes(showcase):
    trial, log = showcase
    N, m, n = trial.N, 8, 3
    assert log.users.shape == (N, m, S)
    assert log.scores.shape == (N, m, S, n)
    assert log.u_hat.shape == (N, m, n)
    assert log.y.shape == (m, N, n)


def test_residuals_have_mean_0_and_variance_1(z):
    v = z.ravel()
    n = v.size                                       # 240,000
    assert abs(v.mean()) <= Z_TOL / np.sqrt(n)
    assert abs(v.var() - 1.0) <= Z_TOL * np.sqrt(2.0 / n)
    # also per genre (n / 3 each)
    for g in range(3):
        vg = z[..., g].ravel()
        assert abs(vg.mean()) <= Z_TOL / np.sqrt(vg.size), g
        assert abs(vg.var() - 1.0) <= Z_TOL * np.sqrt(2.0 / vg.size), g


def test_residuals_pass_a_ks_test(z):
    res = stats.kstest(z.ravel(), "norm")
    assert res.pvalue > 0.01, res


def test_no_correlation_across_genres(z):
    flat = z.reshape(-1, 3)                          # one row per session
    r = np.corrcoef(flat.T)
    off = r[~np.eye(3, dtype=bool)]
    assert np.max(np.abs(off)) <= Z_TOL / np.sqrt(flat.shape[0]), r


def test_no_correlation_between_sessions_of_the_same_day(z):
    """Mean over the (day, region, genre) groups of the average product of the
    residuals of two distinct sessions, sum_{s != s'} z_s z_s' / (S (S - 1)).
    Under i.i.d. N(0, 1) it has mean 0 and variance 2 / (S (S - 1)) per group.
    The deviations from the daily mean alone (no C^{-1} w term) would give
    -1 / S = -0.01, 34 standard errors (their correlation is -1 / (S - 1))."""
    s_ = z.shape[2]
    tot, sq = z.sum(axis=2), (z ** 2).sum(axis=2)    # (N, m, n)
    q = (tot ** 2 - sq) / (s_ * (s_ - 1))
    se = np.sqrt(2.0 / (s_ * (s_ - 1) * q.size))
    assert abs(q.mean()) <= Z_TOL * se, (q.mean(), se)
    # and between consecutive sessions, as a plain correlation coefficient
    a, b = z[:, :, :-1, :].ravel(), z[:, :, 1:, :].ravel()
    assert abs(np.corrcoef(a, b)[0, 1]) <= Z_TOL / np.sqrt(a.size)


def test_daily_means_have_noise_std_0_3(showcase):
    trial, log = showcase
    e = (log.u_hat - trial.u[:trial.N]).ravel()      # u_hat_i(t) - u_i(t) = C^{-1} w_m,i(t)
    sd = 3.0 / np.sqrt(S)                            # 0.3
    assert abs(e.std() - sd) <= Z_TOL * sd / np.sqrt(2 * e.size)
    assert abs(e.mean()) <= Z_TOL * sd / np.sqrt(e.size)
    assert stats.kstest(e / sd, "norm").pvalue > 0.01


def test_measurement_noise_std_0_15(showcase):
    trial, log = showcase
    N = trial.N
    C0 = -0.5 * np.eye(3)
    noise = log.y - np.einsum("ab,itb->ita", C0, trial.Theta[:N].transpose(1, 0, 2))   # (m, N, n)
    assert np.allclose(trial.Cs, C0)
    sd = 0.15
    assert abs(noise.std() - sd) <= Z_TOL * sd / np.sqrt(2 * noise.size)
    assert abs(noise.mean()) <= Z_TOL * sd / np.sqrt(noise.size)
    # ... and it is the paper's draw w_m,i(t)
    assert np.max(np.abs(noise - trial.Wy.transpose(1, 0, 2))) <= 1e-12


def test_servers_compute_their_measurement_from_the_logs(world, showcase):
    trial, log = showcase
    assert np.max(np.abs(log.u_hat - log.scores.mean(axis=2))) <= 1e-12
    want = -0.5 * (log.u_hat - world.cs.ubar[None]).transpose(1, 0, 2)       # C_i(0)(u_hat - ubar_i)
    assert np.max(np.abs(log.y - want)) <= 1e-12
    assert np.array_equal(trial.Y_used, log.y)


def test_session_stream_layout(world, showcase, session_rng):
    """Per (t, i), t outer and i inner: eta = sigma * N(0, I) of shape (S, n), then
    S distinct shoppers of region i; scores = u_i(t) + C_i(0)^{-1} w_m,i(t) + eta - mean(eta)."""
    trial, log = showcase
    g = session_rng(trial.N, 0)
    for t in range(trial.N):
        for i in range(world.m):
            eta = log.sigma * g.standard_normal((S, 3))
            users = g.choice(world.by_region[i], size=S, replace=False)
            assert np.array_equal(users, log.users[t, i]), (t, i)
            target = trial.u[t, i] - 2.0 * trial.Wy[t, i]
            assert np.max(np.abs(log.scores[t, i] - (target + eta - eta.mean(axis=0)))) <= 1e-12, (t, i)


def test_shoppers_belong_to_their_region_and_are_distinct(world, session_log):
    users = session_log.users
    N, m, _ = users.shape
    region = world.users["region"]
    for i in range(m):
        assert np.all(region[users[:, i]] == i), i
        assert np.all(np.isin(users[:, i], world.by_region[i])), i
        for t in range(N):
            assert len(np.unique(users[t, i])) == S, (t, i)
        # not the same 100 shoppers every day
        assert len(np.unique(users[:, i])) > 4 * S, i
