"""
Feeds (rcdemo.feeds): the top-k selection against brute-force sorting, the
monotonicity of the genre shares in the boosts, and FeedEvaluator against a
shopper-by-shopper recomputation.

A boost x_l adds the same amount to the score of every product of genre l, so
raising it can only move genre-l products into a feed (the 8th best score
never decreases, and only genre-l scores grow), and raising all three boosts by
the same amount can only push essentials out.  These properties are checked for
every one of the 4,000 shoppers.
"""
import numpy as np
import pytest

from rcdemo.feeds import FeedEvaluator, feed_of, ordered_feed, region_scores, topk_mask
from rcdemo.world import BOOSTED, FEED_SIZE, GENRES, boost_vector

P = 32


def brute_top(row, K):
    """Indices of the K largest entries of row, best first, by a full sort."""
    return sorted(range(len(row)), key=lambda j: -row[j])[:K]


def my_scores(world, x):
    """Scores of every shopper under common boosts x (3,), without boost_vector."""
    g = world.products["genre"]
    shift = np.array([x[gg] if gg < BOOSTED else 0.0 for gg in g])
    return world.users["base_scores"] + shift[None, :]


def genre_counts(world, x):
    """Slots per genre (U, 4) in every shopper's feed under common boosts x (3,)."""
    mask = topk_mask(world.users["base_scores"] + boost_vector(world, x))
    onehot = world.products["genre"][:, None] == np.arange(len(GENRES))[None, :]
    return mask.astype(int) @ onehot.astype(int)


@pytest.mark.parametrize("K", [1, 3, 8, 31, 32])
def test_topk_mask_and_ordered_feed_match_sorting(K):
    g = np.random.default_rng([7, K])
    scores = g.normal(size=(4, 25, P))
    mask, feed = topk_mask(scores, K), ordered_feed(scores, K)
    assert mask.shape == scores.shape and mask.dtype == bool
    assert feed.shape == (4, 25, K)
    assert np.all(mask.sum(axis=-1) == K)
    for idx in np.ndindex(*scores.shape[:-1]):
        best = brute_top(scores[idx], K)
        assert list(feed[idx]) == best, idx
        assert set(np.flatnonzero(mask[idx])) == set(best), idx


def test_default_feed_size_is_8():
    scores = np.random.default_rng(1).normal(size=(10, P))
    assert FEED_SIZE == 8
    assert np.all(topk_mask(scores).sum(axis=1) == 8)
    assert ordered_feed(scores).shape == (10, 8)


def test_feeds_of_all_shoppers_match_sorting(world):
    g = np.random.default_rng(11)
    for x in g.uniform(-1.0, 3.0, size=(4, 3)):
        sc = my_scores(world, x)
        mask = topk_mask(world.users["base_scores"] + boost_vector(world, x))
        feeds = ordered_feed(world.users["base_scores"] + boost_vector(world, x))
        for s in range(len(sc)):
            best = brute_top(sc[s], 8)
            assert list(feeds[s]) == best, s
            assert set(np.flatnonzero(mask[s])) == set(best), s
        for s in range(0, 4000, 97):
            assert list(feed_of(world, s, x)) == brute_top(sc[s], 8), s


def test_region_scores(world):
    X = np.random.default_rng(4).normal(size=(3, 3))
    for i in (0, 5):
        R = region_scores(world, i, X)
        assert R.shape == (3, 500, P)
        for d in range(3):
            assert np.allclose(R[d], my_scores(world, X[d])[world.by_region[i]], rtol=0, atol=1e-14)


def test_raising_one_boost_never_lowers_its_share(world):
    g = np.random.default_rng(5)
    changed = 0
    for x in g.uniform(-2.0, 4.0, size=(10, 3)):
        c0 = genre_counts(world, x)
        assert np.all(c0.sum(axis=1) == 8)
        for l in range(BOOSTED):
            for d in (1e-3, 0.05, 0.3, 1.5):
                x1 = x.copy()
                x1[l] += d
                c1 = genre_counts(world, x1)
                assert np.all(c1[:, l] >= c0[:, l]), (x, l, d)
                others = [h for h in range(4) if h != l]
                assert np.all(c1[:, others] <= c0[:, others]), (x, l, d)     # the others can only lose slots
                changed += int(np.any(c1[:, l] > c0[:, l]))
    assert changed > 50                      # the property is not vacuous


def test_raising_all_boosts_never_raises_the_essentials_share(world):
    g = np.random.default_rng(6)
    changed = 0
    for x in g.uniform(-2.0, 4.0, size=(10, 3)):
        c0 = genre_counts(world, x)
        for d in (1e-3, 0.05, 0.3, 1.5):
            c1 = genre_counts(world, x + d)
            assert np.all(c1[:, 3] <= c0[:, 3]), (x, d)
            changed += int(np.any(c1[:, 3] < c0[:, 3]))
    assert changed > 10


def test_feed_evaluator_on_the_ideal_boosts(world, showcase_trial):
    t = showcase_trial
    fe = FeedEvaluator(world, t.xstar, np.arange(t.T))
    d = fe.evaluate(np.repeat(t.xstar[:, None, :], world.m, axis=1))
    assert d["agree"].shape == d["overlap"].shape == (t.T, 8)
    assert d["share"].shape == fe.share_ideal.shape == (t.T, 8, 4)
    assert np.all(d["agree"] == 1.0)
    assert np.all(d["overlap"] == 1.0)
    assert np.array_equal(d["share"], fe.share_ideal)
    assert np.allclose(fe.share_ideal.sum(axis=2), 1.0, rtol=0, atol=1e-12)


def test_feed_evaluator_against_a_shopper_by_shopper_count(world, showcase_trial):
    t = showcase_trial
    days = np.array([3, 120, 250])
    g = np.random.default_rng(3)
    boosts = t.xstar[:, None, :] + g.normal(scale=0.08, size=(t.T, 8, 3))
    fe = FeedEvaluator(world, t.xstar, days)
    d = fe.evaluate(boosts)
    genre = world.products["genre"]
    for a, day in enumerate(days):
        sc_ideal = my_scores(world, t.xstar[day])
        for i in range(world.m):
            sc = my_scores(world, boosts[day, i])
            same, common = 0, 0
            share, share_id = np.zeros(4), np.zeros(4)
            idx = world.by_region[i]
            for s in idx:
                f, fi = set(brute_top(sc[s], 8)), set(brute_top(sc_ideal[s], 8))
                same += f == fi
                common += len(f & fi)
                for j in f:
                    share[genre[j]] += 1
                for j in fi:
                    share_id[genre[j]] += 1
            U = len(idx)
            assert d["agree"][a, i] == pytest.approx(same / U, abs=1e-12), (day, i)
            assert d["overlap"][a, i] == pytest.approx(common / (8 * U), abs=1e-12), (day, i)
            assert np.allclose(d["share"][a, i], share / (8 * U), rtol=0, atol=1e-12), (day, i)
            assert np.allclose(fe.share_ideal[a, i], share_id / (8 * U), rtol=0, atol=1e-12), (day, i)
    assert 0.0 < d["agree"].mean() < 1.0      # the perturbed boosts change some feeds, not all
