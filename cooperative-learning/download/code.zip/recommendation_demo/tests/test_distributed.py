"""
The distributed simulation (rcdemo/distributed.py: one OS process per regional
server, the test process as the platform) at N = 30, trial 0, tau = 3:

* it reproduces the in-process trial (simulate.run_trial_logged with
  SessionLog on the same generators) to 1e-9: sessions, window estimates,
  A_hat_i, boosts x_i(t);
* its message accounting matches the counts that follow from the graph
  degrees, T, N and tau, and nothing but Algorithm 1's variables crossed a
  backbone link (and distributed.traffic_mismatches, the CLI's check, agrees
  and detects a lost or foreign message);
* a server whose process fails is named first in RunFailed, no process is
  left behind, and failure_report puts root causes before knock-on errors;
* run_distributed.py runs end to end (into a pytest tmp dir).

    python3 -m pytest tests/test_distributed.py -q
"""
import copy
import csv
import dataclasses
import multiprocessing as mp
import os
import subprocess
import sys

import numpy as np
import pytest

DEMO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if DEMO not in sys.path:
    sys.path.insert(0, DEMO)

from rcdemo import distributed as dist                                    # noqa: E402
from rcdemo.paper import CASE_ID, SEED                                    # noqa: E402
from rcdemo.simulate import SessionLog, paper_trial_rng, run_trial_logged  # noqa: E402
from rcdemo.world import make_world                                       # noqa: E402

N, TRIAL, TAU = 30, 0, 3
TOL = 1e-9


@pytest.fixture(scope="module")
def runs():
    """(world, distributed run, in-process trial, its SessionLog)."""
    world = make_world()
    run = dist.run_distributed(world, N, TRIAL, tau=TAU, timeout=60)
    log = SessionLog(world, np.random.default_rng([SEED, CASE_ID, dist.SESSION_STREAM, N, TRIAL]))
    trial = run_trial_logged(world.cs, N, paper_trial_rng(N, TRIAL), taus=(3, 1), measure=log)
    return world, run, trial, log


def test_agrees_with_in_process_run(runs):
    world, run, trial, log = runs
    key = "coop%d" % TAU
    assert np.array_equal(run.platform.users, log.users)                      # same sessions
    assert np.array_equal(run.platform.scores, log.scores)
    for i, rec in enumerate(run.records):                                     # ... and received as sent
        assert rec["session_digest"] == dist.session_digest(log.users[:, i], log.scores[:, i])
    assert np.max(np.abs(run.stack("theta_tilde") - trial.th)) <= TOL
    assert np.max(np.abs(run.stack("A_hat") - trial.estimates[key][0])) <= TOL
    assert np.max(np.abs(np.array([r["rho_raw"] for r in run.records]) - trial.estimates[key][1])) <= TOL
    assert np.max(np.abs(run.X - trial.boosts[key])) <= TOL
    assert abs(dist.boost_rmse(run.X, trial.xstar, N) - trial.rmse[key]) <= TOL
    diffs = dist.compare(run, trial, log)
    assert dist.failures(diffs, run.m, TOL) == [], diffs


def test_message_accounting(runs):
    world, run, _, _ = runs
    cs = world.cs
    m, n, p, S = cs.m, cs.n, cs.p, run.S
    T = N + 200
    steps = T - 1                                   # recursion steps t = 0..T-2, two exchanges each
    E = len(world.edges)
    deg = np.zeros(m, dtype=int)
    for a, b in world.edges:
        deg[a] += 1
        deg[b] += 1
    expect = {"gt_x": (steps, n * steps), "gt_s": (steps, n * steps), "moments": (TAU, 2 * p * p * TAU)}

    total_msgs = total_reals = 0
    for a, b in world.edges:
        for i, j in ((a, b), (b, a)):
            sent = run.records[i]["links"][j]["sent"]
            assert sent == run.records[j]["links"][i]["received"]           # every message arrived
            for kind, (msgs, reals) in expect.items():
                mine = [msg for msg in sent if msg[0] == kind]
                assert len(mine) == msgs and sum(msg[3] for msg in mine) == reals, (i, j, kind)
            assert [msg[1] for msg in sent if msg[0] == "gt_x"] == list(range(steps))
            assert [msg[1] for msg in sent if msg[0] == "gt_s"] == list(range(steps))
            assert [msg[1:3] for msg in sent if msg[0] == "moments"] == [(N - 1, r) for r in range(1, TAU + 1)]
            total_msgs += len(sent)
            total_reals += sum(msg[3] for msg in sent)
    assert total_msgs == 2 * E * (2 * steps + TAU)
    assert total_reals == 2 * E * (2 * n * steps + 2 * p * p * TAU)
    assert dist.backbone_types_seen(run) == ["gt_s", "gt_x", "moments"]
    assert dist.traffic_mismatches(run) == []                                  # the CLI's check agrees
    recs = copy.deepcopy(run.records)                                          # ... and is not vacuous
    recs[0]["links"][1]["sent"].pop()                                          # server 1 -> 2: one message lost
    recs[2]["links"][3]["received"][N] = ("moments", N - 1, 1, 9)              # server 3 <- 4: a foreign message
    assert dist.traffic_mismatches(dataclasses.replace(run, records=recs)) == [
        "server 1, link to server 2: messages sent differ", "server 3, link to server 4: messages received differ",
        "server 1: totals differ from degree 3 x the link traffic",
        "server 3: totals differ from degree 3 x the link traffic"]

    for r in dist.server_traffic(run):
        i, d = r["i"], deg[r["i"]]
        assert sorted(run.records[i]["links"]) == sorted(world.regions[i]["neighbors"])   # links = neighbors
        assert r["msgs_sent"] == r["msgs_received"] == d * (2 * steps + TAU)
        assert r["reals_sent"] == r["reals_received"] == d * (2 * n * steps + 2 * p * p * TAU)
        assert (r["deploy_msgs"], r["deploy_reals"]) == (N, N * n)                  # days t < N only
        assert (r["session_msgs"], r["session_rows"], r["session_scores"]) == (N, N * S, N * S * n)
        assert (r["report_msgs"], r["report_reals"]) == (N, N * n)
        assert r["platform_counts_agree"]
        assert set(run.platform.sent[i]) == set(dist.PLATFORM_TYPES)


def test_servers_start_from_their_own_constants():
    world = make_world()
    cs = world.cs
    allowed = {"i", "code", "lam", "ubar", "R", "weights", "k", "alpha", "tau", "rho_max", "N", "T",
               "box_lo", "box_hi", "projection"}
    for i, cfg in enumerate(dist.server_configs(world, N, TAU)):
        assert set(vars(cfg)) == allowed
        assert sorted(cfg.weights) == sorted(world.regions[i]["neighbors"] + [i])
        assert all(cfg.weights[j] == cs.W[i, j] for j in cfg.weights)
        assert cfg.lam == cs.varpi[i] and np.array_equal(cfg.ubar, cs.ubar[i])
        assert (cfg.k, cfg.alpha, cfg.tau, cfg.rho_max) == (3, 0.25, TAU, 0.999)


def test_link_passes_only_algorithm_1_messages():
    a, b = mp.Pipe()
    link = dist.Link(1, a, dist.backbone_sizes(3, 3))
    with pytest.raises(ValueError):
        link.send("sessions", 0, 0, np.zeros(3))           # not a backbone type
    with pytest.raises(ValueError):
        link.send("gt_x", 0, 0, np.zeros(300))             # wrong size
    link.send("moments", 29, 1, np.arange(18.0))
    kind, step, rnd, values = b.recv()
    assert (kind, step, rnd) == ("moments", 29, 1) and np.array_equal(values, np.arange(18.0))
    assert link.sent == [("moments", 29, 1, 18)]
    a.close()
    b.close()
    assert dist.failures({"boosts": 2e-9, "sessions": True}, 8) == ["boosts"]


def test_failure_report_names_root_causes_first():
    label = ["server %d (R%d)" % (i + 1, i + 1) for i in range(4)]
    eof = "Traceback (most recent call last):\n  File \"x\", line 1\nEOFError"
    own = "Traceback (most recent call last):\n  File \"x\", line 1\nKeyError: 'x'"
    rep = dist.failure_report(label, {0: eof, 2: own}, [1, 3, 1, None])
    assert rep[0] == "server 2 (R2) exited with code 3 without an error report"      # died silently
    assert rep[1].startswith("server 3 (R3):\n") and rep[1].endswith("KeyError: 'x'")  # its own error
    assert rep[2].startswith("server 1 (R1):\n") and len(rep) == 3                     # knock-on last
    assert dist.failure_report(label, {}, [0, -9, 0, None]) == [
        "server 2 (R2) was killed by signal 9 without an error report"]


def test_failing_server_is_named(monkeypatch):
    """A server whose process fails is named first in RunFailed, and no process is left."""
    world = make_world()
    configs = dist.server_configs

    def broken(world, N, tau=3):
        cfgs = configs(world, N, tau)
        cfgs[3].weights[99] = 0.0                 # server 4 (SA) is told of a neighbor it has no link to
        return cfgs
    monkeypatch.setattr(dist, "server_configs", broken)
    with pytest.raises(dist.RunFailed) as err:
        dist.run_distributed(world, 12, 0, tau=1, timeout=30)
    lines = str(err.value).splitlines()
    assert "server 4 (SA) closed its channel to the platform on day 0" in lines[0]
    assert [l for l in lines[1:] if l.startswith("server ")][0] == "server 4 (SA):"
    assert "KeyError: 99" in lines
    assert mp.active_children() == []


def test_cli(tmp_path):
    out = tmp_path / "distributed"
    res = subprocess.run([sys.executable, os.path.join(DEMO, "run_distributed.py"), "--N", str(N),
                          "--out", str(out)], capture_output=True, text=True, timeout=120)
    assert res.returncode == 0, res.stdout + res.stderr
    for name in ["comparison.txt", "messages.csv", "servers.csv", "steps.csv", "boosts.csv",
                 "identification.csv", "summary.txt", "run_config.json"]:
        assert (out / name).is_file(), name
    assert "result: SAME TRIAL" in (out / "comparison.txt").read_text()
    with open(out / "messages.csv", newline="") as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 20 and {r["received_as_sent"] for r in rows} == {"yes"}
    assert {int(r["moments_reals"]) for r in rows} == {2 * 3 * 3 * TAU}
