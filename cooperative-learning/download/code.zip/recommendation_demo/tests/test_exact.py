"""
run_trial_logged against the paper's reference implementation.

For every (N, trial) of CASES the trial is simulated three times, each from a
fresh generator of the paper's N-sweep, rng([2026, 3, N, trial]):

    res     experiments.run_trial(cs, N, rng, taus=(3, 1), extra=True, want_series=True)
    plain   run_trial_logged(cs, N, rng, taus=(3, 1))              (the paper's measurements)
    logged  run_trial_logged(cs, N, rng, taus=(3, 1), measure=SessionLog(world, rng_s))

with rng_s = rng([2026, 3, 9002, N, trial]), the session stream of run_demo.py.
plain must be bit-exact with res.  logged must be the same trial to 1e-8 and
have the same measurements to 1e-12: the measurements computed from the logs
differ from the paper's by rounding (~1e-15), and the centralized predictor
stops Newton's method at ||grad F|| < 1e-10 (or where its line search can no
longer resolve F, up to ~1e-8 from the minimizer), which turns that rounding
into ~1e-11 differences of its boosts (at most 5e-11 on CASES).  The session
generator must not touch the paper's draws.  Finally, the showcase trial of
run_demo.py (N = 100, trial 0) must be the trial whose series the paper plots
in Figure 3(b) (paper_v4_package/code/data/trial_rc_*.dat, written by
experiments.one_trial).
"""
import os
from types import SimpleNamespace

import numpy as np
import pytest

from rcdemo.paper import CASE_ID, REF_DATA, SEED, ref
from rcdemo.simulate import PAPER_METHODS, SessionLog, paper_trial_rng, run_trial_logged

TAUS = (3, 1)
CASES = [(30, 0), (30, 13), (100, 0), (200, 3)]      # (N, trial) of the paper's N-sweep
TOL_TRIAL = 1e-8                                    # same trial, measurements from session logs
TOL_MEAS = 1e-12                                    # same measurements
EXTRA = {"frozen", "noboost"}                       # demo references that run_trial does not have


@pytest.fixture(scope="module", params=CASES, ids=["N%d-trial%d" % c for c in CASES])
def runs(request, world, trials):
    """The three simulations of one (N, trial); plain and logged come from the
    session cache (conftest.TrialCache: rng([2026, 3, N, trial]) and run_demo.py's
    session stream rng([2026, 3, 9002, N, trial]))."""
    N, tr = request.param
    g_ref = np.random.default_rng([SEED, CASE_ID, N, tr])
    res = ref.run_trial(world.cs, N, g_ref, taus=TAUS, extra=True, want_series=True)
    plain, logged = trials.get(N, tr, sessions=False), trials.get(N, tr, sessions=True)
    return SimpleNamespace(N=N, trial=tr, res=res, plain=plain.trial, logged=logged.trial, log=logged.log,
                           state_ref=g_ref.bit_generator.state, state_plain=plain.state,
                           state_logged=logged.state, sess_before=logged.sess_before, sess_after=logged.sess_after)


def paper_view(res):
    """What experiments.run_trial returns, flattened to name -> value."""
    S = res["series"]
    d = dict(Theta=S["Theta"], xstar=S["xstar"], th=S["th"], traj_data=np.array(S["traj_data"]),
             traj_coop=np.array(S["traj_coop"]), traj_local=np.array(S["traj_local"]),
             fore_coop=S["fore_coop"], fore_local=S["fore_local"], recon=res["recon"])
    for group in ("rmse", "id", "unstable"):
        for key, v in res[group].items():
            d["%s/%s" % (group, key)] = v
    return d


def demo_view(trial):
    """The same quantities taken from a Trial."""
    N, key = trial.N, "coop%d" % trial.taus[0]
    d = dict(Theta=trial.Theta, xstar=trial.xstar, th=trial.th, traj_data=trial.X_data,
             traj_coop=trial.boosts[key][N:], traj_local=trial.boosts["local"][N:],
             fore_coop=trial.forecasts[key][:, 0], fore_local=trial.forecasts["local"][:, 0], recon=trial.recon)
    for group in ("rmse", "id", "unstable"):
        for key2, v in getattr(trial, group).items():
            d["%s/%s" % (group, key2)] = v
    return d


def test_same_methods_as_run_trial(runs):
    res, t = runs.res, runs.plain
    assert set(t.rmse) == set(res["rmse"]) | EXTRA
    assert set(t.id) == set(res["id"]) == set(t.unstable)
    assert set(t.boosts) == set(t.rmse)


def test_bit_exact_with_the_papers_measurements(runs):
    want, got = paper_view(runs.res), demo_view(runs.plain)
    bad = []
    for name, w in want.items():
        g = np.asarray(got[name])
        if g.shape != np.shape(w) or not np.array_equal(g, np.asarray(w)):
            bad.append("%s (max diff %s)" % (name, np.max(np.abs(g - w)) if g.shape == np.shape(w) else "shape"))
    assert not bad, "not bit-exact with experiments.run_trial: " + ", ".join(bad)


def test_same_trial_with_session_logs(runs):
    want, got = paper_view(runs.res), demo_view(runs.logged)
    diff = {name: float(np.max(np.abs(np.asarray(got[name]) - np.asarray(w)))) for name, w in want.items()}
    bad = {name: v for name, v in diff.items() if not v <= TOL_TRIAL}
    assert not bad, "differs from experiments.run_trial by more than %g: %s" % (TOL_TRIAL, bad)
    # the measurements the servers compute from their logs are the paper's measurements
    assert np.max(np.abs(runs.logged.Y_used - runs.plain.Y)) <= TOL_MEAS


def test_session_logs_never_touch_the_papers_draws(runs):
    p, lg = runs.plain, runs.logged
    for name in ("Theta", "Wy", "Wg", "Y", "Cs", "G_data", "X_data", "xstar"):
        assert np.array_equal(getattr(p, name), getattr(lg, name)), name
    # every run leaves the trial generator in the same state: the replica draws
    # exactly what run_trial draws, and the sessions draw nothing from it
    assert runs.state_plain == runs.state_ref
    assert runs.state_logged == runs.state_ref
    # the sessions come from their own generator
    assert runs.sess_after != runs.sess_before
    assert runs.log.scores.shape == (runs.N, 8, 100, 3)


def test_noises_are_the_papers_draws(runs, world):
    """Theta, the gradient noise and the measurement noise are run_trial's draws in
    run_trial's order: Theta(0..T-1), then for each day t the gradient noise of
    servers 1..8 followed by their measurement noise, and nothing else."""
    cs, N, t = world.cs, runs.N, runs.plain
    T, m, n, p = N + 200, cs.m, cs.n, cs.p
    g = np.random.default_rng([SEED, CASE_ID, N, runs.trial])
    Lp, Lq, Lr = (np.linalg.cholesky(M) for M in (cs.P0, cs.Q, cs.R))
    Theta = np.zeros((T, m, p))
    Theta[0] = g.standard_normal((m, p)) @ Lp.T
    for s in range(1, T):
        Theta[s] = Theta[s - 1] @ cs.A.T + g.standard_normal((m, p)) @ Lq.T
    Wg, Wy = np.zeros((N, m, n)), np.zeros((N, m, n))
    for s in range(N):
        for i in range(m):
            Wg[s, i] = Lr @ g.standard_normal(n)
        for i in range(m):
            Wy[s, i] = Lr @ g.standard_normal(n)
    assert np.array_equal(t.Theta, Theta)
    assert np.array_equal(t.Wg, Wg)
    assert np.array_equal(t.Wy, Wy)
    assert g.bit_generator.state == runs.state_ref
    assert np.array_equal(t.u, cs.ubar[None] + Theta)


def test_measurements_are_the_papers_model(runs, world):
    """y_i(t) = C_i(0) theta_i(t) + w_m,i(t), C_i(0) = -diag(sigma(0)) = -I/2 (x^e = 0)."""
    p, lg, N = runs.plain, runs.logged, runs.N
    C0 = -0.5 * np.eye(3)
    assert np.array_equal(p.Cs, np.broadcast_to(C0, p.Cs.shape))
    want = np.einsum("ab,itb->ita", C0, p.Theta[:N].transpose(1, 0, 2)) + p.Wy.transpose(1, 0, 2)
    assert np.max(np.abs(p.Y - want)) <= 1e-15
    assert np.array_equal(p.Y_used, p.Y)
    assert np.max(np.abs(lg.Y_used - want)) <= TOL_MEAS
    assert np.array_equal(lg.Y_used, runs.log.y)


def test_operational_references_and_rmse(runs):
    """Every paper method starts from the data-phase iterates; "frozen" keeps the
    boosts of day N-1, "noboost" is x = 0 on every day, the centralized predictor
    gives every server the same boosts; rmse follows its definition."""
    t = runs.plain
    N = t.N
    for key in PAPER_METHODS + ["frozen"]:
        assert np.array_equal(t.boosts[key][:N], t.X_data), key
    assert np.all(t.boosts["frozen"][N:] == t.X_data[N - 1])
    assert np.all(t.boosts["noboost"] == 0.0)
    assert np.all(t.boosts["centralized"][N:] == t.boosts["centralized"][N:, :1])
    assert np.array_equal(t.window, np.arange(N + 50, N + 200))
    for key, b in t.boosts.items():
        err = b[t.window] - t.xstar[t.window][:, None, :]
        want = np.sqrt(np.mean(np.sum(err ** 2, axis=2)))
        assert t.rmse[key] == pytest.approx(want, rel=1e-12), key


FORECASTERS = ["local", "coop3", "coop1", "exact", "pooledLS", "persistence", "oracleA", "oracleKF"]


@pytest.mark.parametrize("which", ["plain", "logged"])
def test_every_method_is_the_papers_forecaster(runs, world, which):
    """The recorded moments, estimates and forecasts of every method and every
    server are those of experiments.py's functions applied to the recorded window
    estimates: iv_moments, ls_moments, identify (tau = 0, 3, 1, exact; pooled LS),
    and a fresh experiments.Forecaster for t = N..T-1 (persistence: A = I; oracle
    A: A; oracle KF: the Kalman state at N-1).  run_trial returns only server 1's
    cooperative and local forecasts, which test_bit_exact compares."""
    cs, t = world.cs, getattr(runs, which)
    N, T, k, m, p = t.N, t.T, t.k, cs.m, cs.p
    M0, M1 = ref.iv_moments(t.th, N, k)
    L0, L1 = ref.ls_moments(t.th, N, k)
    assert all(np.array_equal(a, b) for a, b in zip(t.moments["iv"], (M0, M1)))
    assert all(np.array_equal(a, b) for a, b in zip(t.moments["ls"], (L0, L1)))
    anchors = t.th[:, N - k]
    assert np.array_equal(t.anchors, anchors)
    want = {"local": ref.identify(M0, M1, cs.W, 0), "coop3": ref.identify(M0, M1, cs.W, 3),
            "coop1": ref.identify(M0, M1, cs.W, 1), "exact": ref.identify(M0, M1, cs.W, None),
            "pooledLS": ref.identify(L0, L1, cs.W, None)}
    assert set(t.estimates) == set(want)
    for key, (Ah, rho) in want.items():
        assert np.array_equal(t.estimates[key][0], Ah) and np.array_equal(t.estimates[key][1], rho), key
    fcs = {key: ref.Forecaster(cs, list(Ah), anchors, N - k) for key, (Ah, _) in want.items()}
    fcs["persistence"] = ref.Forecaster(cs, [np.eye(p)] * m, anchors, N - k)
    fcs["oracleA"] = ref.Forecaster(cs, [cs.A] * m, anchors, N - k)
    fcs["oracleKF"] = ref.Forecaster(cs, [cs.A] * m, ref.kalman_forecast_state(cs, t.Y_used, t.Cs, N), N - 1)
    assert set(t.forecasts) == set(FORECASTERS) | {"centralized"}
    for key, fc in fcs.items():
        series = np.array([fc.at(s) for s in range(N, T)])
        assert t.forecasts[key].shape == (T - N, m, p), key
        assert np.array_equal(t.forecasts[key], series), key
    assert np.array_equal(t.forecasts["centralized"], t.forecasts["coop3"])


@pytest.mark.parametrize("which", ["plain", "logged"])
def test_boosts_follow_gradient_tracking(runs, world, which):
    """Every boost trajectory is the gradient tracking of Algorithm 1 (x(0) = 0,
    s(0) = gamma(0), x(t+1) = W (x(t) - alpha s(t)), s(t+1) = W (s(t) + gamma(t+1)
    - gamma(t))), driven for t < N by the noisy gradients at the iterates,
    G_data(t) = grad f_i(x_i(t), theta_i(t)) + w_g, and for t >= N by the method's
    forecast gradients grad f_i(x_i(t), theta_hat_i(t)).  The centralized
    predictor gives every server the minimizer of the forecast team cost, to the
    precision of experiments.CaseStudy.minimizer: it stops at ||grad|| < 1e-10 or
    when its Armijo test can no longer resolve F (rounding ~1e-15 |F|, |F| ~ 20),
    which leaves ||grad|| up to ~1e-7 on a few days (8.7e-8 at N = 30, trial 0;
    x*(t), from the same minimizer, has up to 2e-9) and the point within ~1e-8 of
    the minimizer (one Newton step)."""
    cs, t = world.cs, getattr(runs, which)
    N, T, m = t.N, t.T, cs.m
    W, a = cs.W, cs.alpha
    for s in range(N):
        G = np.array([cs.grad(i, t.X_data[s, i], t.Theta[s, i]) for i in range(m)]) + t.Wg[s]
        assert np.max(np.abs(t.G_data[s] - G)) <= 1e-12, s
    X, S = np.zeros((m, cs.n)), t.G_data[0].copy()
    assert np.all(t.X_data[0] == 0.0)
    for s in range(N - 1):
        X = W @ (X - a * S)
        S = W @ (S + t.G_data[s + 1] - t.G_data[s])
        assert np.max(np.abs(t.X_data[s + 1] - X)) <= 1e-10, s
    for key in FORECASTERS:
        Th, Xk, Sk, Gk = t.forecasts[key], X, S, t.G_data[N - 1]
        traj = []
        for s in range(N, T):
            Xk = W @ (Xk - a * Sk)
            Gn = np.array([cs.grad(i, Xk[i], Th[s - N, i]) for i in range(m)])
            Sk, Gk = W @ (Sk + Gn - Gk), Gn
            traj.append(Xk)
        assert np.max(np.abs(t.boosts[key][N:] - np.array(traj))) <= 1e-10, key
    xc, Th = t.boosts["centralized"][N:, 0], t.forecasts["coop3"]
    newton = [np.linalg.norm(np.linalg.solve(cs.hess_F(xc[j], Th[j]), cs.grad_F(xc[j], Th[j]))) for j in range(T - N)]
    assert max(newton) <= 1e-7, max(newton)


def test_measurements_do_not_depend_on_the_session_draws(world):
    """Two different session streams: different sessions, the same measurements, the same trial."""
    N, tr = 30, 5
    logs = [SessionLog(world, np.random.default_rng([SEED, CASE_ID, 9100 + s])) for s in range(2)]
    trials = [run_trial_logged(world.cs, N, paper_trial_rng(N, tr), taus=TAUS, measure=lg) for lg in logs]
    assert not np.allclose(logs[0].scores, logs[1].scores)
    assert np.mean(logs[0].users != logs[1].users) > 0.9
    assert np.max(np.abs(trials[0].Y_used - trials[1].Y_used)) <= TOL_MEAS
    a, b = demo_view(trials[0]), demo_view(trials[1])
    diff = {k: float(np.max(np.abs(np.asarray(a[k]) - np.asarray(b[k])))) for k in a}
    assert max(diff.values()) <= TOL_TRIAL, diff


# ----------------------------------------------------------------------------
# the showcase trial is the trial of the paper's Figure 3(b)
# ----------------------------------------------------------------------------
def read_dat(name):
    """A .dat file of experiments.write_dat: header row, then '%.6g' columns."""
    path = os.path.join(REF_DATA, name)
    if not os.path.exists(path):
        pytest.fail("missing paper data file %s" % path)
    a = np.loadtxt(path, skiprows=1)
    return a[:, 0], a[:, 1]


def assert_matches_6g(stored, value, name):
    """stored = '%.6g' % value, up to the rounding of the 6th significant digit."""
    value = np.asarray(value, float)
    mag = np.where(value == 0, 0.0, 10.0 ** (np.floor(np.log10(np.abs(np.where(value == 0, 1.0, value)))) - 5))
    err = np.abs(stored - value)
    bad = err > 0.5 * mag + 1e-9
    assert not bad.any(), "%s: %d values differ beyond the 6th digit (first at index %d: %r vs %r)" % (
        name, bad.sum(), np.flatnonzero(bad)[0], stored[bad][0], value[bad][0])


def test_showcase_is_the_trial_of_figure_3b(showcase_trial):
    """experiments.one_trial: run_trial(cs, 100, rng([2026, 3, 100, 0]), taus=(3,), extra=False),
    server 1 (index 0) for the drifts, every server for the first boost."""
    t = showcase_trial
    N, T = t.N, t.T
    assert (N, T) == (100, 300)
    tf, X, XL = np.arange(N, T), t.boosts["coop3"], t.boosts["local"][N:]
    series = {}
    for c in range(2):
        series["trial_rc_theta%d_true.dat" % (c + 1)] = (np.arange(T), t.Theta[:, 0, c])
        series["trial_rc_theta%d_window.dat" % (c + 1)] = (np.arange(N - t.k + 1), t.th[0, :, c])
        series["trial_rc_theta%d_coop.dat" % (c + 1)] = (tf, t.forecasts["coop3"][:, 0, c])
        series["trial_rc_theta%d_local.dat" % (c + 1)] = (tf, t.forecasts["local"][:, 0, c])
    for i in range(8):
        series["trial_rc_x_agent%d.dat" % i] = (np.arange(T), X[:, i, 0])
    series["trial_rc_x_opt.dat"] = (np.arange(T), t.xstar[:, 0])
    series["trial_rc_x_local.dat"] = (tf, XL[:, :, 0].mean(axis=1))
    series["trial_rc_err_coop.dat"] = (np.arange(T), np.sqrt(np.mean(np.sum((X - t.xstar[:, None]) ** 2, axis=2), axis=1)))
    series["trial_rc_err_local.dat"] = (tf, np.sqrt(np.mean(np.sum((XL - t.xstar[N:, None]) ** 2, axis=2), axis=1)))
    XC = X[N:]
    series["trial_rc_disagreement.dat"] = (tf, np.sqrt(np.mean(np.sum((XC - XC.mean(axis=1, keepdims=True)) ** 2,
                                                                       axis=2), axis=1)))
    for name, (tt, v) in series.items():
        ts, vs = read_dat(name)
        assert np.array_equal(ts, tt), name
        assert_matches_6g(vs, v, name)
