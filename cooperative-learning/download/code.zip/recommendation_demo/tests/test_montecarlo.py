"""
Smoke test of run_montecarlo.py: 2 trials at N = 30 in one process, written to
a pytest tmp dir.  Checks the files and their columns, that the per-trial
tracking RMSE, identification errors and unstable fractions are those of
experiments.run_trial on the same generator (the paper's trials), and the
verdicts of the reproduction check on synthetic statistics.

    python3 -m pytest tests/test_montecarlo.py -q
"""
import csv
import os
import sys

import numpy as np
import pytest

DEMO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if DEMO not in sys.path:
    sys.path.insert(0, DEMO)

import run_montecarlo as mc                                  # noqa: E402
from rcdemo.kpi import KPI_KEYS, METHODS                     # noqa: E402
from rcdemo.paper import CASE, CASE_ID, REF_DATA, SEED, ref  # noqa: E402

N, TRIALS = 30, 2
ESTIMATORS = ["local", "coop1", "coop3", "exact", "pooledLS"]   # methods with an estimate of A


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        rd = csv.reader(f)
        header = next(rd)
        return header, [dict(zip(header, row)) for row in rd]


@pytest.fixture(scope="module")
def run(tmp_path_factory):
    out = tmp_path_factory.mktemp("montecarlo")
    rc = mc.main(["--trials", str(TRIALS), "--Ns", str(N), "--jobs", "1", "--out", str(out)])
    return out, rc


def test_files_and_columns(run):
    out, rc = run
    assert rc == 0
    for name in ("mc_trials.csv", "mc_summary.csv", "mc_table.md", "mc_check.txt"):
        assert (out / name).is_file() and (out / name).stat().st_size > 0

    header, rows = read_csv(out / "mc_trials.csv")
    assert header == ["N", "trial", "method", "rmse", "forecast", "agree", "overlap", "exposure", "excess",
                      "id", "unstable", "id_servers"]
    assert len(rows) == TRIALS * len(METHODS)
    assert [r["method"] for r in rows[:len(METHODS)]] == METHODS
    for r in rows:
        assert int(r["N"]) == N and int(r["trial"]) in range(TRIALS)
        assert 0.0 <= float(r["agree"]) <= 100.0 and 0.0 <= float(r["overlap"]) <= 100.0
        servers = r["id_servers"].split()
        if r["method"] in ESTIMATORS:
            assert len(servers) == 8
            assert float(r["id"]) == pytest.approx(np.mean([float(v) for v in servers]), rel=3e-9)
        else:
            assert servers == [] and r["id"] == "" and r["unstable"] == ""
        if r["method"] == "ideal":
            assert float(r["rmse"]) == 0.0 and float(r["agree"]) == 100.0

    header, srows = read_csv(out / "mc_summary.csv")
    assert header == ["N", "method", "metric", "median", "q25", "q75", "mean", "n"]
    # the summary is the statistics of mc_trials.csv (both printed with 10 significant digits)
    for s in srows:
        if s["metric"] in KPI_KEYS:
            v = [float(r[s["metric"]]) for r in rows if r["method"] == s["method"]]
            assert int(s["n"]) == TRIALS
        else:
            assert s["metric"] == mc.ID_SERVER and s["method"] in ESTIMATORS
            v = [float(x) for r in rows if r["method"] == s["method"] for x in r["id_servers"].split()]
            assert int(s["n"]) == 8 * TRIALS
        assert float(s["median"]) == pytest.approx(np.median(v), rel=3e-9, abs=1e-12)
        assert float(s["q25"]) == pytest.approx(np.percentile(v, 25), rel=3e-9, abs=1e-12)
        assert float(s["q75"]) == pytest.approx(np.percentile(v, 75), rel=3e-9, abs=1e-12)
        assert float(s["mean"]) == pytest.approx(np.mean(v), rel=3e-9, abs=1e-12)

    table = (out / "mc_table.md").read_text(encoding="utf-8")
    for key in KPI_KEYS + [mc.ID_SERVER]:
        assert "\n## %s\n" % key in table
    # 2 trials are not the paper's 50: compared for information only
    assert "result: NOT APPLICABLE" in (out / "mc_check.txt").read_text(encoding="utf-8")


def test_trials_are_the_papers(run):
    """Same generator, same trial: experiments.run_trial gives the rmse, the
    per-server identification errors and the unstable fractions of the CSV."""
    out, _ = run
    _, rows = read_csv(out / "mc_trials.csv")
    by = {(int(r["trial"]), r["method"]): r for r in rows}
    cs = ref.make_case(CASE, np.random.default_rng([SEED, CASE_ID]))
    for tr in range(TRIALS):
        res = ref.run_trial(cs, N, np.random.default_rng([SEED, CASE_ID, N, tr]), taus=(3, 1), extra=True)
        assert len(res["rmse"]) == 9 and set(res["id"]) == set(ESTIMATORS)
        for key, v in res["rmse"].items():
            assert float(by[(tr, key)]["rmse"]) == pytest.approx(v, rel=1e-9, abs=0)
        for key, ids in res["id"].items():
            got = [float(x) for x in by[(tr, key)]["id_servers"].split()]
            np.testing.assert_allclose(got, ids, rtol=1e-9, atol=0)
            assert float(by[(tr, key)]["unstable"]) == pytest.approx(res["unstable"][key], abs=1e-12)


def paper_values(name, col="y"):
    header, d = mc.read_dat(os.path.join(REF_DATA, name))
    return {int(round(x)): y for x, y in zip(d[:, header.index("x")], d[:, header.index(col)])}


def synthetic_results(trials):
    """Trials whose statistics are the paper's values (every trial equal)."""
    rmse = {k: paper_values("rc_rmse_%s.dat" % k) for k in ref.RMSE_KEYS}
    ids = {k: paper_values("rc_id_%s.dat" % k) for k in ref.ID_KEYS}
    unst = {k: paper_values("rc_unstable.dat", k) for k in ref.ID_KEYS}
    res = []
    for n_ in mc.NS:
        for tr in range(trials):
            kp = {k: {"rmse": rmse[k][n_]} for k in ref.RMSE_KEYS}
            for k in ref.ID_KEYS:
                kp.setdefault(k, {})["unstable"] = unst[k][n_]
            res.append(dict(N=n_, trial=tr, kpis=kp, ids={k: np.full(8, ids[k][n_]) for k in ref.ID_KEYS}))
    return res


def test_check_verdicts():
    res = synthetic_results(mc.TRIALS)
    lines, verdict = mc.check(res, mc.NS, mc.TRIALS, SEED)
    assert verdict == "PASS" and lines[-1] == "result: PASS"
    n_cmp = sum(1 for ln in lines if ln.startswith("  rc_") and ln.split()[2].isdigit())   # file, column, N, ...
    assert n_cmp == len(mc.NS) * (len(ref.RMSE_KEYS) + 2 * len(ref.ID_KEYS))
    for r in res:                                    # one statistic off by 1e-4
        if r["N"] == 100:
            r["kpis"]["coop3"]["rmse"] *= 1.0 + 1e-4
    assert mc.check(res, mc.NS, mc.TRIALS, SEED)[1] == "FAIL"
    assert mc.check(synthetic_results(5), mc.NS, 5, SEED)[1] == "NOT APPLICABLE"


def test_metric_definitions():
    defs = mc.metric_definitions()
    for key in KPI_KEYS + [mc.ID_SERVER]:
        assert defs.get(key), key
