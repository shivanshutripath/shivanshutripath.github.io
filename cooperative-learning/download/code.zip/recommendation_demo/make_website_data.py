#!/usr/bin/env python3
"""
make_website_data.py -- the data of the "Recommendation systems" section of the
project page (https://shivanshutripath.github.io/cooperative-learning/).

    python3 make_website_data.py --out <website>/cooperative-learning/data/recommendation.js

Reads the outputs of run_demo.py, run_montecarlo.py and make_dashboard_data.py
(output/kpis.csv, output/run_config.json, output/montecarlo/mc_summary.csv,
output/dashboard/{regions,links,catalog,shoppers,feeds,strip}.csv) and writes one
JavaScript file that adds ``window.RESULTS.REC`` next to the page's
data/results.js:

    mc        medians and interquartile ranges over the paper's 50 trials per N
              (ideal first screens, interest forecast RMSE, genre-mix error)
    trial     the metrics of the trial of the paper's Figure 3(b)
    regions, links, genres, products
    users     the typical and the contrast user of every region: affinities, the
              days their first screen differed from the ideal one, and their
              first screens on the example days under each method

Every series names the file it comes from ("src"). Only the standard library is
needed.
"""
import argparse
import csv
import datetime
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "output")
SRC = "recommendation_demo/output/"

MC_METRICS = {"agree": "% of user-days whose first screen holds the products of the ideal boosts x*(t)",
              "forecast": "RMSE of the interest forecasts, per genre",
              "exposure": "mean absolute error of the genre shares of the first-screen slots, percentage points"}
MC_METHODS = ["coop3", "local", "persistence", "frozen", "oracleA", "oracleKF", "exact", "centralized",
              "pooledLS", "coop1"]
FEED_METHODS = ["ideal", "coop3", "local", "frozen", "noboost"]
STRIP_METHODS = ["coop3", "local", "frozen"]


def rows(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def num(v, nd=4):
    return None if v in ("", None) else round(float(v), nd)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", required=True, help="the JavaScript file to write (data/recommendation.js)")
    args = ap.parse_args()

    cfg = json.load(open(os.path.join(OUT, "run_config.json")))
    if not cfg.get("same_trial"):
        raise SystemExit("output/ does not hold a verified run of run_demo.py")
    D = os.path.join(OUT, "dashboard")

    # ---- Monte Carlo over the paper's N-sweep
    mc_rows = rows(os.path.join(OUT, "montecarlo", "mc_summary.csv"))
    Ns = sorted({int(r["N"]) for r in mc_rows})
    trials = sorted({int(r["n"]) for r in mc_rows if r["metric"] == "agree"})
    mc = {}
    for metric in MC_METRICS:
        mc[metric] = {}
        for m in MC_METHODS:
            got = {int(r["N"]): r for r in mc_rows if r["metric"] == metric and r["method"] == m}
            if len(got) != len(Ns):
                continue
            nd = 2 if metric == "agree" else 4
            mc[metric][m] = {"x": Ns, "median": [num(got[N]["median"], nd) for N in Ns],
                             "q25": [num(got[N]["q25"], nd) for N in Ns], "q75": [num(got[N]["q75"], nd) for N in Ns],
                             "src": SRC + "montecarlo/mc_summary.csv"}

    # ---- the trial of Figure 3(b)
    kp = {r["method"]: r for r in rows(os.path.join(OUT, "kpis.csv"))}
    trial = {"N": cfg["N"], "trial": cfg["trial"], "seed": cfg["seed"], "window": cfg["rmse_window"],
             "src": SRC + "kpis.csv",
             "kpis": {m: {k: num(r[k], 4) for k in ("rmse", "forecast", "agree", "overlap", "exposure", "id", "unstable")}
                      for m, r in kp.items()}}

    # ---- the platform
    # the known average interests from run_demo's table (6 significant digits), so that rounding
    # them to 2 decimals agrees with the demo's README (the dashboard table keeps only 4)
    ubar = {r["code"]: r for r in rows(os.path.join(OUT, "data", "regions.csv"))}
    regions = [{"code": r["code"], "name": r["region"], "hub": r["data_center"], "server": int(r["server"]),
                "ubar": [num(ubar[r["code"]]["ubar_" + g], 2) for g in ("outdoor", "home", "tech")],
                "neighbors": r["neighbors"].split()} for r in rows(os.path.join(D, "regions.csv"))]
    links = [[r["from"], r["to"], r["kind"]] for r in rows(os.path.join(D, "links.csv"))]
    genres = ["Outdoor & Sports", "Home & Kitchen", "Trending Tech", "Everyday Essentials"]
    gkey = {"outdoor": 0, "home": 1, "tech": 2, "essentials": 3}
    cat = rows(os.path.join(D, "catalog.csv"))
    pidx = {r["product"]: k for k, r in enumerate(cat)}
    products = [[r["product"], r["name"], genres.index(r["genre"]), num(r["price_usd"], 2)] for r in cat]

    # ---- example users: first screens on the example days, and the days they differ from the ideal
    feeds = {}
    for r in rows(os.path.join(D, "feeds.csv")):
        u = feeds.setdefault((r["region"], r["kind"]), {})
        d = u.setdefault(r["day"], {})
        f = d.setdefault(r["method"], {"p": [], "x": [num(r["x_outdoor"], 3), num(r["x_home"], 3), num(r["x_tech"], 3)]})
        f["p"].append((int(r["rank"]), pidx[r["product"]]))
        assert gkey[r["genre"]] == products[pidx[r["product"]]][2]
    strips = {}
    for r in rows(os.path.join(D, "strip.csv")):
        strips.setdefault((r["region"], r["kind"], r["method"]), []).append((int(r["day"]), "0" if r["same"] == "1" else "1"))
    users = []
    for r in rows(os.path.join(D, "shoppers.csv")):
        key = (r["region"], r["kind"])
        days = sorted(feeds[key], key=int)
        fd = {}
        for day in days:
            fd[day] = {}
            for m in FEED_METHODS:
                f = feeds[key][day][m]
                ranked = [p for _, p in sorted(f["p"])]
                assert len(ranked) == 8
                fd[day][m] = {"p": ranked, "x": f["x"]}
        strip = {}
        for m in STRIP_METHODS:
            s = sorted(strips[(r["region"], r["kind"], m)])
            strip[m] = "".join(bit for _, bit in s)
            strip["from"] = s[0][0]
        users.append({"region": r["region"], "kind": r["kind"], "id": r["shopper"],
                      "affinity": [num(r["affinity_outdoor"], 2), num(r["affinity_home"], 2), num(r["affinity_tech"], 2)],
                      "differs": {"coop3": int(r["days_coop3_differs"]), "local": int(r["days_local_differs"]),
                                  "frozen": int(r["days_frozen_differs"])},
                      "days": int(r["days"]), "first": int(r["first_contrast_day"]),
                      "feedDays": [int(d) for d in days], "feeds": fd, "strip": strip})

    rec = {"about": {"title": "Recommendation systems: case study (B) with products and users",
                     "generator": "recommendation_demo/make_website_data.py",
                     "generated": datetime.date.today().isoformat(),
                     "note": "Users, products and region names are simulated; the model, the data the servers "
                             "receive and Algorithm 1 are the paper's (seed %d)." % cfg["seed"],
                     "metrics": MC_METRICS,
                     "users": "typical: affinities closest to the region's average; contrast: the user whose "
                              "first screen local learning got wrong, and cooperative learning right, on the most "
                              "days of the window",
                     "strip": "one character per day from 'from': 1 = the first screen differs from the ideal one"},
           "N": Ns, "trials": trials[0] if len(trials) == 1 else trials, "mc": mc, "trial": trial,
           "genres": genres, "products": products, "regions": regions, "links": links, "users": users}
    text = ("/* Data of the \"Recommendation systems\" section of the project page. Generated by\n"
            "   recommendation_demo/make_website_data.py from the demo's outputs (each series names its\n"
            "   source file in \"src\"). Do not edit. */\n"
            "window.RESULTS = window.RESULTS || {};\n"
            "window.RESULTS.REC = " + json.dumps(rec, separators=(",", ":"), ensure_ascii=False) + ";\n")
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(text)
    print("wrote %s (%.1f kB; %d users, %d products, metrics %s)" % (
        args.out, len(text.encode()) / 1024, len(users), len(products), ", ".join(mc)))


if __name__ == "__main__":
    main()
