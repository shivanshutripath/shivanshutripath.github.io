#!/usr/bin/env python3
"""
summarize.py -- prints the quantities quoted in the text of the experimental
section (ratios, percentages, ablation values) from the output of
experiments.py, so that every number in the paper is traceable.

    python3 summarize.py <output dir>
"""
import os
import sys

import numpy as np

out = sys.argv[1] if len(sys.argv) > 1 else "output"


def load(name):
    a = np.loadtxt(os.path.join(out, name), skiprows=1)
    return a


def series(tag, kind, key):
    a = load("%s_%s_%s.dat" % (tag, kind, key))
    return a[:, 0], a[:, 1]


def rng(v, fmt="%.2f"):
    return (fmt + "--" + fmt) % (min(v), max(v))


for tag, name in (("rv", "rendezvous"), ("rc", "recommendation")):
    if not os.path.exists(os.path.join(out, "%s_id_coop3.dat" % tag)):
        continue
    print("=" * 70)
    print(name)
    N, idc = series(tag, "id", "coop3")
    _, idl = series(tag, "id", "local")
    _, ide = series(tag, "id", "exact")
    _, idp = series(tag, "id", "pooledLS")
    _, idc1 = series(tag, "id", "coop1")
    print("  N:", N.astype(int).tolist())
    print("  id coop3  :", np.round(idc, 4).tolist())
    print("  id local  :", np.round(idl, 4).tolist())
    print("  id exact  :", np.round(ide, 4).tolist())
    print("  id pooled :", np.round(idp, 4).tolist())
    print("  local/coop3 ratio: %s   (sqrt m = %.2f)" % (rng(idl / idc), np.sqrt({"rv": 6, "rc": 8}[tag])))
    print("  coop3/exact ratio: %s ; coop1/exact: %s" % (rng(idc / ide), rng(idc1 / ide)))
    print("  pooled LS first->last: %.4f -> %.4f ; pooled/coop3 at N=200: %.2f" % (idp[0], idp[-1], idp[-1] / idc[-1]))
    u = load("%s_unstable.dat" % tag)
    print("  unstable (local, pooledLS, coop1, coop3, exact) per N:")
    for row in u:
        print("     N=%3d  " % row[0] + "  ".join("%.0f%%" % (100 * v) for v in row[1:]))
    R = {k: series(tag, "rmse", k)[1] for k in ("persistence", "local", "coop3", "centralized", "oracleA", "oracleKF", "exact", "coop1")}
    for k, v in R.items():
        print("  rmse %-12s" % k, np.round(v, 4).tolist())
    print("  coop3 vs local: %s %% lower" % rng(100 * (1 - R["coop3"] / R["local"]), "%.0f"))
    print("  persistence/coop3: %s x" % rng(R["persistence"] / R["coop3"]))
    print("  coop3/centralized: %s ; coop3/oracleA: %s ; coop3/oracleKF: %s" % (rng(R["coop3"] / R["centralized"]), rng(R["coop3"] / R["oracleA"]), rng(R["coop3"] / R["oracleKF"])))
    print("  oracleKF/oracleA: %s" % rng(R["oracleKF"] / R["oracleA"]))
    print("  N>=100: coop3/centralized %s ; coop3/oracleA %s" % (rng((R["coop3"] / R["centralized"])[2:]), rng((R["coop3"] / R["oracleA"])[2:])))
    # tau sweep
    if os.path.exists(os.path.join(out, "%s_tau_iderr.dat" % tag)):
        t = load("%s_tau_iderr.dat" % tag); r = load("%s_tau_rmse.dat" % tag); e = load("%s_tau_exact.dat" % tag)
        print("  tau-sweep: tau", t[:, 0].astype(int).tolist())
        print("     id   ", np.round(t[:, 1], 4).tolist(), " exact %.4f" % e[0, 1])
        print("     rmse ", np.round(r[:, 1], 4).tolist(), " rmse/final:", np.round(r[:, 1] / r[-1, 1], 3).tolist())
    # k sweep
    if os.path.exists(os.path.join(out, "%s_k_recon.dat" % tag)):
        k = load("%s_k_recon.dat" % tag)
        il = load("%s_k_idlocal.dat" % tag)[:, 1]; ic = load("%s_k_idcoop.dat" % tag)[:, 1]
        rl = load("%s_k_rmse_local.dat" % tag)[:, 1]; rc = load("%s_k_rmse_coop3.dat" % tag)[:, 1]; ro = load("%s_k_rmse_oracleA.dat" % tag)[:, 1]
        print("  k-sweep: k", k[:, 0].astype(int).tolist())
        print("     recon    ", np.round(k[:, 1], 3).tolist(), " argmin k=%d" % k[np.argmin(k[:, 1]), 0])
        print("     id local ", np.round(il, 4).tolist(), " argmin k=%d" % k[np.argmin(il), 0])
        print("     id coop  ", np.round(ic, 4).tolist(), " argmin k=%d" % k[np.argmin(ic), 0])
        print("     rmse loc ", np.round(rl, 4).tolist())
        print("     rmse coop", np.round(rc, 4).tolist(), " /min:", np.round(rc / rc.min(), 3).tolist())
        print("     rmse orac", np.round(ro, 4).tolist())
# m sweep
if os.path.exists(os.path.join(out, "rv_m_coop3.dat")):
    print("=" * 70)
    m, c = series("rv", "m", "coop3"); _, e = series("rv", "m", "exact"); _, l = series("rv", "m", "local"); _, ref = series("rv", "m", "ref")
    sig = load("rv_m_sigma.dat")[:, 1]
    print("m-sweep: m", m.astype(int).tolist(), " sigma", np.round(sig, 2).tolist())
    print("   exact ", np.round(e, 4).tolist(), " ref 1/sqrt(m):", np.round(ref, 4).tolist(), " exact/ref:", np.round(e / ref, 2).tolist())
    print("   coop3 ", np.round(c, 4).tolist(), " coop3/exact:", np.round(c / e, 2).tolist())
    print("   local ", np.round(l, 4).tolist())
