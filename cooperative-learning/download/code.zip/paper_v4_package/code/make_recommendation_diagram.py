#!/usr/bin/env python3
"""
make_recommendation_diagram.py -- schematic of case study (B), decentralized
federated recommendation (Figure 3(a)).

    python3 make_recommendation_diagram.py <output dir> [--splice ../main.tex]

Writes, from one geometry definition,
  recommendation_setup.drawio  -- draw.io / diagrams.net file (open, edit, export);
  recommendation_setup.tex     -- the same drawing as a tikzpicture for main.tex.

The eight regional servers of the paper's instance on the backbone, a ring
1-2-...-8-1 with the chords (1,5) and (3,7) (solid lines).  Server i receives
the engagement data of the users of region i only (dashed arrows, during data
collection t < N).  The primitives and the two exporters are those of
make_rendezvous_diagram.py, so that the two schematics share one style.
"""
import os
import sys

import numpy as np

_args = sys.argv[1:]
SPLICE = None
if "--splice" in _args:                       # --splice ../main.tex
    k = _args.index("--splice")
    SPLICE = _args[k + 1]
    del _args[k:k + 2]
OUT = _args[0] if _args else "."
BEGIN = "% ---- BEGIN generated figure: recommendation_setup"
END = "% ---- END generated figure: recommendation_setup ----"

sys.argv = sys.argv[:1]                       # the imported module parses sys.argv
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_rendezvous_diagram as R  # noqa: E402  (primitives, colours, exporters)

R.SHAPES.clear()                              # drop the drawing of case study (A)
R.GROUPS.clear()
COL = R.COL
line, rect, circle, text = R.line, R.rect, R.circle, R.text


# ----------------------------------------------------------------------------
# icons
# ----------------------------------------------------------------------------
def server(c, s, label):
    """Regional server (rack unit with two status lights), width s (cm), with its index."""
    g = "srv%d" % len(R.GROUPS)
    R.GROUPS[g] = (c, s)
    w, h = 0.9 * s, 0.6 * s
    rect(c, w, h, COL["robotdark"], COL["robot"], 0.6, rounded=0.25, group=g)
    for dy in (0.12, -0.12):
        circle((c[0] + 0.28 * s, c[1] + dy * s), 0.055 * s, COL["robotdark"], "#FFFFFF", 0.4, group=g)
    text((c[0] - 0.1 * s, c[1]), "$%s$" % label, plain=str(label),
         size="scriptsize" if s < 0.45 else "footnotesize")


def person(c, s, g):
    """One user, height about s (cm): head and shoulders."""
    rect((c[0], c[1] - 0.2 * s), 0.62 * s, 0.42 * s, COL["uav"], COL["uavfill"], 0.5, rounded=0.5, group=g)
    circle((c[0], c[1] + 0.2 * s), 0.19 * s, COL["uav"], COL["uavfill"], 0.5, group=g)


def users(c, s):
    """The users of one region: three people, size s (cm)."""
    g = "usr%d" % len(R.GROUPS)
    R.GROUPS[g] = (c, s)
    person((c[0], c[1] + 0.16 * s), 0.55 * s, g)              # back
    for dx in (-0.3, 0.3):
        person((c[0] + dx * s, c[1] - 0.08 * s), 0.55 * s, g)  # front


# ----------------------------------------------------------------------------
# layout: servers, their users, data and backbone links
# ----------------------------------------------------------------------------
M = 8
CHORDS = [(1, 5), (3, 7)]                     # 1-based, as in experiments.py
R.W, R.H = 6.2, 5.45                          # figure size (cm), as Figure 1(a)
CB = (3.1, 3.13)                              # center of the server ring
RS, RU = 1.2, 2.1                             # radii of the servers and of the users

ang = np.radians(22.5 + 45.0 * np.arange(M))  # server 1 at the right, counter-clockwise
spos = [R.polar(CB, RS, a) for a in ang]
upos = [R.polar(CB, RU, a) for a in ang]
edges = [(i, (i + 1) % M) for i in range(M)] + [(a - 1, b - 1) for a, b in CHORDS]
for (i, j) in edges:
    line([spos[i], spos[j]], COL["comm"], 0.9)
for i in range(M):
    p0, p1 = R.shorten(upos[i], spos[i], 0.3, 0.33)
    line([p0, p1], COL["sense"], 0.8, dash="dashed", arrow=True)
    users(upos[i], 0.5)
for i in range(M):
    server(spos[i], 0.56, i + 1)

# legend, one line
LY = 0.3
server((0.25, LY), 0.46, "i")
text((0.55, LY), "server $i$", plain="server i", anchor="west")
users((1.98, LY + 0.02), 0.4)
text((2.25, LY), "users, region $i$", plain="users, region i", anchor="west")
line([(4.62, LY), (5.07, LY)], COL["comm"], 0.9)
text((5.17, LY), "link", plain="link", anchor="west")


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    tikz = R.export_tikz()
    drawio = R.export_drawio().replace('id="rendezvous" name="Case study (A): charging station"',
                                       'id="recommendation" name="Case study (B): recommendation"')
    with open(os.path.join(OUT, "recommendation_setup.tex"), "w") as f:
        f.write(tikz)
    with open(os.path.join(OUT, "recommendation_setup.drawio"), "w") as f:
        f.write(drawio)
    print("wrote", os.path.join(OUT, "recommendation_setup.tex"), "and",
          os.path.join(OUT, "recommendation_setup.drawio"))
    if SPLICE:
        src = open(SPLICE).read()
        i = src.index(BEGIN)
        i = src.index("\n", i) + 1
        j = src.index(END)
        j = src.rindex("\n", 0, j) + 1
        src = src[:i] + tikz.rstrip("\n") + "\n" + src[j:]
        with open(SPLICE, "w") as f:
            f.write(src)
        print("spliced into", SPLICE)
