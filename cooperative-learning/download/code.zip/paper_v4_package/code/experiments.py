#!/usr/bin/env python3
"""
experiments.py
==============

Reproduces all numerical experiments of

    "Cooperative Learning of Shared Latent Dynamics for Distributed Online
     Optimization"  (Algorithm 1: windowed Gauss--Markov reconstruction,
     cooperative instrumental-variable identification by average consensus,
     gradient tracking on forecast gradients).

Three case studies (parameters in Table 1 of the paper):
    rendezvous      -- case study (A) of the paper: six ground control stations
                       positioning a charging cart for six patrol UAVs (quadratic costs)
    congestion      -- five regional traffic agents, softplus congestion costs
    recommendation  -- eight regional servers, logistic engagement costs

Experiments (all with 50 trials, tracking horizon T = N + 200):
    N-sweep   N in {30, 50, 100, 150, 200} for every case study, all methods
    m-sweep   identical agents of case study (A), m in {2, 4, 8, 16, 32}, N = 100
    tau-sweep recommendation, N = 100, consensus rounds in {0, 1, 2, 3, 5, 10}
    k-sweep   congestion, N = 150, window length in {1, 2, 3, 5, 8, 12, 16}
    trial     one trial of each case study with N = 100 (time series)

Outputs (whitespace separated .dat files with a header row, read by the
pgfplots figures in figs/, plus table_results.tex):
    python3 experiments.py --out output            # everything (~10 min)
    python3 experiments.py --out output --quick    # 5 trials, for testing
    python3 experiments.py --out output --only nsweep,trial

The .dat files have the same names and columns as those in figs/data, so a
fresh run can replace them.  Only numpy is required.
"""
import argparse
import os
import time
from dataclasses import dataclass, field

import numpy as np

# ----------------------------------------------------------------------------
# linear algebra helpers
# ----------------------------------------------------------------------------
def rot(w):
    c, s = np.cos(w), np.sin(w)
    return np.array([[c, -s], [s, c]])


def spectral_radius(A):
    return float(np.max(np.abs(np.linalg.eigvals(A))))


def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))


def softplus(z):
    return np.logaddexp(0.0, z)


def metropolis(adj):
    """Metropolis weights of an undirected graph given its adjacency matrix."""
    m = adj.shape[0]
    deg = adj.sum(axis=1)
    W = np.zeros((m, m))
    for i in range(m):
        for j in range(m):
            if i != j and adj[i, j]:
                W[i, j] = 1.0 / (1.0 + max(deg[i], deg[j]))
        W[i, i] = 1.0 - W[i].sum()
    return W


def ring_graph(m, chords=()):
    adj = np.zeros((m, m), dtype=bool)
    for i in range(m):
        adj[i, (i + 1) % m] = adj[(i + 1) % m, i] = True
    for (a, b) in chords:  # 1-based labels as in the paper
        adj[a - 1, b - 1] = adj[b - 1, a - 1] = True
    return adj


def ring_with_diameters(m):
    adj = ring_graph(m)
    if m >= 4:
        for i in range(m // 2):
            adj[i, i + m // 2] = adj[i + m // 2, i] = True
    return adj


def contraction(W):
    m = W.shape[0]
    return float(np.linalg.norm(W - np.ones((m, m)) / m, 2))


def stationary_cov(A, Q, iters=5000):
    S = Q.copy()
    for _ in range(iters):
        S = A @ S @ A.T + Q
    return S


# ----------------------------------------------------------------------------
# case studies
# ----------------------------------------------------------------------------
PROJECTION = False   # set by --projection: project the forecasts onto the boxes B_i


@dataclass
class CaseStudy:
    """Problem instance: costs f_i(x, theta_i) = f_i^0(x) + g_i(x)^T theta_i."""
    name: str
    m: int
    n: int
    p: int
    A: np.ndarray
    Q: np.ndarray
    R: np.ndarray
    P0: np.ndarray
    W: np.ndarray
    k: int
    alpha: float
    box_lo: np.ndarray  # projection set B_i = {lo_i <= theta <= hi_i}, shape (m, p)
    box_hi: np.ndarray
    params: dict = field(default_factory=dict)

    # --- cost model: to be provided by subclasses ---
    def grad_f0(self, i, x):
        raise NotImplementedError

    def C(self, i, x):
        """C_i(x) = d g_i^T / d x, shape (n, p)."""
        raise NotImplementedError

    def hess(self, i, x, theta):
        raise NotImplementedError

    def explore(self, i, t, x_iter):
        """Exploration point x_i^e(t)."""
        raise NotImplementedError

    def single_query(self):
        """True if the oracle query at the iterate also serves identification."""
        return False

    # --- derived quantities ---
    def grad(self, i, x, theta):
        return self.grad_f0(i, x) + self.C(i, x) @ theta

    def grad_F(self, x, Theta):
        return sum(self.grad(i, x, Theta[i]) for i in range(self.m))

    def hess_F(self, x, Theta):
        return sum(self.hess(i, x, Theta[i]) for i in range(self.m))

    def minimizer(self, Theta, x0=None):
        """Exact minimizer of F(., Theta) by damped Newton (Levenberg--Marquardt
        regularization if the Hessian is not positive definite)."""
        x = np.zeros(self.n) if x0 is None else x0.copy()
        for _ in range(100):
            g = self.grad_F(x, Theta)
            if np.linalg.norm(g) < 1e-10:
                break
            Hm = self.hess_F(x, Theta)
            lmin = np.linalg.eigvalsh(Hm).min()
            if lmin < 1e-6:
                Hm = Hm + (1e-6 - lmin) * np.eye(self.n)
            d = -np.linalg.solve(Hm, g)
            step = 1.0
            F0 = self.value_F(x, Theta)
            while self.value_F(x + step * d, Theta) > F0 + 1e-4 * step * g @ d and step > 1e-8:
                step *= 0.5
            x = x + step * d
        return x

    def value_F(self, x, Theta):
        return sum(self.value(i, x, Theta[i]) for i in range(self.m))

    def value(self, i, x, theta):
        raise NotImplementedError

    def project(self, i, theta):
        if not PROJECTION:
            return theta
        return np.minimum(np.maximum(theta, self.box_lo[i]), self.box_hi[i])


class Rendezvous(CaseStudy):
    """Case study (A), the charging cart for patrol UAVs, with every
    UAV holding its observation location (route p_i(t) = bbar_i, case study (A) of Section 5.1):
    f_i = h_i ||x - bbar_i - theta_i||^2  (C_i = -2 h_i I, constant), with
    bbar_i the observation location and h_i the service rate of UAV i."""

    def __init__(self, rng, m=6, identical=False, graph=None):
        n = p = 2
        A = 0.99 * rot(0.15)      # = [[0.979, -0.148], [0.148, 0.979]], the matrix printed in the paper
        Q, R, P0 = 0.05 ** 2 * np.eye(2), 1.5 ** 2 * np.eye(2), 4.0 ** 2 * np.eye(2)
        if identical:
            h = np.ones(m)
        else:
            h = rng.uniform(0.5, 1.5, size=m)
        radius = rng.uniform(3.0, 8.0, size=m)
        ang = 2 * np.pi * np.arange(m) / m
        bbar = np.column_stack([radius * np.cos(ang), radius * np.sin(ang)])
        adj = ring_graph(m, chords=[(1, 4), (2, 5), (3, 6)]) if graph is None else graph
        W = metropolis(adj)
        box = 20.0 * np.ones((m, p))
        super().__init__("rendezvous", m, n, p, A, Q, R, P0, W, k=2, alpha=0.2,
                         box_lo=-box, box_hi=box, params=dict(h=h, bbar=bbar))
        self.h, self.bbar = h, bbar

    def grad_f0(self, i, x):
        return 2 * self.h[i] * (x - self.bbar[i])

    def C(self, i, x):
        return -2 * self.h[i] * np.eye(2)

    def hess(self, i, x, theta):
        return 2 * self.h[i] * np.eye(2)

    def value(self, i, x, theta):
        return self.h[i] * np.sum((x - self.bbar[i] - theta) ** 2)

    def explore(self, i, t, x_iter):
        return x_iter

    def single_query(self):
        return True

    def minimizer(self, Theta, x0=None):  # closed form
        hb = self.h[:, None] * (self.bbar + Theta)
        return hb.sum(axis=0) / self.h.sum()


class Congestion(CaseStudy):
    """f_i = varpi_i/2 ||x||^2 + sum_l (dbar_il + theta_il) softplus(a_il^T x - l0)."""

    def __init__(self, rng, m=5):
        n = p = 2
        A = 0.99 * rot(0.2)
        Q, R, P0 = 0.03 ** 2 * np.eye(2), 0.2 ** 2 * np.eye(2), 1.2 ** 2 * np.eye(2)
        varpi = rng.uniform(0.2, 0.4, size=m)
        dbar = rng.uniform(1.5, 2.5, size=(m, 2))
        phi = rng.uniform(0, 2 * np.pi, size=m)  # two orthogonal corridor directions per agent
        a = np.zeros((m, 2, 2))
        for i in range(m):
            a[i, 0] = [np.cos(phi[i]), np.sin(phi[i])]
            a[i, 1] = [-np.sin(phi[i]), np.cos(phi[i])]
        W = metropolis(ring_graph(m))
        lo = np.maximum(-dbar, -5.0)
        hi = 5.0 * np.ones((m, p))
        super().__init__("congestion", m, n, p, A, Q, R, P0, W, k=5, alpha=0.3,
                         box_lo=lo, box_hi=hi, params=dict(varpi=varpi, dbar=dbar, a=a, l0=0.5))
        self.varpi, self.dbar, self.a, self.l0 = varpi, dbar, a, 0.5
        self.psi = 2 * np.pi / ((1 + np.sqrt(5)) / 2) ** 2  # golden angle

    def grad_f0(self, i, x):
        z = self.a[i] @ x - self.l0
        return self.varpi[i] * x + self.a[i].T @ (self.dbar[i] * sigmoid(z))

    def C(self, i, x):
        z = self.a[i] @ x - self.l0
        return (self.a[i] * sigmoid(z)[:, None]).T  # columns sigma(z_l) a_il

    def hess(self, i, x, theta):
        z = self.a[i] @ x - self.l0
        s = sigmoid(z)
        w = (self.dbar[i] + theta) * s * (1 - s)
        return self.varpi[i] * np.eye(2) + self.a[i].T @ (w[:, None] * self.a[i])

    def value(self, i, x, theta):
        z = self.a[i] @ x - self.l0
        return 0.5 * self.varpi[i] * x @ x + np.sum((self.dbar[i] + theta) * softplus(z))

    def explore(self, i, t, x_iter):
        return np.array([np.cos(self.psi * t), np.sin(self.psi * t)])


class Recommendation(CaseStudy):
    """f_i = varpi_i/2 ||x||^2 + sum_l (ubar_il + theta_il) softplus(-x_l)."""

    def __init__(self, rng, m=8):
        n = p = 3
        A = np.zeros((3, 3))
        A[:2, :2] = 0.98 * rot(0.25)
        A[2, 2] = 0.95
        Q, R, P0 = 0.02 ** 2 * np.eye(3), 0.15 ** 2 * np.eye(3), 1.5 ** 2 * np.eye(3)
        varpi = rng.uniform(0.4, 0.8, size=m)
        ubar = rng.uniform(1.0, 3.0, size=(m, 3))
        W = metropolis(ring_graph(m, chords=[(1, 5), (3, 7)]))
        lo = np.maximum(-ubar, -5.0)
        hi = 5.0 * np.ones((m, p))
        super().__init__("recommendation", m, n, p, A, Q, R, P0, W, k=3, alpha=0.25,
                         box_lo=lo, box_hi=hi, params=dict(varpi=varpi, ubar=ubar))
        self.varpi, self.ubar = varpi, ubar

    def grad_f0(self, i, x):
        return self.varpi[i] * x - self.ubar[i] * sigmoid(-x)

    def C(self, i, x):
        return -np.diag(sigmoid(-x))

    def hess(self, i, x, theta):
        s = sigmoid(-x)
        return self.varpi[i] * np.eye(3) + np.diag((self.ubar[i] + theta) * s * (1 - s))

    def value(self, i, x, theta):
        return 0.5 * self.varpi[i] * x @ x + np.sum((self.ubar[i] + theta) * softplus(-x))

    def explore(self, i, t, x_iter):
        return np.zeros(3)


CASE_ID = {"rendezvous": 1, "congestion": 2, "recommendation": 3}  # deterministic seeds


def make_case(name, rng):
    return {"rendezvous": Rendezvous, "congestion": Congestion, "recommendation": Recommendation}[name](rng)


# ----------------------------------------------------------------------------
# Algorithm 1: reconstruction, identification, forecasting
# ----------------------------------------------------------------------------
def window_estimates(cs, Y, Cs, N, k):
    """Gauss--Markov window estimates (eq. (5)) for t = 0, ..., N-k.

    Y[i, t]  : measurement ytilde_i(t) = C_{i,t} theta_i(t) + noise, shape (m, N, n)
    Cs[i, t] : C_{i,t}, shape (m, N, n, p)
    Returns theta_tilde of shape (m, N-k+1, p)."""
    m, p = cs.m, cs.p
    Rinv = np.linalg.inv(cs.R)
    out = np.zeros((m, N - k + 1, p))
    for i in range(m):
        for t in range(N - k + 1):
            Cbar = Cs[i, t:t + k].reshape(k * cs.n, p)
            ybar = Y[i, t:t + k].reshape(k * cs.n)
            RinvBar = np.kron(np.eye(k), Rinv)
            G = Cbar.T @ RinvBar @ Cbar
            out[i, t] = np.linalg.solve(G, Cbar.T @ RinvBar @ ybar)
    return out


def iv_moments(theta_tilde, N, k):
    """Local IV moments (eq. (8)): M_j = 1/(N-2k) sum_{t=k}^{N-k-1} th(t+j) th(t-k)^T."""
    m, _, p = theta_tilde.shape
    M0 = np.zeros((m, p, p))
    M1 = np.zeros((m, p, p))
    ts = np.arange(k, N - k)
    for i in range(m):
        Z = theta_tilde[i, ts - k]
        M0[i] = theta_tilde[i, ts].T @ Z / len(ts)
        M1[i] = theta_tilde[i, ts + 1].T @ Z / len(ts)
    return M0, M1


def ls_moments(theta_tilde, N, k):
    """Least-squares moments (pooled least squares baseline)."""
    m, _, p = theta_tilde.shape
    M0 = np.zeros((m, p, p))
    M1 = np.zeros((m, p, p))
    ts = np.arange(0, N - k)
    for i in range(m):
        Z = theta_tilde[i, ts]
        M0[i] = Z.T @ Z / len(ts)
        M1[i] = theta_tilde[i, ts + 1].T @ Z / len(ts)
    return M0, M1


def consensus(M, W, tau):
    """tau rounds of average consensus on a stack of matrices, shape (m, p, p)."""
    out = M.copy()
    for _ in range(tau):
        out = np.einsum("il,lab->iab", W, out)
    return out


def identify(M0, M1, W, tau, rho_max=0.999):
    """Estimates A^(i) = M1^(i) (M0^(i))^{-1} after tau rounds (tau=None: exact
    averaging).  Returns the safeguarded estimates and the raw spectral radii."""
    m = M0.shape[0]
    if tau is None:
        M0c = np.repeat(M0.mean(axis=0, keepdims=True), m, axis=0)
        M1c = np.repeat(M1.mean(axis=0, keepdims=True), m, axis=0)
    else:
        M0c, M1c = consensus(M0, W, tau), consensus(M1, W, tau)
    A_hat = np.zeros_like(M0)
    rho_raw = np.zeros(m)
    for i in range(m):
        A_hat[i] = M1c[i] @ np.linalg.inv(M0c[i])
        rho_raw[i] = spectral_radius(A_hat[i])
        if rho_raw[i] > rho_max:  # safeguard: rescale to spectral radius rho_max
            A_hat[i] *= rho_max / rho_raw[i]
    return A_hat, rho_raw


def kalman_forecast_state(cs, Y, Cs, N):
    """Oracle Kalman filter on the exploration data of each agent (knows A, Q,
    R, P0); returns the filtered state at time N-1, shape (m, p)."""
    m, p = cs.m, cs.p
    out = np.zeros((m, p))
    for i in range(m):
        x, P = np.zeros(p), cs.P0.copy()
        for t in range(N):
            if t > 0:
                x, P = cs.A @ x, cs.A @ P @ cs.A.T + cs.Q
            C = Cs[i, t]
            S = C @ P @ C.T + cs.R
            K = P @ C.T @ np.linalg.inv(S)
            x = x + K @ (Y[i, t] - C @ x)
            P = (np.eye(p) - K @ C) @ P
        out[i] = x
    return out


# ----------------------------------------------------------------------------
# simulation of one trial
# ----------------------------------------------------------------------------
class Forecaster:
    """theta_hat_i(t) = P_B( A_i^(t - t0) anchor_i ) for t >= N."""

    def __init__(self, cs, A_list, anchors, t0):
        self.cs, self.A_list, self.anchors, self.t0 = cs, A_list, anchors, t0
        self.powers = [np.eye(cs.p) for _ in range(cs.m)]
        self.t_cur = t0

    def at(self, t):
        # powers are advanced sequentially (t is non-decreasing)
        while self.t_cur < t:
            self.powers = [Pw @ A for Pw, A in zip(self.powers, self.A_list)]
            self.t_cur += 1
        return np.array([self.cs.project(i, self.powers[i] @ self.anchors[i]) for i in range(self.cs.m)])


def gradient_tracking_phase(cs, X, S, G_prev, t_start, t_end, grad_signal):
    """Runs (11) from t_start to t_end-1; grad_signal(t, X) returns the stacked
    gradient signals gamma_i(t) at the iterates X (shape (m, n)).  Returns the
    trajectory of iterates X[t] for t in [t_start, t_end] (list) and the final
    state."""
    W, alpha = cs.W, cs.alpha
    traj = [X.copy()]
    for t in range(t_start, t_end):
        X_new = W @ (X - alpha * S)
        G_new = grad_signal(t + 1, X_new)
        S = W @ (S + G_new - G_prev)
        X, G_prev = X_new, G_new
        traj.append(X.copy())
    return traj, X, S, G_prev


def run_trial(cs, N, rng, taus=(3,), extra=True, k=None, want_series=False, m_sweep=False):
    """Simulates one trial.  Returns a dict of metrics (and series)."""
    m, n, p, T = cs.m, cs.n, cs.p, N + 200
    k = cs.k if k is None else k
    A, Q, R = cs.A, cs.Q, cs.R
    Lq, Lr, Lp = np.linalg.cholesky(Q), np.linalg.cholesky(R), np.linalg.cholesky(cs.P0)

    # latent parameters theta_i(t), t = 0..T-1
    Theta = np.zeros((T, m, p))
    Theta[0] = rng.standard_normal((m, p)) @ Lp.T
    for t in range(1, T):
        Theta[t] = Theta[t - 1] @ A.T + rng.standard_normal((m, p)) @ Lq.T
    # true minimizers x*(t)
    xstar = np.zeros((T, n))
    x_prev = None
    for t in range(T):
        xstar[t] = cs.minimizer(Theta[t], x_prev)
        x_prev = xstar[t]

    # ---- data collection with gradient tracking driven by oracle gradients ----
    Y = np.zeros((m, N, n))        # exploration measurements ytilde_i(t)
    Cs = np.zeros((m, N, n, p))    # C_{i,t}
    X = np.zeros((m, n))           # x_i(0) = 0

    def oracle_signal(t, Xcur):
        G = np.zeros((m, n))
        for i in range(m):
            G[i] = cs.grad(i, Xcur[i], Theta[t, i]) + Lr @ rng.standard_normal(n)
        return G

    def record_exploration(t, Xcur, Gcur):
        for i in range(m):
            xe = cs.explore(i, t, Xcur[i])
            Cs[i, t] = cs.C(i, xe)
            if cs.single_query():  # the oracle query at the iterate serves both
                Y[i, t] = Gcur[i] - cs.grad_f0(i, Xcur[i])
            else:
                Y[i, t] = Cs[i, t] @ Theta[t, i] + Lr @ rng.standard_normal(n)

    G = oracle_signal(0, X)
    S = G.copy()
    record_exploration(0, X, G)
    traj_data = [X.copy()]
    for t in range(0, N - 1):
        X_new = cs.W @ (X - cs.alpha * S)
        G_new = oracle_signal(t + 1, X_new)
        record_exploration(t + 1, X_new, G_new)
        S = cs.W @ (S + G_new - G)
        X, G = X_new, G_new
        traj_data.append(X.copy())
    X_N1, S_N1, G_N1 = X, S, G  # state at t = N-1

    # ---- identification ----
    if 2 * k >= N - 1:
        raise ValueError("N too small for window length k")
    th = window_estimates(cs, Y, Cs, N, k)         # t = 0..N-k
    M0, M1 = iv_moments(th, N, k)
    anchors = th[:, N - k]                          # theta_tilde_i(N-k)
    recon_err = np.sqrt(np.mean(np.sum((th - Theta[:N - k + 1].transpose(1, 0, 2)) ** 2, axis=2)))

    estimates = {}
    estimates["local"] = identify(M0, M1, cs.W, 0)
    for tau in taus:
        estimates["coop%d" % tau] = identify(M0, M1, cs.W, tau)
    estimates["exact"] = identify(M0, M1, cs.W, None)
    if extra:
        L0, L1 = ls_moments(th, N, k)
        estimates["pooledLS"] = identify(L0, L1, cs.W, None)
    out = {"recon": recon_err, "id": {}, "unstable": {}}
    for key, (Ah, rho) in estimates.items():
        out["id"][key] = np.linalg.norm(Ah - A, axis=(1, 2))   # per agent
        out["unstable"][key] = np.mean(rho >= 1.0)
    if m_sweep:
        return out

    # ---- tracking phase for every forecaster ----
    forecasters = {}
    for key, (Ah, rho) in estimates.items():
        forecasters[key] = Forecaster(cs, list(Ah), anchors, N - k)
    if extra:
        forecasters["persistence"] = Forecaster(cs, [np.eye(p)] * m, anchors, N - k)
        forecasters["oracleA"] = Forecaster(cs, [A] * m, anchors, N - k)
        forecasters["oracleKF"] = Forecaster(cs, [A] * m, kalman_forecast_state(cs, Y, Cs, N), N - 1)

    def rmse_of(traj):  # traj[t - N] = X(t) for t = N..T-1 (stack (m, n)) ; network-average RMSE over [N+50, N+200)
        err = np.array([np.mean(np.sum((traj[t - N] - xstar[t]) ** 2, axis=1)) for t in range(N + 50, T)])
        return float(np.sqrt(np.mean(err)))

    out["rmse"] = {}
    series = {}
    for key, fc in forecasters.items():
        def forecast_signal(t, Xcur, fc=fc):
            Th = fc.at(t)
            return np.array([cs.grad(i, Xcur[i], Th[i]) for i in range(m)])
        # at t = N the gradient signal switches to the forecast gradient; the
        # tracker is updated with gamma(N) - gamma(N-1) as in Algorithm 1
        X = cs.W @ (X_N1 - cs.alpha * S_N1)
        G_N = forecast_signal(N, X)
        S = cs.W @ (S_N1 + G_N - G_N1)
        traj, _, _, _ = gradient_tracking_phase(cs, X, S, G_N, N, T - 1, forecast_signal)
        out["rmse"][key] = rmse_of(traj)
        if want_series:
            series[key] = (traj, fc)
    if extra:
        # centralized predictor: exact minimizer of F_hat(., t) from the cooperative forecasts
        fc = Forecaster(cs, list(estimates["coop%d" % taus[0]][0]), anchors, N - k)
        xh, xh_prev = [], None
        for t in range(N, T):
            xh_prev = cs.minimizer(fc.at(t), xh_prev)
            xh.append(np.repeat(xh_prev[None, :], m, axis=0))
        out["rmse"]["centralized"] = rmse_of(xh)

    if want_series:
        key = "coop%d" % taus[0]
        out["series"] = {
            "Theta": Theta, "xstar": xstar, "th": th, "N": N, "k": k,
            "traj_data": traj_data,
            "traj_coop": series[key][0], "traj_local": series["local"][0],
        }
        # forecasts of agent 0 for the time-series figure
        fcs = {kk: Forecaster(cs, list(estimates[kk][0]), anchors, N - k) for kk in (key, "local")}
        out["series"]["fore_coop"] = np.array([fcs[key].at(t)[0] for t in range(N, T)])
        out["series"]["fore_local"] = np.array([fcs["local"].at(t)[0] for t in range(N, T)])
    return out


# ----------------------------------------------------------------------------
# experiments and output files
# ----------------------------------------------------------------------------
def _worker(job):
    """One trial (picklable for multiprocessing)."""
    global PROJECTION
    kind, seed, name, N, tr, kw = job
    kw = dict(kw)
    PROJECTION = kw.pop("projection", PROJECTION)
    if kind == "msweep":
        m = kw["m"]
        cs = Rendezvous(np.random.default_rng([seed, 7, m]), m=m, identical=True, graph=ring_with_diameters(m))
        rng = np.random.default_rng([seed, 7, m, tr])
        return run_trial(cs, N, rng, taus=(3,), extra=False, m_sweep=True)
    cs = make_case(name, np.random.default_rng([seed, CASE_ID[name]]))
    rng = np.random.default_rng([seed, CASE_ID[name], N, tr])
    return run_trial(cs, N, rng, **kw)


def run_jobs(jobs, jobs_n):
    jobs = [(kind, seed, name, N, tr, dict(kw, projection=PROJECTION)) for (kind, seed, name, N, tr, kw) in jobs]
    if jobs_n > 1:
        import multiprocessing as mp
        with mp.Pool(jobs_n) as pool:
            return pool.map(_worker, jobs)
    return [_worker(j) for j in jobs]


def write_dat(path, header, cols):
    arr = np.column_stack(cols)
    with open(path, "w") as f:
        f.write("  ".join(header) + "\n")
        for row in arr:
            f.write("  ".join("%.6g" % v for v in row) + "\n")


def quantiles(values):
    v = np.asarray(values).ravel()
    return np.median(v), np.percentile(v, 25), np.percentile(v, 75)


RMSE_KEYS = ["persistence", "local", "coop1", "coop3", "exact", "centralized", "oracleA", "oracleKF"]
ID_KEYS = ["local", "pooledLS", "coop1", "coop3", "exact"]
TAG = {"rendezvous": "rv", "congestion": "cg", "recommendation": "rc"}


def n_sweep(name, Ns, trials, seed, out, log, jobs_n=1):
    """N-sweep for one case study; writes <tag>_rmse_<method>.dat and
    <tag>_id_<method>.dat (medians) plus *_band.dat (interquartile ranges)."""
    tag = TAG[name]
    med = {"rmse": {k: [] for k in RMSE_KEYS}, "id": {k: [] for k in ID_KEYS}}
    band = {"rmse": {k: [] for k in RMSE_KEYS}, "id": {k: [] for k in ID_KEYS}}
    unstable = {k: [] for k in ID_KEYS}
    rows = []
    for N in Ns:
        t0 = time.time()
        rmse = {k: [] for k in RMSE_KEYS}
        ids = {k: [] for k in ID_KEYS}
        unst = {k: [] for k in ID_KEYS}
        results = run_jobs([("nsweep", seed, name, N, tr, dict(taus=(3, 1))) for tr in range(trials)], jobs_n)
        for res in results:
            for k in RMSE_KEYS:
                rmse[k].append(res["rmse"][k])
            for k in ID_KEYS:
                ids[k].extend(res["id"][k])
                unst[k].append(res["unstable"][k])
        row = [N]
        for k in RMSE_KEYS:
            q = quantiles(rmse[k]); med["rmse"][k].append(q[0]); band["rmse"][k].append(q[1:]); row.append(q[0])
        for k in ID_KEYS:
            q = quantiles(ids[k]); med["id"][k].append(q[0]); band["id"][k].append(q[1:]); row.append(q[0])
            unstable[k].append(np.mean(unst[k]))
        rows.append(row)
        log("  %s N=%3d  rmse coop3 %.4f local %.4f | id coop3 %.4f local %.4f | unstable local %.0f%% coop %.0f%%  (%.0fs)" % (
            name, N, med["rmse"]["coop3"][-1], med["rmse"]["local"][-1], med["id"]["coop3"][-1], med["id"]["local"][-1],
            100 * unstable["local"][-1], 100 * unstable["coop3"][-1], time.time() - t0))
    Ns = np.array(Ns, float)
    for k in RMSE_KEYS:
        write_dat(os.path.join(out, "%s_rmse_%s.dat" % (tag, k)), ["x", "y"], [Ns, med["rmse"][k]])
    for k in ("local", "coop3"):
        b = np.array(band["rmse"][k]); write_dat(os.path.join(out, "%s_rmse_%s_band.dat" % (tag, k)), ["x", "lo", "hi"], [Ns, b[:, 0], b[:, 1]])
    for k in ID_KEYS:
        write_dat(os.path.join(out, "%s_id_%s.dat" % (tag, k)), ["x", "y"], [Ns, med["id"][k]])
    for k in ("local", "coop3"):
        b = np.array(band["id"][k]); write_dat(os.path.join(out, "%s_id_%s_band.dat" % (tag, k)), ["x", "lo", "hi"], [Ns, b[:, 0], b[:, 1]])
    write_dat(os.path.join(out, "%s_unstable.dat" % tag), ["x"] + ID_KEYS, [Ns] + [unstable[k] for k in ID_KEYS])
    return rows, unstable


def m_sweep(ms, trials, seed, out, log, jobs_n=1):
    """Identical rendezvous robots on a ring with diametral chords, N=100."""
    N = 100
    med = {k: [] for k in ("local", "coop3", "exact")}
    band = {k: [] for k in med}
    sigmas = []
    for m in ms:
        ids = {k: [] for k in med}
        cs = Rendezvous(np.random.default_rng([seed, 7, m]), m=m, identical=True, graph=ring_with_diameters(m))
        sigmas.append(contraction(cs.W))
        for res in run_jobs([("msweep", seed, "rendezvous", N, tr, dict(m=m)) for tr in range(trials)], jobs_n):
            for k in med:
                ids[k].extend(res["id"][k])
        for k in med:
            q = quantiles(ids[k]); med[k].append(q[0]); band[k].append(q[1:])
        log("  m-sweep m=%2d sigma=%.2f  id local %.4f coop3 %.4f exact %.4f" % (m, sigmas[-1], med["local"][-1], med["coop3"][-1], med["exact"][-1]))
    ms = np.array(ms, float)
    for k in med:
        write_dat(os.path.join(out, "rv_m_%s.dat" % k), ["x", "y"], [ms, med[k]])
        b = np.array(band[k]); write_dat(os.path.join(out, "rv_m_%s_band.dat" % k), ["x", "lo", "hi"], [ms, b[:, 0], b[:, 1]])
    ref = med["exact"][0] * np.sqrt(ms[0] / ms)
    write_dat(os.path.join(out, "rv_m_ref.dat"), ["x", "y"], [ms, ref])
    write_dat(os.path.join(out, "rv_m_sigma.dat"), ["x", "sigma"], [ms, sigmas])


def tau_sweep(name, N, taus, trials, seed, out, log, jobs_n=1):
    """Identification error and RMSE versus the number of consensus rounds."""
    tag = TAG[name]
    med_id, band_id, med_rmse = [], [], []
    exact = []
    for tau in taus:
        ids, rmses = [], []
        for res in run_jobs([("tausweep", seed, name, N, tr, dict(taus=(tau,), extra=False)) for tr in range(trials)], jobs_n):
            ids.extend(res["id"]["coop%d" % tau]); rmses.append(res["rmse"]["coop%d" % tau])
            if tau == taus[0]:
                exact.extend(res["id"]["exact"])
        q = quantiles(ids); med_id.append(q[0]); band_id.append(q[1:]); med_rmse.append(np.median(rmses))
        log("  %s tau-sweep tau=%2d  id %.4f  rmse %.4f" % (name, tau, med_id[-1], med_rmse[-1]))
    taus = np.array(taus, float)
    write_dat(os.path.join(out, "%s_tau_iderr.dat" % tag), ["tau", "y"], [taus, med_id])
    b = np.array(band_id); write_dat(os.path.join(out, "%s_tau_iderr_band.dat" % tag), ["tau", "lo", "hi"], [taus, b[:, 0], b[:, 1]])
    write_dat(os.path.join(out, "%s_tau_rmse.dat" % tag), ["tau", "y"], [taus, med_rmse])
    ex = np.median(exact)
    write_dat(os.path.join(out, "%s_tau_exact.dat" % tag), ["tau", "y"], [[taus[0], taus[-1]], [ex, ex]])


def k_sweep(name, N, ks, trials, seed, out, log, jobs_n=1):
    """Reconstruction/identification errors and RMSE versus the window length."""
    tag = TAG[name]
    recon, idl, idc, rl, rc, ro = [], [], [], [], [], []
    for k in ks:
        rec, il, ic, l, c, o = [], [], [], [], [], []
        for res in run_jobs([("ksweep", seed, name, N, tr, dict(taus=(3,), extra=True, k=k)) for tr in range(trials)], jobs_n):
            rec.append(res["recon"]); il.extend(res["id"]["local"]); ic.extend(res["id"]["coop3"])
            l.append(res["rmse"]["local"]); c.append(res["rmse"]["coop3"]); o.append(res["rmse"]["oracleA"])
        recon.append(np.sqrt(np.mean(np.square(rec)))); idl.append(np.median(il)); idc.append(np.median(ic))
        rl.append(np.median(l)); rc.append(np.median(c)); ro.append(np.median(o))
        log("  %s k-sweep k=%2d  recon %.3f  id local %.4f coop %.4f  rmse local %.4f coop %.4f oracle %.4f" % (name, k, recon[-1], idl[-1], idc[-1], rl[-1], rc[-1], ro[-1]))
    ks = np.array(ks, float)
    write_dat(os.path.join(out, "%s_k_recon.dat" % tag), ["k", "y"], [ks, recon])
    write_dat(os.path.join(out, "%s_k_idlocal.dat" % tag), ["k", "y"], [ks, idl])
    write_dat(os.path.join(out, "%s_k_idcoop.dat" % tag), ["k", "y"], [ks, idc])
    write_dat(os.path.join(out, "%s_k_rmse_local.dat" % tag), ["k", "y"], [ks, rl])
    write_dat(os.path.join(out, "%s_k_rmse_coop3.dat" % tag), ["k", "y"], [ks, rc])
    write_dat(os.path.join(out, "%s_k_rmse_oracleA.dat" % tag), ["k", "y"], [ks, ro])


def one_trial(cases, seed, out, log):
    """Time series of one trial (N=100) of each case study."""
    N = 100
    for name in cases:
        tag = TAG[name]
        cs = make_case(name, np.random.default_rng([seed, CASE_ID[name]]))
        res = run_trial(cs, N, np.random.default_rng([seed, CASE_ID[name], N, 0]), taus=(3,), extra=False, want_series=True)
        S = res["series"]
        t_all = np.arange(N + 200)
        # latent parameter of agent 0: true, window estimates, forecasts (first two components)
        for c in range(min(2, cs.p)):
            write_dat(os.path.join(out, "trial_%s_theta%d_true.dat" % (tag, c + 1)), ["t", "theta"], [t_all, S["Theta"][:, 0, c]])
            tw = np.arange(N - S["k"] + 1)
            write_dat(os.path.join(out, "trial_%s_theta%d_window.dat" % (tag, c + 1)), ["t", "theta"], [tw, S["th"][0, :, c]])
            tf = np.arange(N, N + 200)
            write_dat(os.path.join(out, "trial_%s_theta%d_coop.dat" % (tag, c + 1)), ["t", "theta"], [tf, S["fore_coop"][:, c]])
            write_dat(os.path.join(out, "trial_%s_theta%d_local.dat" % (tag, c + 1)), ["t", "theta"], [tf, S["fore_local"][:, c]])
        # network-average tracking error and disagreement
        err_data = [np.sqrt(np.mean(np.sum((X - S["xstar"][t]) ** 2, axis=1))) for t, X in enumerate(S["traj_data"])]
        err_coop = [np.sqrt(np.mean(np.sum((X - S["xstar"][N + j]) ** 2, axis=1))) for j, X in enumerate(S["traj_coop"])]
        err_local = [np.sqrt(np.mean(np.sum((X - S["xstar"][N + j]) ** 2, axis=1))) for j, X in enumerate(S["traj_local"])]
        dis = [np.sqrt(np.mean(np.sum((X - X.mean(axis=0)) ** 2, axis=1))) for X in S["traj_coop"]]
        write_dat(os.path.join(out, "trial_%s_err_coop.dat" % tag), ["t", "err"], [t_all, np.array(err_data + err_coop)])
        write_dat(os.path.join(out, "trial_%s_err_local.dat" % tag), ["t", "err"], [np.arange(N, N + 200), err_local])
        write_dat(os.path.join(out, "trial_%s_disagreement.dat" % tag), ["t", "err"], [np.arange(N, N + 200), dis])
        # first coordinate of the iterates (all agents) and of the optimum
        traj = S["traj_data"] + S["traj_coop"]
        for i in range(cs.m):
            write_dat(os.path.join(out, "trial_%s_x_agent%d.dat" % (tag, i)), ["t", "x"], [t_all, [X[i, 0] for X in traj]])
        write_dat(os.path.join(out, "trial_%s_x_opt.dat" % tag), ["t", "x"], [t_all, S["xstar"][:, 0]])
        write_dat(os.path.join(out, "trial_%s_x_local.dat" % tag), ["t", "x"], [np.arange(N, N + 200), [X[:, 0].mean() for X in S["traj_local"]]])
        log("  one-trial series written for %s" % name)


def write_table(rows_by_case, out):
    """table_results.tex with the columns used in the paper."""
    names = {"rendezvous": "(A)", "congestion": "Congest.", "recommendation": "(B)"}
    lines = [r"\begin{tabular}{@{}llrrrrrr@{\hspace{9pt}}rrrr@{}}", r"\toprule",
             r"& & \multicolumn{6}{c}{tracking RMSE} & \multicolumn{4}{c}{identification error $\|\hat A^{(i)}-A\|_F$}\\",
             r"\cmidrule(lr){3-8}\cmidrule(l){9-12}",
             r"case study & $N$ & persist. & local & coop. & central. & oracle $A$ & oracle KF & local & pooled LS & coop. & exact avg.\\",
             r"\midrule"]
    first = True
    for name, rows in rows_by_case.items():
        if not first:
            lines.append(r"\midrule")
        first = False
        for j, row in enumerate(rows):
            N = int(row[0]); r = dict(zip(RMSE_KEYS, row[1:1 + len(RMSE_KEYS)])); d = dict(zip(ID_KEYS, row[1 + len(RMSE_KEYS):]))
            lead = r"\multirow{%d}{*}{%s}" % (len(rows), names[name]) if j == 0 else ""
            fmt = (lambda v: "%.3f" % v) if name == "rendezvous" else (lambda v: "%.4f" % v)
            lines.append(" %s & %d & %s & %s & %s & %s & %s & %s & %.4f & %.4f & %.4f & %.4f\\\\" % (
                lead, N, fmt(r["persistence"]), fmt(r["local"]), fmt(r["coop3"]), fmt(r["centralized"]), fmt(r["oracleA"]), fmt(r["oracleKF"]),
                d["local"], d["pooledLS"], d["coop3"], d["exact"]))
    lines += [r"\bottomrule", r"\end{tabular}"]
    with open(os.path.join(out, "table_results.tex"), "w") as f:
        f.write("\n".join(lines) + "\n")


def main():
    global PROJECTION
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default="output", help="output directory for the .dat files and the table")
    ap.add_argument("--trials", type=int, default=50)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--quick", action="store_true", help="5 trials (smoke test)")
    ap.add_argument("--cases", default="rendezvous,recommendation", help="comma separated case studies (also: congestion)")
    ap.add_argument("--only", default="nsweep,msweep,tausweep,ksweep,trial", help="comma separated subset of experiments")
    ap.add_argument("--jobs", type=int, default=1, help="parallel worker processes")
    ap.add_argument("--projection", action="store_true", help="project the forecasts onto the boxes B_i (off by default)")
    args = ap.parse_args()
    PROJECTION = args.projection
    trials = 5 if args.quick else args.trials
    os.makedirs(args.out, exist_ok=True)
    only = set(args.only.split(","))
    cases = args.cases.split(",")
    logf = open(os.path.join(args.out, "log.txt"), "a")

    def log(msg):
        print(msg, flush=True)
        logf.write(msg + "\n"); logf.flush()

    log("=== experiments.py  trials=%d seed=%d projection=%s cases=%s  %s ===" % (
        trials, args.seed, PROJECTION, ",".join(cases), time.strftime("%Y-%m-%d %H:%M")))
    rows_by_case = {}
    if "nsweep" in only:
        for name in cases:
            rows, unstable = n_sweep(name, [30, 50, 100, 150, 200], trials, args.seed, args.out, log, args.jobs)
            rows_by_case[name] = rows
            log("  %s: fraction of local estimates not Schur stable per N: %s" % (name, ["%.0f%%" % (100 * u) for u in unstable["local"]]))
        write_table(rows_by_case, args.out)
    if "msweep" in only and "rendezvous" in cases:
        m_sweep([2, 4, 8, 16, 32], trials, args.seed, args.out, log, args.jobs)
    if "tausweep" in only:
        for name in cases:
            tau_sweep(name, 100, [0, 1, 2, 3, 5, 10], trials, args.seed, args.out, log, args.jobs)
    if "ksweep" in only:
        for name in cases:
            k_sweep(name, 150, [1, 2, 3, 5, 8, 12, 16], trials, args.seed, args.out, log, args.jobs)
    if "trial" in only:
        one_trial(cases, args.seed, args.out, log)
    log("done.")


if __name__ == "__main__":
    main()
