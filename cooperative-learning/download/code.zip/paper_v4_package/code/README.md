# Code accompanying the manuscript

* `experiments.py` (numpy only) implements Algorithm 1 — windowed Gauss–Markov
  reconstruction, cooperative IV identification by average consensus with the
  spectral-radius safeguard, gradient tracking on the forecast gradients — all
  baselines (local identification, exact averaging, pooled least squares,
  persistence, centralized predictor, oracle with known `A`, oracle Kalman
  filter) and the two case studies with the parameters of Table 1.  Forecasts
  are not projected.  Naming: the code calls case study (A), the overhead
  charging station for patrol UAVs, `rendezvous` (class `Rendezvous`, data
  files `rv_*`), and case study (B) `recommendation` (`rc_*`); the shared
  dynamics `A = 0.99 * rot(0.15)` is the matrix `[[0.979, -0.148], [0.148,
  0.979]]` printed in the paper.
* `make_tikz.py` writes the TikZ/pgfplots code of the plots (Figures 2, 3(b)
  and 4 of the paper, and `tikz/fig_appendix.tex`, a window ablation and one
  trial of case study (B) that is not part of the paper), with the data
  inline, and (with `--splice`) replaces the figures between the
  `BEGIN/END generated figure` markers in `../main.tex`.  The figure styles
  (colours, line styles, panel size, spacing) are defined in the preamble of
  `main.tex` (block "Figures").
* The supplementary material (the proofs only) is the separate document
  `../../supplementary_package/supplementary.tex`.  It cites the paper's
  equation and result numbers through `mainrefs.tex`, which
  `../../supplementary_package/sync_mainrefs.py` regenerates from
  `../main.aux`: rerun it after every build of `main.tex`.
* `make_rendezvous_diagram.py` draws the schematic of case study (A)
  (Figure 1) from one geometry definition and writes it twice:
  `rendezvous_setup.drawio` (open, edit and export it in draw.io /
  diagrams.net; the labels are LaTeX, typeset by draw.io's mathematical
  typesetting, which the file switches on) and `rendezvous_setup.tex` (the
  same drawing as a tikzpicture).  With `--splice` it replaces the drawing in `../main.tex`
  between the `BEGIN/END generated figure: rendezvous_setup` markers.  It
  uses the observation locations and service rates of the paper's instance;
  the deviations are illustrative.
* `make_recommendation_diagram.py` draws the schematic of case study (B)
  (Figure 3(a)), the eight regional servers on the backbone, with the
  primitives and exporters of `make_rendezvous_diagram.py`, and writes
  `recommendation_setup.drawio` and `recommendation_setup.tex` in the same
  way (`--splice` replaces it in `../main.tex`).
* `summarize.py` prints every number quoted in Section 5.1.
* `data/` holds the run reported in the paper (`data/run_log.txt` is its log).
* Section 5.2 of the paper (the Webots simulation) comes from
  `../../webots_demo` (see its README): `tools/collect_data.py` runs the
  simulation headless once per seed and logs every station's telemetry,
  iterates, estimates and packets; `tools/analyze_runs.py` checks the runs
  against `experiments.py` (same estimates to 6e-16, same iterates to 8e-15),
  replays the baselines on the recorded telemetry, prints the numbers quoted
  in Section 5.2 (`output/analysis/webots_summary.txt`), and writes a table
  and a sweep figure of all runs to `output/analysis/` (not part of the
  paper).  The images
  `figs/webots_scene.jpg` and `figs/webots_hud.jpg` are a still of the
  simulation and a frame of its video.

```
python3 experiments.py --out data --jobs 4               # 50 trials, ~35 min on 2 cores
python3 make_tikz.py data tikz --splice ../main.tex              # redraw the figures
python3 make_rendezvous_diagram.py ../figs --splice ../main.tex   # Figure 1 (.drawio + TikZ)
python3 make_recommendation_diagram.py ../figs --splice ../main.tex  # Figure 3(a)
python3 summarize.py data                                # numbers quoted in the text
python3 experiments.py --out test --quick                # 5-trial smoke test

# Webots simulation (Section 5.2), from ../../webots_demo:
for N in 30 50 100 150 200; do python3 tools/collect_data.py --N $N --track 200 --seeds 2026-2045; done
python3 tools/analyze_runs.py output/runs

# Supplementary material (the proofs), from ../../supplementary_package, after building main.tex:
python3 sync_mainrefs.py && pdflatex supplementary && bibtex supplementary && pdflatex supplementary && pdflatex supplementary
```

File names in `data/`: `rv_*`/`rc_*` = case study (A) / case study (B);
`*_rmse_<method>`, `*_id_<method>` versus `N` (`*_band` = interquartile
range), `rv_m_*` versus `m`, `*_tau_*` versus the consensus rounds, `*_k_*`
versus the window length, `trial_*` time series of one trial.
