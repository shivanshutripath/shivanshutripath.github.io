#!/usr/bin/env python3
"""
make_tikz.py -- writes the TikZ/pgfplots code of the plots of the
paper, with the data inline, from the output of experiments.py.

    python3 make_tikz.py [data dir] [output dir] [--splice ../main.tex]

Writes <output dir>/fig_rendezvous.tex, fig_rc_trial.tex,
fig_recommendation.tex and fig_appendix.tex (defaults: data, tikz).  Each file holds only a tikzpicture.
With --splice, the pictures (between the lines
"% ---- BEGIN generated figure: <name>" and "% ---- END generated figure:
<name>") are replaced in place in whichever of the given files holds their
markers -- fig_rendezvous, fig_rc_trial and fig_recommendation in main.tex;
fig_appendix (window ablation and one trial of case study (B)) is written to
the output directory only and is not part of the paper -- so that the paper
follows a new run of experiments.py.  The preamble of main.tex defines the
styles used here (panel, mcoop, mlocal, ..., see the block "Figures") and
the length \\panelwidth, set inside each figure from \\linewidth.

Layout (all figures): panels of width \\panelwidth = (\\linewidth - 4.3cm)/2
and fixed height; 2.3cm between the two columns of axes (room for the
y-axis label and tick labels of the right column plus a 0.8cm gap); 2.0cm
between the two rows (x-axis label of the top row, a 0.55cm gap, title of
the bottom row); the shared legend sits 0.2cm above the titles of the top
row, centered on the figure.  y-axis labels are placed at a fixed offset from the axis so that they
are aligned within each column.
"""
import os
import sys

import numpy as np

ARGS = [a for a in sys.argv[1:] if not a.startswith("--")]
SPLICE = []                      # files to update in place: --splice f1 [f2 ...]
if "--splice" in sys.argv:
    for a in sys.argv[sys.argv.index("--splice") + 1:]:
        if a.startswith("--"):
            break
        SPLICE.append(a)
        ARGS.remove(a)
DATA = ARGS[0] if len(ARGS) > 0 else "data"
OUT = ARGS[1] if len(ARGS) > 1 else "tikz"


# ----------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------
def load(name):
    return np.loadtxt(os.path.join(DATA, name), skiprows=1, ndmin=2)


def num(v):
    s = "%.4g" % v
    if "e" in s:
        mant, exp = s.split("e")
        s = "%se%d" % (mant, int(exp))
    return s


def coords(x, y, per_line=6, indent="      "):
    pts = ["(%s,%s)" % (num(a), num(b)) for a, b in zip(x, y)]
    rows = [" ".join(pts[i:i + per_line]) for i in range(0, len(pts), per_line)]
    return ("\n" + indent).join(rows)


def line(style, fname, every=1, per_line=6):
    a = load(fname)
    if every > 1:  # keep the last point
        idx = sorted(set(list(range(0, len(a), every)) + [len(a) - 1]))
        a = a[idx]
    return "\\addplot[%s] coordinates {%s};" % (style, coords(a[:, 0], a[:, 1], per_line))


def band(color, fname, tag):
    """Interquartile band from a file with columns x, lo, hi."""
    a = load(fname)
    return ("\\addplot[name path=%sU, draw=none, forget plot] coordinates {%s};\n"
            "\\addplot[name path=%sL, draw=none, forget plot] coordinates {%s};\n"
            "\\addplot[band, fill=%s] fill between[of=%sU and %sL];") % (
        tag, coords(a[:, 0], a[:, 2]), tag, coords(a[:, 0], a[:, 1]), color, tag, tag)


def axis(opts):
    return "\\nextgroupplot[\n  " + ",\n  ".join(opts) + ",\n]"


def ticks(axis_name, values, labels=None):
    labels = labels or [str(v) for v in values]
    return "%stick={%s}, %sticklabels={%s}" % (axis_name, ",".join(map(str, values)), axis_name, ",".join(labels))


N_TICKS = ticks("x", [30, 50, 100, 150, 200])
N_RANGE = "xmode=log, xmin=26, xmax=230"

LEGEND_COMMON = [
    ("mcoop", "cooperative"),
    ("mlocal", "local identification"),
    ("mpers", "persistence"),
    ("mcent", "centralized predictor"),
    ("moracle", "oracle ($A$ known)"),
    ("mpooled", "pooled least squares"),
    ("mexact", "exact averaging"),
]


def legend_images(entries):
    return "\n".join("\\addlegendimage{%s}\\addlegendentry{%s}" % e for e in entries)


def legend_node(name):
    """Shared legend, centered above the whole picture (titles included)."""
    return ("\\node[anchor=south, yshift=0.2cm] at (current bounding box.north) "
            "{\\pgfplotslegendfromname{%s}};" % name)


def picture(group_opts, body, style="panel"):
    return ("\\begin{tikzpicture}\n"
            "\\begin{groupplot}[%s, group style={%s}]\n" % (style, group_opts)
            + body + "\n\\end{groupplot}\n")


# ----------------------------------------------------------------------------
# Figure 2: rendezvous (1 x 3, cooperative and local identification only,
# dots (cooperative) and stars (local), styles scoop/slocal;
# \panelwidth = (\linewidth - 5.4cm)/3, style panel3 of main.tex)
# ----------------------------------------------------------------------------
RV_N_TICKS = ticks("x", [30, 50, 100, 200])


def fig_rendezvous():
    p = []
    p.append("% ---- left: tracking RMSE versus N ----")
    p.append(axis(["xlabel={training horizon $N$\\\\(a)}", "ylabel={tracking RMSE}",
                   N_RANGE, RV_N_TICKS, "ymin=0.15, ymax=0.72", ticks("y", [0.2, 0.4, 0.6]),
                   "legend to name=legRV, figlegend, legend style={/tikz/every even column/.append style={column sep=1cm}}"]))
    p.append(legend_images([("scoop", "cooperative identification"), ("slocal", "local identification")]))
    p.append(band("cRedNew", "rv_rmse_local_band.dat", "rvaL"))
    p.append(band("cBlueNew", "rv_rmse_coop3_band.dat", "rvaC"))
    p.append(line("slocal", "rv_rmse_local.dat"))
    p.append(line("scoop", "rv_rmse_coop3.dat"))

    p.append("% ---- middle: identification error versus N ----")
    p.append(axis(["xlabel={training horizon $N$\\\\(b)}", "ylabel={$\\|\\hat A^{(i)}-A\\|_F$}",
                   N_RANGE, RV_N_TICKS, "ymode=log, ymin=0.003, ymax=0.05", ticks("y", [0.005, 0.01, 0.02])]))
    p.append(band("cRedNew", "rv_id_local_band.dat", "rvbL"))
    p.append(band("cBlueNew", "rv_id_coop3_band.dat", "rvbC"))
    p.append(line("slocal", "rv_id_local.dat"))
    p.append(line("scoop", "rv_id_coop3.dat"))

    p.append("% ---- right: identification error versus m (identical agents) ----")
    p.append(axis(["xlabel={number of agents $m$\\\\(c)}", "ylabel={$\\|\\hat A^{(i)}-A\\|_F$}",
                   "xmode=log, log basis x=2, xmin=1.75, xmax=36", ticks("x", [2, 4, 8, 16, 32]),
                   "ymode=log, ymin=0.003, ymax=0.05", ticks("y", [0.005, 0.01, 0.02])]))
    p.append(band("cRedNew", "rv_m_local_band.dat", "rvcL"))
    p.append(band("cBlueNew", "rv_m_coop3_band.dat", "rvcC"))
    p.append(line("slocal", "rv_m_local.dat"))
    p.append(line("scoop", "rv_m_coop3.dat"))

    body = "\n".join(p)
    return (picture("group size=3 by 1, horizontal sep=1.95cm", body, "panel3")
            + legend_node("legRV").replace("yshift=0.2cm", "yshift=0.3cm") + "\n\\end{tikzpicture}\n")


# ----------------------------------------------------------------------------
# Figure 3(b): recommendation, one trial with N = 100 (2 x 1, shared time
# axis): drift of the interest of region 1 in genre 1, and boosts of genre 1.
# Sits next to the schematic of make_recommendation_diagram.py; \panelwidth
# is set in its minipage.
# ----------------------------------------------------------------------------
def fig_rc_trial():
    N = 100
    shade = ("\\fill[black, fill opacity=0.06] (axis cs:0,\\pgfkeysvalueof{/pgfplots/ymin}) rectangle "
             "(axis cs:%d,\\pgfkeysvalueof{/pgfplots/ymax});" % N)
    tN = "\\draw[gray, densely dashed, line width=0.5pt] (axis cs:%d,\\pgfkeysvalueof{/pgfplots/ymin}) -- (axis cs:%d,\\pgfkeysvalueof{/pgfplots/ymax});" % (N, N)
    leg = ("legend columns=-1, legend style={%s, font=\\scriptsize, draw=none, fill=white, fill opacity=0.85, "
           "text opacity=1, inner sep=1pt, /tikz/every even column/.append style={column sep=0.25cm}}")
    common = ["xmin=0, xmax=300", ticks("x", [0, 100, 200, 300]), "height=1.9cm", "grid=none", "tick pos=left",
              "every axis y label/.style={at={(axis description cs:0,0.5)}, xshift=-0.85cm, rotate=90, anchor=south}"]
    p = []
    p.append("% ---- top: drift of the interest of region 1 in genre 1 ----")
    p.append(axis(common + ["xticklabels={}", "ylabel={drift $\\theta_{1,1}$}",
                            "ymin=-3.3, ymax=3.4", ticks("y", [-2, 0, 2]),
                            leg % "at={(0.5,1.03)}, anchor=south"]))
    p.append(shade)
    p.append(line("black, line width=0.6pt", "trial_rc_theta1_true.dat", per_line=10))
    p.append("\\addlegendentry{true}")
    p.append(line("only marks, mark=*, mark size=0.7pt, cRecon", "trial_rc_theta1_window.dat", per_line=10))
    p.append("\\addlegendentry{reconstructed}")
    p.append(line("cCoop, line width=1pt", "trial_rc_theta1_coop.dat", per_line=10))
    p.append("\\addlegendentry{forecast}")
    p.append(tN)
    p.append("\\node[dlabel, anchor=north, font=\\scriptsize] at (axis cs:50,\\pgfkeysvalueof{/pgfplots/ymax}) {data collection};")
    p.append("\\node[dlabel, anchor=north, font=\\scriptsize] at (axis cs:200,\\pgfkeysvalueof{/pgfplots/ymax}) {no data: forecast};")

    p.append("% ---- bottom: boost of genre 1 at every server, and its optimal value ----")
    p.append(axis(common + ["xlabel={time $t$}", "ylabel={boost $x_{i,1}$}",
                            "ymin=0.72, ymax=1.22", ticks("y", ["0.8", "1", "1.2"], ["0.8", "1.0", "1.2"]),
                            leg % "at={(0.99,0.04)}, anchor=south east"]))
    p.append(shade)
    for i in range(8):
        p.append(line("cCoop, line width=0.45pt, draw opacity=0.7%s" % ("" if i == 0 else ", forget plot"),
                      "trial_rc_x_agent%d.dat" % i, every=2, per_line=10))
        if i == 0:
            p.append("\\addlegendentry{servers}")
    p.append(line("black, densely dashed, line width=0.8pt", "trial_rc_x_opt.dat", every=2, per_line=10))
    p.append("\\addlegendentry{minimizer $x^\\star_1$}")
    p.append(tN)

    body = "\n".join(p)
    return picture("group size=1 by 2, vertical sep=0.18cm", body) + "\\end{tikzpicture}\n"


# ----------------------------------------------------------------------------
# Figure 4: recommendation (1 x 3, as Figure 2: cooperative and local
# identification, styles scoop/slocal; pooled least squares and exact
# averaging are labeled in place; \panelwidth = (\linewidth - 5.4cm)/3)
# ----------------------------------------------------------------------------
def fig_recommendation():
    p = []
    p.append("% ---- left: tracking RMSE versus N ----")
    p.append(axis(["xlabel={training horizon $N$\\\\(a)}", "ylabel={tracking RMSE}",
                   N_RANGE, RV_N_TICKS, "ymin=0.009, ymax=0.037", "scaled y ticks=false",
                   ticks("y", ["0.01", "0.02", "0.03"]),
                   "legend to name=legRC, figlegend, legend style={/tikz/every even column/.append style={column sep=1cm}}"]))
    p.append(legend_images([("scoop", "cooperative identification"), ("slocal", "local identification")]))
    p.append(band("cRedNew", "rc_rmse_local_band.dat", "rcaL"))
    p.append(band("cBlueNew", "rc_rmse_coop3_band.dat", "rcaC"))
    p.append(line("slocal", "rc_rmse_local.dat"))
    p.append(line("scoop", "rc_rmse_coop3.dat"))

    p.append("% ---- middle: identification error versus N ----")
    p.append(axis(["xlabel={training horizon $N$\\\\(b)}", "ylabel={$\\|\\hat A^{(i)}-A\\|_F$}",
                   N_RANGE, RV_N_TICKS, "ymode=log, ymin=0.0105, ymax=0.6", ticks("y", [0.02, 0.05, 0.1, 0.2, 0.5])]))
    p.append(band("cRedNew", "rc_id_local_band.dat", "rcbL"))
    p.append(band("cBlueNew", "rc_id_coop3_band.dat", "rcbC"))
    p.append(line("cPooled, densely dashed, line width=1pt, mark=x, mark size=2.3pt, mark options={solid}", "rc_id_pooledLS.dat"))
    p.append(line("slocal", "rc_id_local.dat"))
    p.append(line("scoop", "rc_id_coop3.dat"))
    p.append("\\node[dlabel, text=cPooled!80!black, anchor=north, rotate=20] at (axis cs:120,0.057) {pooled LS};")

    p.append("% ---- right: identification error versus the consensus rounds ----")
    p.append(axis(["xlabel={consensus rounds $\\tau$, $N=100$\\\\(c)}", "ylabel={$\\|\\hat A^{(i)}-A\\|_F$}",
                   "xmin=-0.5, xmax=10.5", ticks("x", [0, 1, 2, 3, 5, 10]),
                   "ymode=log, ymin=0.0105, ymax=0.6", ticks("y", [0.02, 0.05, 0.1, 0.2, 0.5])]))
    p.append(band("cBlueNew", "rc_tau_iderr_band.dat", "rccC"))
    p.append(line("cExact, dashed, line width=1pt", "rc_tau_exact.dat"))
    p.append(line("scoop", "rc_tau_iderr.dat"))
    p.append("\\node[dlabel, text=cExact!75!black, anchor=north] at (axis cs:6.5,0.0162) {exact averaging};")

    body = "\n".join(p)
    return (picture("group size=3 by 1, horizontal sep=1.95cm", body, "panel3")
            + legend_node("legRC").replace("yshift=0.2cm", "yshift=0.3cm") + "\n\\end{tikzpicture}\n")


# ----------------------------------------------------------------------------
# fig_appendix (not in the paper): recommendation window ablation and one trial (1 x 2)
# ----------------------------------------------------------------------------
def fig_appendix():
    p = []
    p.append("% ---- (a) errors versus the window length ----")
    p.append(axis(["title={(a) Window length, $N=150$}", "xlabel={window length $k$}", "ylabel={error}",
                   "xmode=log, xmin=0.88, xmax=18.5", ticks("x", [1, 2, 3, 5, 8, 16]),
                   "ymode=log, ymin=0.012, ymax=2.5", ticks("y", [0.03, 0.1, 0.3, 1])]))
    p.append(line("mrecon", "rc_k_recon.dat"))
    p.append(line("mlocal", "rc_k_idlocal.dat"))
    p.append(line("mcoop", "rc_k_idcoop.dat"))
    p.append("\\node[dlabel, text=cRecon!85!black, anchor=south] at (axis cs:2.6,0.57) {reconstruction error};")
    p.append("\\node[dlabel, text=cLocal, anchor=south] at (axis cs:5,0.172) {identification, local};")
    p.append("\\node[dlabel, text=cCoop, anchor=south] at (axis cs:5.6,0.0335) {identification, cooperative};")

    p.append("% ---- (b) one trial: tracking error and disagreement ----")
    p.append(axis(["title={(b) One trial, $N=100$}", "xlabel={time $t$}", "ylabel={error}",
                   "xmin=0, xmax=300", ticks("x", [0, 100, 200, 300]),
                   "ymode=log, ymin=5e-5, ymax=150", ticks("y", ["1e-4", "1e-2", "1"], ["$10^{-4}$", "$10^{-2}$", "$1$"]),
                   "legend style={at={(0.98,0.97)}, anchor=north east, font=\\footnotesize, draw=none, fill=white, fill opacity=0.85, text opacity=1, row sep=-1pt}"]))
    p.append(line("cCoop, line width=0.8pt", "trial_rc_err_coop.dat", every=2))
    p.append("\\addlegendentry{tracking error, cooperative}")
    p.append(line("cLocal, line width=0.8pt", "trial_rc_err_local.dat", every=2))
    p.append("\\addlegendentry{tracking error, local}")
    p.append(line("cPooled, dashed, line width=1pt", "trial_rc_disagreement.dat", every=5))
    p.append("\\addlegendentry{disagreement}")
    p.append("\\addplot[gray, densely dashed, line width=0.5pt, forget plot] coordinates {(100,5e-5) (100,150)};")
    p.append("\\node[dlabel, text=gray, anchor=south east] at (axis cs:96,8e-5) {$t=N$};")

    body = "\n".join(p)
    return picture("group size=2 by 1, horizontal sep=2.3cm", body.replace("panel,", "panel,")) + "\\end{tikzpicture}\n"


def splice(paths, pictures):
    """Replace the generated pictures between their markers, in whichever of
    the given files holds them; a picture whose markers are in none of the
    files (fig_appendix) stays in the output directory only."""
    import re
    texts = {p: open(p).read() for p in paths}
    for name, code in pictures.items():
        pat = re.compile(r"(% ---- BEGIN generated figure: " + name + r"[^\n]*\n).*?(\s*% ---- END generated figure: " + name + r")", re.S)
        hits = [p for p in paths if pat.search(texts[p])]
        if not hits:
            print("note: markers for %s in none of %s (not spliced)" % (name, paths))
            continue
        if len(hits) > 1:
            raise SystemExit("markers for %s found in several files: %s" % (name, hits))
        texts[hits[0]] = pat.sub(lambda mo: mo.group(1) + code.rstrip("\n") + mo.group(2), texts[hits[0]])
    for p in paths:
        open(p, "w").write(texts[p])
        print("updated", p)


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    pictures = {}
    for name, fn in (("fig_rendezvous", fig_rendezvous), ("fig_rc_trial", fig_rc_trial),
                     ("fig_recommendation", fig_recommendation), ("fig_appendix", fig_appendix)):
        pictures[name] = fn()
        with open(os.path.join(OUT, name + ".tex"), "w") as f:
            f.write("%% %s -- generated by code/make_tikz.py; requires the figure styles\n"
                    "%% of the preamble of main.tex and \\panelwidth.\n" % name)
            f.write(pictures[name])
        print("wrote", os.path.join(OUT, name + ".tex"))
    if SPLICE:
        splice(SPLICE, pictures)
