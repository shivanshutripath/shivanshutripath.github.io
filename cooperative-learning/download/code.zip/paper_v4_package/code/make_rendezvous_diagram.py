#!/usr/bin/env python3
"""
make_rendezvous_diagram.py -- schematic of case study (A), the charging
cart for patrol UAVs (called "rendezvous" in the code).

    python3 make_rendezvous_diagram.py <output dir>

Writes, from one geometry definition,
  rendezvous_setup.drawio  -- draw.io / diagrams.net file (open, edit, export);
                              labels use draw.io's LaTeX math mode (math=1);
  rendezvous_setup.tex     -- the same drawing as a tikzpicture for main.tex.

The six ground control stations of the paper's instance, each at the bearing
of its UAV's observation location.  Station i receives the telemetry of UAV i
only (dashed arrows, during data collection t < N) and talks to its three
neighbors in the radio network (solid lines: the ring 1-2-3-4-5-6-1 and the
chords (1,4), (2,5), (3,6) of Table 1).
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from experiments import Rendezvous  # noqa: E402

_args = sys.argv[1:]
SPLICE = None
if "--splice" in _args:                       # --splice ../main.tex
    k = _args.index("--splice")
    SPLICE = _args[k + 1]
    del _args[k:k + 2]
OUT = _args[0] if _args else "."
BEGIN = "% ---- BEGIN generated figure: rendezvous_setup"
END = "% ---- END generated figure: rendezvous_setup ----"

# ----------------------------------------------------------------------------
# colours (Okabe--Ito, as in the plots)
# ----------------------------------------------------------------------------
COL = {
    "uav": "#0072B2", "uavfill": "#D6E9F8", "uavbody": "#2B2B2B",
    "slot": "#8C8C8C", "dev": "#D55E00", "star": "#009E73", "stardark": "#006B4E",
    "dist": "#A6A6A6", "robot": "#E69F00", "robotdark": "#9C6B00", "wheel": "#2B2B2B",
    "comm": "#404040", "sense": "#0072B2", "text": "#000000", "frame": "#BFBFBF",
}

# ----------------------------------------------------------------------------
# primitives (coordinates in cm, y upwards)
# ----------------------------------------------------------------------------
SHAPES = []


def circle(c, r, stroke, fill="none", width=0.6, dash=None, group=None):
    SHAPES.append(dict(kind="circle", c=c, r=r, stroke=stroke, fill=fill, width=width, dash=dash, group=group))


def rect(c, w, h, stroke, fill="none", width=0.6, rounded=0.0, group=None):
    SHAPES.append(dict(kind="rect", c=c, w=w, h=h, stroke=stroke, fill=fill, width=width, rounded=rounded, group=group))


def line(pts, stroke, width=0.6, dash=None, arrow=False, smooth=False, opacity=1.0, group=None):
    SHAPES.append(dict(kind="line", pts=[tuple(p) for p in pts], stroke=stroke, width=width, dash=dash,
                       arrow=arrow, smooth=smooth, opacity=opacity, group=group))


def text(p, tex, plain=None, anchor="center", size="footnotesize", color="#000000", bold=False, bg=False):
    """tex: LaTeX label (TikZ, and draw.io math); plain: draw.io text if no math;
    bg: white background that masks the thin lines under the label."""
    SHAPES.append(dict(kind="text", p=p, tex=tex, plain=plain, anchor=anchor, size=size, color=color, bold=bold, bg=bg))


def star(c, r, fill, stroke):
    SHAPES.append(dict(kind="star", c=c, r=r, fill=fill, stroke=stroke))


GROUPS = {}


def uav(c, s, label=None):
    """Quadcopter, top view, size s (cm)."""
    g = "uav%d" % len(GROUPS)
    GROUPS[g] = (c, s)
    a = 0.33 * s
    for dx, dy in ((1, 1), (-1, -1)):
        line([(c[0] - a * dx, c[1] - a * dy), (c[0] + a * dx, c[1] + a * dy)], COL["uavbody"], 0.7, group=g)
    line([(c[0] - a, c[1] + a), (c[0] + a, c[1] - a)], COL["uavbody"], 0.7, group=g)
    for dx, dy in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
        circle((c[0] + a * dx, c[1] + a * dy), 0.17 * s, COL["uav"], COL["uavfill"], 0.5, group=g)
    rect(c, 0.3 * s, 0.3 * s, COL["uavbody"], COL["uavbody"], 0.4, rounded=0.25, group=g)


def station(c, s, label):
    """Ground control station (box with a radio mast), width s (cm), with its index."""
    g = "sta%d" % len(GROUPS)
    GROUPS[g] = (c, s)
    mx = c[0] + 0.3 * s                                  # mast, to the right of the index
    line([(mx, c[1] + 0.25 * s), (mx, c[1] + 0.58 * s)], COL["wheel"], 0.6, group=g)
    circle((mx, c[1] + 0.6 * s), 0.07 * s, COL["wheel"], COL["wheel"], 0.4, group=g)
    rect((c[0], c[1] - 0.02 * s), 0.86 * s, 0.56 * s, COL["robotdark"], COL["robot"], 0.6, rounded=0.25, group=g)
    text((c[0] - 0.08 * s, c[1] - 0.02 * s), "$%s$" % label, plain=str(label),
         size="scriptsize" if s < 0.45 else "footnotesize", color="#000000")


def polar(c, r, ang):
    return (c[0] + r * np.cos(ang), c[1] + r * np.sin(ang))


# ----------------------------------------------------------------------------
# data: the paper's instance (observation locations, service rates);
# illustrative deviations
# ----------------------------------------------------------------------------
cs = Rendezvous(np.random.default_rng([2026, 1]))
# deviation theta_i(t) of each UAV: magnitude and direction (degrees).  The
# deviations of a simulated trial are as large as the gaps between locations,
# so the schematic uses smaller ones with private phases; each UAV circles its
# location counter-clockwise (A = 0.99 Rot(0.15)), and its recent path is an
# arc of 100 degrees whose radius shrinks slightly (damping).
DEV = [(2.6, 80), (1.8, 160), (2.0, 200), (1.7, 285), (2.0, 100), (1.9, 112)]
NUM_ANGLE = [160, 30, 150, 220, 200, 330]               # where the index of each UAV is written
theta = np.array([[r * np.cos(np.radians(a)), r * np.sin(np.radians(a))] for r, a in DEV])
pos = cs.bbar + theta                                    # b_i(t)
xstar = (cs.h[:, None] * pos).sum(0) / cs.h.sum()        # best charging-station position


def path(i, n=9, sweep=100.0, grow=0.15):
    r, a = DEV[i]
    out = []
    for k in range(n + 1):
        f = k / n                                        # 0: oldest, 1: now
        aa = np.radians(a - sweep * (1 - f))
        rr = r * (1 + grow * (1 - f))
        out.append(cs.bbar[i] + rr * np.array([np.cos(aa), np.sin(aa)]))
    return out


# ----------------------------------------------------------------------------
# layout: the ground stations, their UAVs, telemetry and radio links
# ----------------------------------------------------------------------------
W, H = 6.2, 5.45                       # figure size (cm)
CB = (3.1, 3.2)                        # center of the station ring
RR, RU = 1.15, 2.05                    # radii of the stations and of the UAVs


def shorten(p, q, a, b):
    """Segment p->q shortened by a at p and b at q."""
    p, q = np.array(p, float), np.array(q, float)
    d = (q - p) / np.linalg.norm(q - p)
    return tuple(p + a * d), tuple(q - b * d)


ang = np.arctan2(cs.bbar[:, 1], cs.bbar[:, 0])          # station i at the bearing of its UAV's area
rpos = [polar(CB, RR, a) for a in ang]
upos = [polar(CB, RU, a) for a in ang]
edges = [(i, (i + 1) % 6) for i in range(6)]            # ring: each station talks to its two neighbors
edges += [(i, i + 3) for i in range(3)]                 # + the three chords (1,4), (2,5), (3,6) of Table 1
for (i, j) in edges:
    line([rpos[i], rpos[j]], COL["comm"], 0.9)
for i in range(6):
    p0, p1_ = shorten(upos[i], rpos[i], 0.28, 0.36)
    line([p0, p1_], COL["sense"], 0.8, dash="dashed", arrow=True)
    uav(upos[i], 0.46)
    text(polar(CB, RU + 0.47, ang[i]), "$%d$" % (i + 1), plain=str(i + 1), size="footnotesize")
for i in range(6):
    station(rpos[i], 0.56, i + 1)
# legend, one line
LY = 0.3
station((0.22, LY), 0.44, "i")
text((0.54, LY), "station $i$", plain="station i", anchor="west")
uav((2.42, LY), 0.38)
text((2.69, LY), "UAV $i$", plain="UAV i", anchor="west")
line([(4.12, LY), (4.57, LY)], COL["comm"], 0.9)
text((4.67, LY), "radio link", plain="radio link", anchor="west")


# ----------------------------------------------------------------------------
# exporters
# ----------------------------------------------------------------------------
def tikz_color(hexs):
    return "{rgb,255:red,%d;green,%d;blue,%d}" % tuple(int(hexs[k:k + 2], 16) for k in (1, 3, 5))


def fmt(v):
    return ("%.3f" % v).rstrip("0").rstrip(".")


def pt(p):
    return "(%s,%s)" % (fmt(p[0]), fmt(p[1]))


def export_tikz():
    out = ["\\begin{tikzpicture}[x=1cm, y=1cm, line cap=round, line join=round]"]
    out.append("\\useasboundingbox (0,0) rectangle (%s,%s);" % (fmt(W), fmt(H)))
    for s in SHAPES:
        k = s["kind"]
        if k == "circle":
            opts = ["draw=%s" % tikz_color(s["stroke"]), "line width=%spt" % fmt(s["width"])]
            if s["fill"] != "none":
                opts.append("fill=%s" % tikz_color(s["fill"]))
            if s["dash"]:
                opts.append(s["dash"])
            out.append("\\path[%s] %s circle[radius=%s];" % (", ".join(opts), pt(s["c"]), fmt(s["r"])))
        elif k == "rect":
            c, w, h = s["c"], s["w"], s["h"]
            opts = ["draw=%s" % tikz_color(s["stroke"]), "line width=%spt" % fmt(s["width"])]
            if s["fill"] != "none":
                opts.append("fill=%s" % tikz_color(s["fill"]))
            if s["rounded"]:
                opts.append("rounded corners=%scm" % fmt(s["rounded"] * min(w, h)))
            out.append("\\path[%s] %s rectangle %s;" % (", ".join(opts), pt((c[0] - w / 2, c[1] - h / 2)), pt((c[0] + w / 2, c[1] + h / 2))))
        elif k == "line":
            opts = ["draw=%s" % tikz_color(s["stroke"]), "line width=%spt" % fmt(s["width"])]
            if s["dash"]:
                opts.append(s["dash"])
            if s["arrow"]:
                opts.append("-{Stealth[length=4.5pt, width=3.6pt]}")
            if s["opacity"] < 1:
                opts.append("draw opacity=%s" % fmt(s["opacity"]))
            pts = s["pts"]
            if s["smooth"] and len(pts) > 2:
                out.append("\\draw[%s] plot[smooth, tension=0.6] coordinates {%s};" % (", ".join(opts), " ".join(pt(p) for p in pts)))
            else:
                out.append("\\draw[%s] %s;" % (", ".join(opts), " -- ".join(pt(p) for p in pts)))
        elif k == "star":
            out.append("\\node[star, star points=5, star point ratio=2.3, minimum size=%scm, inner sep=0pt, "
                       "fill=%s, draw=%s, line width=0.5pt] at %s {};" % (fmt(2 * s["r"]), tikz_color(s["fill"]), tikz_color(s["stroke"]), pt(s["c"])))
        elif k == "text":
            size = {"footnotesize": "\\footnotesize", "small": "\\small", "scriptsize": "\\scriptsize"}[s["size"]]
            opts = ["anchor=%s" % s["anchor"], "inner sep=1pt", "font=%s" % size]
            if s.get("bg"):
                opts.append("fill=white")
            if s["color"] != "#000000":
                opts.append("text=%s" % tikz_color(s["color"]))
            out.append("\\node[%s] at %s {%s};" % (", ".join(opts), pt(s["p"]), s["tex"]))
    out.append("\\end{tikzpicture}")
    return "\n".join(out) + "\n"


PX = 37.7953  # draw.io pixels per cm


def X(x):
    return x * PX


def Y(y):
    return (H - y) * PX


def esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;"))


def html_escape(s):
    """draw.io labels with html=1 are HTML: escape once for HTML (then once for XML)."""
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def drawio_label(s):
    """LaTeX label -> draw.io label (math mode delimiters \\( \\))."""
    tex = s["tex"]
    if s.get("plain") is not None and "$" not in tex:
        return s["plain"]
    out, inmath, buf = [], False, ""
    for ch in tex:
        if ch == "$":
            out.append(("\\(" + buf + "\\)") if inmath else buf)
            buf, inmath = "", not inmath
        else:
            buf += ch
    out.append(buf)
    return "".join(out)


def export_drawio():
    cells = []
    nid = [2]

    def new_id():
        nid[0] += 1
        return "c%d" % nid[0]

    # groups (icons) get a parent cell; children are positioned relative to it.
    # draw.io stacks cells in document order, so each group cell is written
    # just before its first child: icons stay above the lines drawn earlier
    # (e.g. stations above the radio links), as in the TikZ version.
    group_cells = {}

    def parent_of(s):
        g = s.get("group")
        if not g:
            return "1", 0.0, 0.0
        if g not in group_cells:
            c, sz = GROUPS[g]
            gid = new_id()
            half = 0.7 * sz
            gx, gy = X(c[0] - half), Y(c[1] + half)
            group_cells[g] = (gid, gx, gy)
            cells.append('<mxCell id="%s" value="" style="group" vertex="1" connectable="0" parent="1">'
                         '<mxGeometry x="%.2f" y="%.2f" width="%.2f" height="%.2f" as="geometry"/></mxCell>'
                         % (gid, gx, gy, 2 * half * PX, 2 * half * PX))
        return group_cells[g]

    dash_map = {"dashed": "dashed=1;dashPattern=4 3;", "densely dashed": "dashed=1;dashPattern=3 2;",
                "dotted": "dashed=1;dashPattern=1 2;"}
    for s in SHAPES:
        k = s["kind"]
        if k in ("circle", "rect"):
            par, ox, oy = parent_of(s)
            if k == "circle":
                c, r = s["c"], s["r"]
                x, y, w, h = X(c[0] - r) - ox, Y(c[1] + r) - oy, 2 * r * PX, 2 * r * PX
                style = "ellipse;html=1;aspect=fixed;"
            else:
                c, w0, h0 = s["c"], s["w"], s["h"]
                x, y, w, h = X(c[0] - w0 / 2) - ox, Y(c[1] + h0 / 2) - oy, w0 * PX, h0 * PX
                style = "rounded=1;arcSize=%d;html=1;" % int(100 * s["rounded"]) if s["rounded"] else "rounded=0;html=1;"
            style += "fillColor=%s;strokeColor=%s;strokeWidth=%.2f;" % (s["fill"] if s["fill"] != "none" else "none", s["stroke"], s["width"] * 1.3333)
            if s.get("dash"):
                style += dash_map[s["dash"]]
            cells.append('<mxCell id="%s" value="" style="%s" vertex="1" parent="%s">'
                         '<mxGeometry x="%.2f" y="%.2f" width="%.2f" height="%.2f" as="geometry"/></mxCell>'
                         % (new_id(), style, par, x, y, w, h))
        elif k == "line":
            par, ox, oy = parent_of(s)
            pts = [(X(p[0]) - ox, Y(p[1]) - oy) for p in s["pts"]]
            style = "html=1;rounded=0;strokeColor=%s;strokeWidth=%.2f;" % (s["stroke"], s["width"] * 1.3333)
            style += "endArrow=classic;endFill=1;endSize=5;startArrow=none;" if s["arrow"] else "endArrow=none;startArrow=none;"
            if s["dash"]:
                style += dash_map[s["dash"]]
            if s["smooth"]:
                style += "curved=1;"
            if s["opacity"] < 1:
                style += "opacity=%d;" % int(100 * s["opacity"])
            way = "".join('<mxPoint x="%.2f" y="%.2f"/>' % p for p in pts[1:-1])
            cells.append('<mxCell id="%s" style="%s" edge="1" parent="%s"><mxGeometry relative="1" as="geometry">'
                         '<mxPoint x="%.2f" y="%.2f" as="sourcePoint"/><mxPoint x="%.2f" y="%.2f" as="targetPoint"/>'
                         '%s</mxGeometry></mxCell>'
                         % (new_id(), style, par, pts[0][0], pts[0][1], pts[-1][0], pts[-1][1],
                            ('<Array as="points">%s</Array>' % way) if way else ""))
        elif k == "star":
            c, r = s["c"], s["r"]
            style = "shape=mxgraph.basic.star;html=1;fillColor=%s;strokeColor=%s;strokeWidth=0.7;" % (s["fill"], s["stroke"])
            cells.append('<mxCell id="%s" value="" style="%s" vertex="1" parent="1">'
                         '<mxGeometry x="%.2f" y="%.2f" width="%.2f" height="%.2f" as="geometry"/></mxCell>'
                         % (new_id(), style, X(c[0] - r), Y(c[1] + r), 2 * r * PX, 2 * r * PX))
        elif k == "text":
            lab = drawio_label(s)
            fs = {"footnotesize": 11, "small": 12, "scriptsize": 9}[s["size"]]
            n = len(s["plain"] if s.get("plain") else s["tex"].replace("\\underbrace", "").replace("\\text", ""))
            w, h = max(14, 6.3 * n), (34 if "underbrace" in s["tex"] else 16)
            a = s["anchor"]
            align = "left" if "west" in a else ("right" if "east" in a else "center")
            valign = "top" if "north" in a else ("bottom" if "south" in a else "middle")
            px, py = X(s["p"][0]), Y(s["p"][1])
            x = px if align == "left" else (px - w if align == "right" else px - w / 2)
            y = py if valign == "top" else (py - h if valign == "bottom" else py - h / 2)
            style = ("text;html=1;whiteSpace=nowrap;fontFamily=Times New Roman;fontSize=%d;fontColor=%s;"
                     "align=%s;verticalAlign=%s;spacing=1;" % (fs, s["color"], align, valign))
            if s.get("bg"):
                style += "labelBackgroundColor=#FFFFFF;"
            cells.append('<mxCell id="%s" value="%s" style="%s" vertex="1" parent="1">'
                         '<mxGeometry x="%.2f" y="%.2f" width="%.2f" height="%.2f" as="geometry"/></mxCell>'
                         % (new_id(), esc(html_escape(lab)), style, x, y, w, h))
    body = "".join(cells)
    return ('<mxfile host="drawio" type="device">\n'
            '  <diagram id="rendezvous" name="Case study (A): charging station">\n'
            '    <mxGraphModel dx="800" dy="400" grid="0" gridSize="10" guides="1" tooltips="1" connect="0" '
            'arrows="1" fold="1" page="0" pageScale="1" pageWidth="%d" pageHeight="%d" math="1" shadow="0">\n'
            '      <root><mxCell id="0"/><mxCell id="1" parent="0"/>%s</root>\n'
            '    </mxGraphModel>\n  </diagram>\n</mxfile>\n') % (int(W * PX), int(H * PX), body)


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, "rendezvous_setup.tex"), "w") as f:
        f.write(export_tikz())
    with open(os.path.join(OUT, "rendezvous_setup.drawio"), "w") as f:
        f.write(export_drawio())
    print("b_i(t):", np.round(pos, 2).tolist())
    print("x*(t) =", np.round(xstar, 2))
    print("wrote", os.path.join(OUT, "rendezvous_setup.tex"), "and", os.path.join(OUT, "rendezvous_setup.drawio"))
    if SPLICE:
        # replace the tikzpicture between the BEGIN/END marker lines of the paper
        src = open(SPLICE).read()
        i = src.index(BEGIN)
        i = src.index("\n", i) + 1
        j = src.index(END)
        j = src.rindex("\n", 0, j) + 1
        src = src[:i] + export_tikz().rstrip("\n") + "\n" + src[j:]
        with open(SPLICE, "w") as f:
            f.write(src)
        print("spliced into", SPLICE)
