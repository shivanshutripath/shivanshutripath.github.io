Cooperative Learning of Shared Latent Dynamics
==============================================

Source accompanying the project page and the L4DC submission
"Cooperative Learning of Shared Latent Dynamics for Distributed Online Optimization"
by Shivanshu Tripathi and Maziar Raissi.

paper_code/     Algorithm 1, both case studies, figure generation (numpy only)
webots_demo/    Case study (A) as six station processes plus a charging robot in Webots

Paper experiments
-----------------
cd paper_code
python3 experiments.py --out data --jobs 4
python3 summarize.py data

Webots (case study A as a distributed program)
----------------------------------------------
Requires Webots nightly on macOS 27 (the stable R2025a package cannot open a port;
see webots_demo/README.md) and Python 3 with numpy. Each controller runtime.ini
points at a local interpreter; edit that path before running.

open -a Webots-nightly webots_demo/worlds/disaster_response.wbt

Headless data collection and the audit against paper_code/experiments.py:

cd webots_demo
python3 tools/collect_data.py --N 100 --track 200 --seeds 2026-2045
python3 tools/analyze_runs.py output/runs

The logged run on the project page is output/runs/N100/seed_2026 of that audit
(not included here; regenerate it with the command above).
