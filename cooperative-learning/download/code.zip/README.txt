Cooperative Learning of Shared Latent Dynamics
==============================================

Code accompanying "Cooperative Learning of Shared Latent Dynamics for
Distributed Online Optimization" by Shivanshu Tripathi and Maziar Raissi
(submitted to L4DC 2027). Project page:
https://shivanshutripath.github.io/cooperative-learning/

paper_v4_package/code/  Algorithm 1, every baseline, both case studies and
                        the figures of the paper (numpy only); data/ holds
                        the run reported in the paper
webots_demo/            case study (A) in Webots: six station processes, a
                        charging robot, and a supervisor that plays the
                        environment; output/analysis/ holds the numbers of
                        the 100 logged runs, output/web_animation/logs/ the
                        run shown in 3D on the project page

recommendation_demo/    case study (B) with products and users: eight named
                        regions, 32 products, 4,000 users and the session logs
                        from which each server measures its region's interests;
                        the "Recommendation systems" section of the project
                        page. output/ holds the numbers of the trial of Figure
                        3(b), of the 250 Monte Carlo trials of the N-sweep, and
                        of the run with one process per regional server

Requirements: Python 3 with numpy. Webots R2025a for the simulation; on
macOS 27 use the nightly build (the stable package cannot open a port, see
webots_demo/README.md). Each controller's runtime.ini points at a local
Python interpreter: edit that path first.

Paper experiments (Section 5.1)
-------------------------------
cd paper_v4_package/code
python3 experiments.py --out data --jobs 4    # 50 trials per point, ~35 min on 2 cores
python3 summarize.py data                     # the numbers quoted in the text
python3 experiments.py --out test --quick     # 5-trial smoke test

Webots (Section 5.2)
--------------------
open -a Webots-nightly webots_demo/worlds/disaster_response.wbt

cd webots_demo
for N in 30 50 100 150 200; do python3 tools/collect_data.py --N $N --track 200 --seeds 2026-2045; done
python3 tools/analyze_runs.py output/runs     # audit against experiments.py, baselines, Section 5.2 numbers

Recommendation systems (case study (B) with products and users)
---------------------------------------------------------------
cd recommendation_demo
python3 run_demo.py                 # the trial of Figure 3(b) with products, users and session logs (~11 s)
python3 run_montecarlo.py --jobs 6  # the 250 trials of the N-sweep with product-level metrics (~6 min)
python3 run_distributed.py          # the same trial with one OS process per regional server (~2 s)
python3 make_figures.py             # figures, from output/ (matplotlib)
python3 -m pytest -q tests          # the tests (pytest and scipy)

The 3D scene on the project page
--------------------------------
sh webots_demo/tools/record_animation.sh PAGE_DIR

records seed 2026 (N = 100, 200 tracking steps) as a Webots web animation and
copies it, with a self-hosted copy of the Webots web player, into PAGE_DIR
(see webots_demo/README.md, "The web animation").
